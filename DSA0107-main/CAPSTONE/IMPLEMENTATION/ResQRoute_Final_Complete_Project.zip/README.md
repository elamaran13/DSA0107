# ResQRoute: Intelligent Emergency Vehicle Dispatch & Route Prioritization System

ResQRoute is an intelligent, high-performance decision-support platform for emergency medical services (EMS). The system integrates dynamic emergency priority queues, graph-theoretic routing with real-time disruption handling, and a novel **Counterfactual Look-Ahead Dispatch Optimizer** that evaluates prospective consequences before committing critical ambulance assets.

---

## 1. Project Overview

Traditional EMS dispatch systems rely primarily on myopic greedy heuristics—most commonly selecting the closest available ambulance to an incident. While intuitive, greedy dispatch often creates critical coverage vacuums in high-demand municipal sectors, resulting in severe delays when subsequent life-threatening emergencies arrive.

ResQRoute overcomes this challenge by combining:
1. **Dynamic Emergency Prioritization** (urgency escalation based on severity and waiting time).
2. **Counterfactual Look-Ahead Optimization** (multi-objective rollout evaluation across prospective future demand scenarios).
3. **Dynamic Graph Routing & Coverage Assessment** (Dijkstra shortest-path routing, road closure detours, and isochrone coverage analysis).

---

## 2. Project Objectives

- **Urgency-Aware Prioritization:** Dynamically classify and re-rank emergency calls based on clinical severity and accumulated queue delay.
- **Counterfactual Decision Support:** Evaluate candidate dispatch decisions across immediate travel times, projected future delays, and regional coverage loss.
- **Resilient Road Routing:** Identify shortest paths and automatically calculate alternative detours when urban corridors are disrupted by closures or congestion.
- **Regional Coverage Preservation:** Quantify demand-weighted population coverage within guaranteed time thresholds (e.g., $\le 10$ minutes).
- **Rigorous Comparative Benchmarking:** Objectively benchmark the proposed algorithm against standard greedy and immediate heuristic baselines across standardized incident scenarios.

---

## 3. The Three Core Modules

### Module 1: Dynamic Emergency Prioritization & Incident Management
- **Emergency Registration:** Captures location, emergency type (cardiac, trauma, respiratory, etc.), patient triage details, and arrival timestamp.
- **Dynamic Priority Engine:** Priority scores update dynamically as simulation time progresses:
  $$\text{Priority Score} = (w_{\text{sev}} \times S_i) + (w_{\text{wait}} \times \Delta t_{\text{wait}})$$
- **Max-Priority Queue:** Implemented in C++ to guarantee $O(\log N)$ insertion and extraction of the highest-priority patient.
- **Validated Lifecycle State Machine:** Enforces valid status transitions:
  $$\text{Pending} \longrightarrow \text{Dispatched} \longrightarrow \text{In-Transit} \longrightarrow \text{Resolved} \text{ (or Cancelled)}$$

### Module 2: Counterfactual Look-Ahead Ambulance Dispatch Optimization (Main Innovation)
- **Feasible Candidate Generation:** Evaluates all available EMS units capable of reaching the incident location.
- **Multi-Objective Cost Formulation:** Instead of simply choosing the nearest ambulance, the optimizer computes:
  $$\text{Total Cost} = w_1 \cdot C_{\text{imm}} + w_2 \cdot C_{\text{fut}} + w_3 \cdot P_{\text{crit}} + w_4 \cdot L_{\text{cov}} + w_5 \cdot P_{\text{disrupt}}$$
  - $C_{\text{imm}}$: Immediate travel time weighted by incident severity.
  - $C_{\text{fut}}$: Expected delay across prospective future emergency arrivals.
  - $P_{\text{crit}}$: Severe vulnerability penalty if future critical calls lack nearby coverage.
  - $L_{\text{cov}}$: Marginal loss of demand-weighted coverage in neighboring municipal zones.
  - $P_{\text{disrupt}}$: Detour penalty caused by active road closures.
- **Optimal Selection:** The candidate minimizing total objective cost is dispatched, generating a clear human-readable explanation of why that unit was chosen.

### Module 3: Dynamic Routing, Coverage Assessment & Performance Evaluation
- **Graph-Based Road Network:** Vertices represent municipal sectors, hospitals, and stations; edges represent road corridors with distance, speed limits, and travel times.
- **Dijkstra Shortest Path:** High-performance C++ implementation calculating optimal routes and automated detours around closures.
- **Ambulance Coverage Isochrones:** Computes demand-weighted percentage of urban sectors reachable within a defined response threshold (default: 10.0 min).
- **Strategy Benchmarking:** Systematically compares:
  1. *Nearest Available Ambulance* (Standard Greedy Baseline)
  2. *Immediate Priority-and-Coverage Scoring* (Static Heuristic Baseline)
  3. *Proposed Counterfactual Look-Ahead Optimization*

---

## 4. Technology Stack

| Component | Technology | Role |
|---|---|---|
| **Core Computational Engine** | C++17 (STL, Dijkstra, Priority Queue) | High-speed algorithmic execution & graph calculations |
| **Backend Orchestration** | Python 3.9+ | Data management, simulation clock, subprocess bridge |
| **Web Dashboard** | Streamlit | Interactive high-contrast emergency operations dashboard |
| **Data Visualization** | Plotly | Interactive road network graphs, cost breakdowns, and bar charts |
| **Database** | SQLite3 | Persistent storage for incidents, fleet, decisions, and benchmarks |
| **Build Configuration** | CMake / Direct g++ | Portable cross-compiler configuration |
| **Automated Testing** | Pytest & C++ Test Suite | Comprehensive unit and integration verification |

---

## 5. System Architecture

```
[ User / Dispatcher ]
         │
         ▼
[ Streamlit Web Frontend ] (Clean Localhost • High-Contrast Emergency Theme)
         │
         ▼
[ Python Backend Orchestrator ] (launcher.py, services/, database.py, data_manager.py)
         │
   ┌─────┴─────────────────────────────────────┐
   ▼                                           ▼
[ SQLite Database ]                 [ C++17 Computational Core ]
 (Incidents, Fleet, Roads,           (PriorityQueue, Dijkstra Router,
  Decisions, Benchmarks)              LookAheadOptimizer, Evaluator)
```

---

## 6. Project Folder Structure

```
ResQRoute_Final/
├── .streamlit/
│   └── config.toml               # Clean light theme & server configuration
├── cpp_engine/                   # C++17 Core Engine
│   ├── include/                  # C++ Header files
│   │   ├── Ambulance.h
│   │   ├── CoverageAnalyzer.h
│   │   ├── DispatchDecision.h
│   │   ├── DispatchStrategy.h
│   │   ├── Incident.h
│   │   ├── LookAheadOptimizer.h
│   │   ├── PerformanceEvaluator.h
│   │   ├── PriorityEngine.h
│   │   ├── RoadNetwork.h
│   │   ├── RouteOptimizer.h
│   │   └── json.hpp              # Header-only JSON library
│   ├── src/                      # C++ Source implementations
│   ├── tests/                    # C++ Unit test suite (29 tests)
│   ├── build_engine.bat          # Standalone C++ build script
│   └── CMakeLists.txt            # CMake build definition
├── data/                         # CSV datasets (locations, roads, incidents, etc.)
├── database/                     # SQLite database file (resqroute.db)
├── docs/                         # Extended architectural documentation
├── exports/                      # Exported CSV evaluation reports
├── services/                     # Python business logic & service handlers
├── tests/                        # Automated pytest suite (21 tests)
├── ui/                           # Streamlit UI pages & high-contrast theme
├── app.py                        # Streamlit web application entry point
├── config.py                     # Centralized configuration (relative paths)
├── cpp_bridge.py                 # Subprocess bridge between Python and C++
├── data_manager.py               # Dataset manager & SQLite loader
├── database.py                   # SQLite schema initialization & connection
├── generate_dataset.py           # Sample data generator
├── launcher.py                   # Dynamic port launcher & browser opener
├── requirements.txt              # Pinned Python package dependencies
├── setup.bat                     # Windows first-time installation script
├── run.bat                       # Windows one-click execution script
├── run.sh                        # Linux/macOS launcher script
├── VS_CODE_GUIDE.md              # Detailed VS Code execution guide
└── ANTIGRAVITY_GUIDE.md          # Guide for running inside Antigravity
```

---

## 7. System Requirements

- **Operating System:** Windows 10/11 (or Linux / macOS via `run.sh`).
- **Python:** Python 3.9 or higher (Python 3.10, 3.11, 3.12, 3.14 supported).
- **C++ Compiler:** Any C++17 compliant compiler (MinGW-w64 `g++`, Clang, or Visual Studio MSVC).
- **Web Browser:** Google Chrome, Microsoft Edge, Mozilla Firefox, or Safari.

---

## 8. First-Time Setup Instructions

1. Extract the project folder `ResQRoute_Final` to any folder or drive on your computer (e.g., `C:\Projects\ResQRoute_Final`).
2. Open the `ResQRoute_Final` folder in **Visual Studio Code** (or open a Command Prompt inside the folder).
3. In the terminal, execute:
   ```cmd
   .\setup.bat
   ```
4. The setup script will automatically:
   - Verify Python and its version.
   - Create a local virtual environment (`.venv`).
   - Install all required Python libraries from `requirements.txt`.
   - Compile the C++17 computational core into `resqroute_engine.exe`.
   - Initialize the SQLite database and seed initial municipal data.
   - Execute all verification tests (29 C++ tests + 21 Python tests).

---

## 9. Normal Execution (One-Click Launch)

After completing the initial setup, simply run:
```cmd
.\run.bat
```
The script automatically:
1. Detects an available localhost port (defaults to `8501`, smoothly shifting to `8502` if another project is running).
2. Starts the Streamlit application server.
3. Polls the server until confirmed online.
4. Opens your default web browser to the clean address: `http://127.0.0.1:8501`.
5. Displays the active URL and operational telemetry in the terminal.

---

## 10. Teammate Laptop Setup

When sharing the project with teammates:
1. Share `ResQRoute_Final_Complete_Project.zip`.
2. Extract the ZIP anywhere on their Windows laptop.
3. Open the folder in VS Code and open the terminal (`Ctrl + ~`).
4. Run `.\setup.bat` once.
5. Launch the application anytime with `.\run.bat`.
*All paths are resolved dynamically using `%~dp0` and Python's `Path(__file__)`. No machine-specific dependencies or hardcoded paths exist.*

---

## 11. Stopping the Application

To stop the ResQRoute server:
- Click into the terminal window running `run.bat` (or `launcher.py`).
- Press **Ctrl + C**.
- The server will cleanly terminate without affecting any other running applications.

---

## 12. Dynamic Port Selection & Conflict Prevention

If you are running another application or another Streamlit project on port `8501`:
- ResQRoute detects that port `8501` is occupied.
- It dynamically binds to the next available port (e.g., `8502`).
- It opens the browser directly to `http://127.0.0.1:8502`.
- It does **not** kill or interfere with your other project.

---

## 13. UI Visibility & High-Contrast Design

ResQRoute features an emergency operations dashboard theme:
- **Canvas Background:** Soft blue-grey (`#F3F6FA`).
- **Sidebar:** Dark Navy (`#10243A`) with crisp white typography.
- **Headings:** Deep Navy (`#142B45`).
- **Body Text:** Solid Black (`#000000`) for complete contrast.
- **Secondary Text:** Charcoal (`#333333`).
- **Cards & Forms:** Clean White (`#FFFFFF`) with borders (`#D9E1EA`).
- **Action Buttons:** Deep Blue (`#174A78`) with White text (`#FFFFFF`).
- **Plotly Charts:** Pure white backgrounds with dark navy titles and black tick marks.

---

## 14. Testing Instructions

### Run Python Automated Tests:
```cmd
.\.venv\Scripts\python.exe -m pytest tests -v
```

### Run C++ Core Unit Tests:
```cmd
.\cpp_engine\resqroute_tests.exe
```

### Ping C++ Engine via CLI:
```cmd
.\cpp_engine\resqroute_engine.exe --mode ping
```

---

## 15. Troubleshooting

| Issue | Cause | Solution |
|---|---|---|
| `'python' is not recognized` | Python not in system PATH | Reinstall Python 3.10+ and enable "Add Python to PATH" |
| `'g++' is not recognized` | No C++ compiler in PATH | Install MinGW-w64 or TDM-GCC, or run `cpp_engine\build_engine.bat` |
| `Port already in use` | Another service on port | `launcher.py` automatically selects the next free port (`8502`) |
| `Database locked` | File locked by open viewer | Close any external SQLite explorer tool and retry |

