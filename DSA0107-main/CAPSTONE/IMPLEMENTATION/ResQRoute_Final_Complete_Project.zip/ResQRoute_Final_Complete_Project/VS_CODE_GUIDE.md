# Visual Studio Code Execution Guide for ResQRoute

This step-by-step guide walks you through extracting, opening, and executing **ResQRoute** directly inside **Visual Studio Code (VS Code)** on any Windows laptop.

---

## Step 1: Open ResQRoute in VS Code

1. Extract `ResQRoute_Final_Complete_Project.zip` to your computer (e.g. `C:\Users\<YourUser>\Desktop\ResQRoute_Final` or `D:\Projects\ResQRoute_Final`).
2. Launch **Visual Studio Code**.
3. In the top menu bar, click **File** ➔ **Open Folder...** (or press `Ctrl + K, Ctrl + O`).
4. Browse to and select the folder **`ResQRoute_Final`**, then click **Select Folder**.
5. When prompted *"Do you trust the authors of the files in this folder?"*, click **Yes, I trust the authors**.

---

## Step 2: Open the Integrated Terminal

1. In the top menu, click **Terminal** ➔ **New Terminal** (or press shortcut **`Ctrl + ` ` `** / **`Ctrl + ~`**).
2. Ensure the terminal shell is set to **Command Prompt (cmd)** or **PowerShell**.
3. Verify that the terminal prompt shows you are in the `ResQRoute_Final` folder:
   ```cmd
   C:\...\ResQRoute_Final>
   ```

---

## Step 3: First-Time Setup (Run Once)

In the VS Code terminal, type the following command and press **Enter**:

```cmd
.\setup.bat
```

### What `setup.bat` does automatically:
- Checks Python installation and verifies version compatibility ($\ge 3.9$).
- Checks the C++17 compiler (`g++` / MSVC) and builds the C++ core engine.
- Creates the local virtual environment `.venv`.
- Installs all required packages (`streamlit`, `pandas`, `numpy`, `plotly`, `pytest`, `cmake`).
- Initializes the SQLite database and loads seed demonstration datasets.
- Runs verification tests to ensure 100% functionality before launch.

*Wait until the script finishes and prints:*
```
=====================================================================
[SUCCESS] ResQRoute Setup Completed Successfully!
=====================================================================
```

---

## Step 4: Normal Execution (Launch the Application)

Once setup is complete, you only ever need to execute:

```cmd
.\run.bat
```

### What happens when you run `.\run.bat`:
1. Activates the project's local virtual environment.
2. Checks port availability starting from `8501`. If `8501` is occupied by another project, it dynamically selects `8502` to prevent interference.
3. Starts the Streamlit dashboard server in headless mode.
4. Waits for the server to confirm it is fully initialized and healthy.
5. Automatically opens your default web browser to the clean address:
   ```
   http://127.0.0.1:8501
   ```
6. The terminal remains open, displaying live logs and operational telemetry.

---

## Step 5: How to Stop the Application

To shut down the ResQRoute server:
1. Click into the VS Code terminal where `run.bat` is running.
2. Press **`Ctrl + C`**.
3. The server shuts down cleanly without affecting any other running application or terminal.

---

## Step 6: Running Automated Tests in VS Code

You can run automated tests anytime in the VS Code terminal:

### Python Pytest Suite:
```cmd
.\.venv\Scripts\python.exe -m pytest tests -v
```

### C++ Core Engine Unit Tests:
```cmd
.\cpp_engine\resqroute_tests.exe
```

---

## Summary of Commands

| Purpose | Command |
|---|---|
| **First-Time Setup** | `.\setup.bat` |
| **Normal Launch** | `.\run.bat` |
| **Run Pytest** | `.\.venv\Scripts\python.exe -m pytest tests` |
| **Run C++ Tests** | `.\cpp_engine\resqroute_tests.exe` |
| **Stop Server** | Press `Ctrl + C` in the terminal |

