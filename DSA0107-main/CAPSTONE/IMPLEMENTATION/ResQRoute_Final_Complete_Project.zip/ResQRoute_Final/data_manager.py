import os
import csv
import logging
from pathlib import Path
from typing import Dict, Any, List, Tuple, Optional
import pandas as pd

from config import DATA_DIR, EXPORTS_DIR, DATABASE_PATH
from database import get_connection, init_db, reset_database
from generate_dataset import generate_all_datasets

logger = logging.getLogger("ResQRoute.DataManager")

class DataManager:
    """
    Manages CSV datasets, validation, imports/exports, and synchronization with SQLite.
    """

    def __init__(self, data_dir: Path = DATA_DIR, exports_dir: Path = EXPORTS_DIR):
        self.data_dir = data_dir
        self.exports_dir = exports_dir
        self.data_dir.mkdir(parents=True, exist_ok=True)
        self.exports_dir.mkdir(parents=True, exist_ok=True)

    def verify_or_generate_csvs(self):
        """Ensures all required CSV files exist with valid sample data."""
        required = [
            "locations.csv",
            "road_network.csv",
            "road_closures.csv",
            "ambulances.csv",
            "incidents.csv",
            "scenarios.csv"
        ]
        missing = [f for f in required if not (self.data_dir / f).exists()]
        if missing:
            logger.info("Generating missing CSV datasets: %s", missing)
            generate_all_datasets(self.data_dir)

    def validate_csv(self, filename: str) -> Tuple[bool, List[str]]:
        """
        Validates CSV structure, mandatory columns, and checks for duplicate IDs.
        """
        file_path = self.data_dir / filename
        if not file_path.exists():
            return False, [f"File {filename} does not exist."]

        errors = []
        try:
            df = pd.read_csv(file_path)
            if df.empty:
                return False, [f"File {filename} is empty."]

            id_col = "id" if "id" in df.columns else ("road_id" if "road_id" in df.columns else None)
            if id_col:
                duplicates = df[df.duplicated(subset=[id_col], keep=False)]
                if not duplicates.empty:
                    dup_ids = duplicates[id_col].unique().tolist()
                    errors.append(f"Duplicate IDs found in {id_col}: {dup_ids}")

            if filename == "incidents.csv":
                required_cols = {"id", "location", "severity", "arrival_time", "status"}
                if not required_cols.issubset(df.columns):
                    errors.append(f"Missing required columns in incidents.csv: {required_cols - set(df.columns)}")
                invalid_sev = df[~df["severity"].isin(["Critical", "High", "Medium", "Low"])]
                if not invalid_sev.empty:
                    errors.append(f"Invalid severity values in {len(invalid_sev)} records.")
            elif filename == "ambulances.csv":
                required_cols = {"id", "call_sign", "current_location", "status"}
                if not required_cols.issubset(df.columns):
                    errors.append(f"Missing required columns in ambulances.csv: {required_cols - set(df.columns)}")
                invalid_stat = df[~df["status"].isin(["Available", "Busy", "Maintenance"])]
                if not invalid_stat.empty:
                    errors.append(f"Invalid ambulance status in {len(invalid_stat)} records.")

            return len(errors) == 0, errors
        except Exception as e:
            return False, [f"Error reading {filename}: {str(e)}"]

    def load_csv_to_db(self, db_path: Optional[Path] = None, overwrite: bool = False):
        """
        Loads all CSV datasets into SQLite.
        """
        self.verify_or_generate_csvs()
        init_db(db_path)
        conn = get_connection(db_path)
        cursor = conn.cursor()

        # Check if database is already populated
        cursor.execute("SELECT COUNT(*) as count FROM locations;")
        count = cursor.fetchone()["count"]
        if count > 0 and not overwrite:
            conn.close()
            return

        cursor.execute("PRAGMA foreign_keys = OFF;")
        cursor.execute("BEGIN TRANSACTION;")

        try:
            # 1. Locations
            df_loc = pd.read_csv(self.data_dir / "locations.csv")
            cursor.execute("DELETE FROM locations;")
            for _, r in df_loc.iterrows():
                cursor.execute("""
                    INSERT INTO locations (id, name, type, demand_weight, latitude, longitude)
                    VALUES (?, ?, ?, ?, ?, ?);
                """, (r["id"], r["name"], r["type"], float(r["demand_weight"]), float(r["latitude"]), float(r["longitude"])))

            # 2. Roads
            df_roads = pd.read_csv(self.data_dir / "road_network.csv")
            cursor.execute("DELETE FROM roads;")
            for _, r in df_roads.iterrows():
                cursor.execute("""
                    INSERT INTO roads (road_id, source, destination, distance_km, speed_limit_kmh, travel_time_min, is_closed, closure_reason, is_bidirectional)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?);
                """, (r["road_id"], r["source"], r["destination"], float(r["distance_km"]), float(r["speed_limit_kmh"]), float(r["travel_time_min"]), int(r["is_closed"]), str(r.get("closure_reason", "")), int(r.get("is_bidirectional", 1))))

            # 3. Road Closures
            if (self.data_dir / "road_closures.csv").exists():
                df_cls = pd.read_csv(self.data_dir / "road_closures.csv")
                cursor.execute("DELETE FROM road_closures;")
                for _, r in df_cls.iterrows():
                    cursor.execute("""
                        INSERT INTO road_closures (id, road_id, closed_at, reopened_at, reason, is_active)
                        VALUES (?, ?, ?, ?, ?, ?);
                    """, (int(r["id"]), r["road_id"], str(r.get("closed_at", "")), str(r.get("reopened_at", "")), str(r.get("reason", "")), int(r.get("is_active", 1))))

            # 4. Ambulances
            df_amb = pd.read_csv(self.data_dir / "ambulances.csv")
            cursor.execute("DELETE FROM ambulances;")
            for _, r in df_amb.iterrows():
                cursor.execute("""
                    INSERT INTO ambulances (id, call_sign, current_location, status, station_id, fuel_level, assigned_incident_id, busy_until_time)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?);
                """, (r["id"], r["call_sign"], r["current_location"], r["status"], r["station_id"], float(r.get("fuel_level", 100.0)), str(r.get("assigned_incident_id", "")), float(r.get("busy_until_time", 0.0))))

            # 5. Incidents
            df_inc = pd.read_csv(self.data_dir / "incidents.csv")
            cursor.execute("DELETE FROM incidents;")
            for _, r in df_inc.iterrows():
                cursor.execute("""
                    INSERT INTO incidents (id, location, severity, arrival_time, waiting_time, description, status, priority_score, severity_weight, waiting_time_weight, assigned_ambulance_id)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
                """, (r["id"], r["location"], r["severity"], float(r["arrival_time"]), float(r.get("waiting_time", 0.0)), r["description"], r["status"], float(r.get("priority_score", 0.0)), float(r.get("severity_weight", 25.0)), float(r.get("waiting_time_weight", 2.0)), str(r.get("assigned_ambulance_id", ""))))

            # 6. Scenarios
            if (self.data_dir / "scenarios.csv").exists():
                df_scen = pd.read_csv(self.data_dir / "scenarios.csv")
                cursor.execute("DELETE FROM scenario_definitions;")
                for _, r in df_scen.iterrows():
                    cursor.execute("""
                        INSERT INTO scenario_definitions (id, name, description, incident_count, fleet_count)
                        VALUES (?, ?, ?, ?, ?);
                    """, (r["id"], r["name"], r["description"], int(r.get("incident_count", 0)), int(r.get("fleet_count", 0))))

            conn.commit()
            logger.info("Successfully populated SQLite database from CSV datasets.")
        except Exception as e:
            conn.rollback()
            logger.error("Failed to load CSV datasets into database: %s", e)
            raise e
        finally:
            cursor.execute("PRAGMA foreign_keys = ON;")
            conn.close()

    def reset_and_reload(self, confirm: bool = False, db_path: Optional[Path] = None):
        """Safely resets the database and reloads default datasets."""
        reset_database(db_path, confirm=confirm)
        self.load_csv_to_db(db_path, overwrite=True)

    def export_table_to_csv(self, table_name: str, output_path: Optional[Path] = None) -> Path:
        """Exports an SQLite table to a clean CSV file."""
        conn = get_connection()
        query = f"SELECT * FROM {table_name};"
        df = pd.read_sql_query(query, conn)
        conn.close()

        out_file = output_path or (self.exports_dir / f"{table_name}_export.csv")
        df.to_csv(out_file, index=False)
        return out_file

    def export_all_tables(self) -> List[Path]:
        tables = ["locations", "roads", "ambulances", "incidents", "dispatch_decisions", "candidate_evaluations", "simulation_results"]
        exported = []
        for t in tables:
            exported.append(self.export_table_to_csv(t))
        return exported

data_manager = DataManager()
