-- ResQRoute SQLite Database Schema
-- Intelligent Emergency Vehicle Dispatch & Dynamic Route Prioritization System

PRAGMA foreign_keys = ON;

-- 1. Municipal Geographic Network
CREATE TABLE IF NOT EXISTS locations (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    type TEXT NOT NULL,
    demand_weight REAL DEFAULT 1.0,
    latitude REAL,
    longitude REAL
);

-- 2. Road Network Segments
CREATE TABLE IF NOT EXISTS roads (
    road_id TEXT PRIMARY KEY,
    source TEXT NOT NULL,
    destination TEXT NOT NULL,
    distance_km REAL NOT NULL,
    speed_limit_kmh REAL NOT NULL,
    travel_time_min REAL NOT NULL,
    is_closed INTEGER DEFAULT 0,
    closure_reason TEXT DEFAULT '',
    is_bidirectional INTEGER DEFAULT 1,
    FOREIGN KEY (source) REFERENCES locations(id),
    FOREIGN KEY (destination) REFERENCES locations(id)
);

-- 3. Dynamic Road Closures & Incidents
CREATE TABLE IF NOT EXISTS road_closures (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    road_id TEXT NOT NULL,
    reason TEXT NOT NULL,
    reported_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    resolved_at TIMESTAMP,
    FOREIGN KEY (road_id) REFERENCES roads(road_id)
);

-- 4. Emergency Fleet Roster
CREATE TABLE IF NOT EXISTS ambulances (
    id TEXT PRIMARY KEY,
    call_sign TEXT NOT NULL,
    base_location TEXT NOT NULL,
    current_location TEXT NOT NULL,
    status TEXT NOT NULL CHECK(status IN ('Available', 'Busy', 'Maintenance', 'En-Route')),
    equipment_level TEXT DEFAULT 'ALS',
    assigned_incident_id TEXT,
    available_at_time REAL DEFAULT 0.0,
    total_missions_completed INTEGER DEFAULT 0,
    FOREIGN KEY (base_location) REFERENCES locations(id),
    FOREIGN KEY (current_location) REFERENCES locations(id)
);

-- 5. Emergency Incident Register & Priority Tracking
CREATE TABLE IF NOT EXISTS incidents (
    id TEXT PRIMARY KEY,
    caller_name TEXT DEFAULT 'Anonymous',
    contact_number TEXT DEFAULT '911',
    emergency_type TEXT NOT NULL,
    severity_level TEXT NOT NULL CHECK(severity_level IN ('Critical', 'High', 'Medium', 'Low')),
    base_priority REAL NOT NULL,
    current_priority REAL NOT NULL,
    location_id TEXT NOT NULL,
    latitude REAL,
    longitude REAL,
    patient_condition TEXT DEFAULT 'Stable',
    reported_time REAL NOT NULL,
    status TEXT NOT NULL CHECK(status IN ('Pending', 'Dispatched', 'In-Transit', 'Resolved', 'Cancelled')),
    assigned_ambulance_id TEXT,
    waiting_time_minutes REAL DEFAULT 0.0,
    FOREIGN KEY (location_id) REFERENCES locations(id),
    FOREIGN KEY (assigned_ambulance_id) REFERENCES ambulances(id)
);

-- 6. Mission Assignments & Transit Timings
CREATE TABLE IF NOT EXISTS assignments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    incident_id TEXT NOT NULL,
    ambulance_id TEXT NOT NULL,
    assigned_at REAL NOT NULL,
    estimated_arrival_minutes REAL NOT NULL,
    detour_occurred INTEGER DEFAULT 0,
    detour_delay_minutes REAL DEFAULT 0.0,
    route_path TEXT DEFAULT '[]',
    FOREIGN KEY (incident_id) REFERENCES incidents(id),
    FOREIGN KEY (ambulance_id) REFERENCES ambulances(id)
);

-- 7. Look-Ahead Dispatch Decisions Log
CREATE TABLE IF NOT EXISTS dispatch_decisions (
    decision_id TEXT PRIMARY KEY,
    incident_id TEXT NOT NULL,
    selected_ambulance_id TEXT NOT NULL,
    strategy_used TEXT NOT NULL,
    response_time_minutes REAL NOT NULL,
    coverage_loss_penalty REAL NOT NULL,
    opportunity_cost REAL NOT NULL,
    total_lookahead_cost REAL NOT NULL,
    evaluated_at REAL NOT NULL,
    timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (incident_id) REFERENCES incidents(id),
    FOREIGN KEY (selected_ambulance_id) REFERENCES ambulances(id)
);

-- 8. Candidate Vehicle Evaluation Audit
CREATE TABLE IF NOT EXISTS candidate_evaluations (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    decision_id TEXT NOT NULL,
    ambulance_id TEXT NOT NULL,
    travel_time_min REAL NOT NULL,
    coverage_loss REAL NOT NULL,
    future_penalty REAL NOT NULL,
    total_score REAL NOT NULL,
    is_selected INTEGER DEFAULT 0,
    FOREIGN KEY (decision_id) REFERENCES dispatch_decisions(decision_id),
    FOREIGN KEY (ambulance_id) REFERENCES ambulances(id)
);

-- 9. Simulation Runs Log
CREATE TABLE IF NOT EXISTS simulation_runs (
    run_id TEXT PRIMARY KEY,
    scenario_id TEXT NOT NULL,
    scenario_name TEXT NOT NULL,
    started_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    completed_at TIMESTAMP,
    status TEXT DEFAULT 'Completed'
);

-- 10. Multi-Strategy Comparative Evaluation Results
CREATE TABLE IF NOT EXISTS simulation_results (
    result_id TEXT PRIMARY KEY,
    run_id TEXT NOT NULL,
    strategy TEXT NOT NULL,
    avg_response_time_minutes REAL NOT NULL,
    critical_response_time_minutes REAL NOT NULL,
    coverage_preservation_pct REAL NOT NULL,
    total_distance_km REAL NOT NULL,
    computation_time_ms REAL NOT NULL,
    incidents_served INTEGER NOT NULL,
    detours_encountered INTEGER NOT NULL,
    FOREIGN KEY (run_id) REFERENCES simulation_runs(run_id)
);

-- 11. Evaluation Scenario Definitions
CREATE TABLE IF NOT EXISTS scenario_definitions (
    scenario_id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    description TEXT NOT NULL,
    incident_count INTEGER NOT NULL,
    road_closures_count INTEGER NOT NULL,
    fleet_availability_pct REAL NOT NULL
);

-- Performance Indexes
CREATE INDEX IF NOT EXISTS idx_roads_source ON roads(source);
CREATE INDEX IF NOT EXISTS idx_roads_dest ON roads(destination);
CREATE INDEX IF NOT EXISTS idx_ambulances_status ON ambulances(status);
CREATE INDEX IF NOT EXISTS idx_incidents_status ON incidents(status);
CREATE INDEX IF NOT EXISTS idx_incidents_priority ON incidents(current_priority DESC);
CREATE INDEX IF NOT EXISTS idx_dispatch_incident ON dispatch_decisions(incident_id);
