# ResQRoute System Architecture & Technical Specification

## 1. Architectural Architecture Overview

ResQRoute implements a decoupled multi-tier architecture separating high-performance algorithmic execution, backend business logic, persistent data management, and the user-facing web dashboard.

```
┌────────────────────────────────────────────────────────┐
│                   User / Dispatcher                    │
│  - Incident Registration     - Fleet Management        │
│  - Look-Ahead Dispatch       - Route & Analysis        │
└───────────────────────────┬────────────────────────────┘
                            │
                            ▼
┌────────────────────────────────────────────────────────┐
│              Streamlit Web Frontend (UI)               │
│  - Emergency Theme Palette: #F3F6FA, #10243A, #142B45   │
│  - Solid Black Body Text: #000000 (100% Contrast)      │
│  - Plotly Interactive Visualizations & Geospatial Map  │
└───────────────────────────┬────────────────────────────┘
                            │
                            ▼
┌────────────────────────────────────────────────────────┐
│             Python Backend Orchestrator                │
│  - launcher.py: Dynamic Port Selection & URL Launch    │
│  - simulation_service.py: Time & Queue Progression     │
│  - services/: Incident, Ambulance, Road, Dispatch, Eval│
│  - cpp_bridge.py: JSON IPC via Subprocess              │
└──────────────────┬─────────────────┬───────────────────┘
                   │                 │
                   ▼                 ▼
┌────────────────────────┐    ┌──────────────────────────┐
│   SQLite Database      │    │  C++17 Engine Core       │
│  - Incidents Table     │    │  - PriorityEngine        │
│  - Ambulances Table    │    │  - RouteOptimizer        │
│  - Roads & Closures    │    │  - CoverageAnalyzer      │
│  - Decisions & Evals   │    │  - LookAheadOptimizer    │
│  - Simulation Results  │    │  - PerformanceEvaluator  │
└────────────────────────┘    └──────────────────────────┘
```

---

## 2. C++17 Core Engine & OOP Principles

The computational core is written in C++17 to ensure ultra-low execution latency (< 2 ms per dispatch evaluation) and strict encapsulation of safety-critical algorithms.

### Meaningful Demonstration of OOP Concepts:

1. **Classes and Objects:**
   - `Incident`: Encapsulates patient details, severity rating, timestamps, and priority score.
   - `Ambulance`: Encapsulates call signs, current location, mission status, and busy duration.
   - `RoadNetwork`: Encapsulates graph nodes, edges, weights, and disruption states.

2. **Constructors and Destructors:**
   - Parameterized and default constructors across domain models; RAII-compliant destructor memory management.

3. **Encapsulation:**
   - Internal states (e.g. `is_closed`, `status`, `busy_until_time`) are private, exposed through guarded accessors and state transition methods.

4. **Inheritance and Abstract Base Classes:**
   - `DispatchStrategy` is an abstract base class defining pure virtual dispatch contracts:
     ```cpp
     virtual DispatchDecision dispatch(
         const Incident& incident,
         const std::vector<Ambulance>& ambulances,
         const RoadNetwork& network,
         const std::vector<Incident>& pending_queue,
         double current_sim_time) = 0;
     ```

5. **Polymorphism & Virtual Functions:**
   - Three distinct strategies inherit from `DispatchStrategy` and override the `dispatch(...)` method:
     1. `NearestAmbulanceStrategy`
     2. `ImmediateScoringStrategy`
     3. `LookAheadOptimizer`

6. **Function Overloading:**
   - Overloaded routing functions in `RouteOptimizer` accepting node IDs vs. domain objects, and options to ignore or enforce closures.

7. **Exception Handling:**
   - Explicit `std::invalid_argument` and `std::runtime_error` handling guarding against malformed JSON or invalid topological paths.

8. **STL Containers & Algorithms:**
   - `std::priority_queue` for max-priority scheduling.
   - `std::unordered_map` and `std::vector` for adjacency lists and constant-time node lookups.
   - `std::sort` and `std::min_element` for candidate ranking.
