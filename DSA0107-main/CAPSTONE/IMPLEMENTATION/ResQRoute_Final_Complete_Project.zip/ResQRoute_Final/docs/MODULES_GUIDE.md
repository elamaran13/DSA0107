# ResQRoute: Three Core Modules Detailed Guide

## Module 1: Dynamic Emergency Prioritization & Incident Management

### Clinical Severity Weighting
Each incident is categorized into one of four triage tiers:
- **Critical (Factor 4.0):** Cardiac arrest, severe trauma, respiratory failure, anaphylaxis.
- **High (Factor 3.0):** Acute chest pain, stroke, compound fractures.
- **Medium (Factor 2.0):** Minor burns, stable fractures, high fever.
- **Low (Factor 1.0):** Lacerations, sprains, non-urgent clinical consultations.

### Dynamic Waiting-Time Escalation
To prevent lower-urgency patients from starving in the queue, priority increases dynamically over time:
$$\text{Priority Score} = (w_{\text{sev}} \times \text{Severity Factor}) + (w_{\text{wait}} \times \text{Waiting Minutes})$$

Defaults:
- $w_{\text{sev}} = 25.0$
- $w_{\text{wait}} = 2.0$

A Critical call arrives with an immediate baseline score of $100.0$. A Medium call arriving at $t=0$ with score $50.0$ escalates to $70.0$ after 10 minutes of waiting, ensuring proper medical attention as time elapses.

---

## Module 2: Counterfactual Look-Ahead Ambulance Dispatch Optimization

### Motivation
Greedy dispatch assigns the closest available vehicle. However, if that vehicle is the sole protector of a major industrial or residential sector, dispatching it leaves that sector vulnerable to an impending high-severity emergency.

### Multi-Objective Objective Function
For each available ambulance candidate $k$:
$$\text{Cost}(k) = w_{\text{imm}} \cdot C_{\text{imm}}(k) + w_{\text{fut}} \cdot C_{\text{fut}}(k) + w_{\text{crit}} \cdot P_{\text{crit}}(k) + w_{\text{cov}} \cdot L_{\text{cov}}(k) + w_{\text{disrupt}} \cdot P_{\text{disrupt}}(k)$$

Where:
- **$C_{\text{imm}}(k)$:** Travel time from candidate $k$ to the incident, multiplied by the incident severity factor.
- **$C_{\text{fut}}(k)$:** Estimated delay in responding to simulated future calls if ambulance $k$ is committed.
- **$P_{\text{crit}}(k)$:** Penalty applied if committing candidate $k$ leaves any future Critical call unassigned or with $>12$ min response time.
- **$L_{\text{cov}}(k)$:** Marginal coverage loss across all municipal demand nodes:
  $$L_{\text{cov}}(k) = \text{Pre-Dispatch Coverage} \% - \text{Post-Dispatch Coverage} \%$$
- **$P_{\text{disrupt}}(k)$:** Additional detour penalty caused by active road closures along candidate $k$'s optimal path.

The optimizer deterministically selects $\arg\min_k \text{Cost}(k)$ among all feasible units.

---

## Module 3: Dynamic Routing, Coverage Assessment & Performance Evaluation

### Graph-Based Road Network
- Urban sectors are vertices $V$, roads are edges $E$ with length $d_e$, speed limit $v_e$, and baseline travel time:
  $$t_e = \frac{d_e}{v_e} \times 60 \text{ minutes}$$
- Road closures set $t_e = \infty$, forcing Dijkstra to explore alternative detours.

### Ambulance Coverage Isochrones
For a response threshold $T = 10.0\text{ min}$, a location node $i$ is covered if at least one available ambulance can reach it in $\le T$ minutes.
Demand-weighted coverage is computed as:
$$\text{Coverage} \% = \frac{\sum_{i \in \text{Covered}} \text{DemandWeight}(i)}{\sum_{i \in V} \text{DemandWeight}(i)} \times 100$$

### Benchmark Strategies Evaluated
1. **Nearest Available Ambulance:** Selects $\min_k \text{TravelTime}(k)$.
2. **Immediate Priority-Coverage:** Evaluates static immediate time and immediate coverage without looking ahead.
3. **Counterfactual Look-Ahead Optimizer:** Simulates future stochastic demand events, minimizing expected system-wide regret.
