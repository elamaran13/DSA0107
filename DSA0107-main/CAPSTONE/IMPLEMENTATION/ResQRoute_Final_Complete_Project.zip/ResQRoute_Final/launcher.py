import os
import sys
import time
import socket
import urllib.request
import webbrowser
import subprocess
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parent

def is_port_in_use(port: int, host: str = "127.0.0.1") -> bool:
    """Checks whether a port is currently occupied by an active service."""
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.settimeout(0.3)
        return s.connect_ex((host, port)) == 0

def find_available_port(start_port: int = 8501, max_port: int = 8550, host: str = "127.0.0.1") -> int:
    """
    Finds the first available port starting from start_port up to max_port.
    Prefers 8501 if available. If 8501 is occupied, smoothly selects the next free port
    without terminating or interfering with any running project.
    """
    for port in range(start_port, max_port + 1):
        if not is_port_in_use(port, host):
            try:
                # Double-check bind availability
                with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                    s.bind((host, port))
                    return port
            except OSError:
                continue
    raise RuntimeError(f"No available TCP ports found in range {start_port}-{max_port}.")

def wait_for_server_health(url: str, timeout_seconds: float = 25.0) -> bool:
    """
    Polls the Streamlit health endpoint until the server is confirmed responsive.
    Prevents premature browser launching before the server has started.
    """
    health_url = f"{url.rstrip('/')}/_stcore/health"
    start_time = time.time()
    while time.time() - start_time < timeout_seconds:
        try:
            req = urllib.request.Request(health_url, headers={"User-Agent": "ResQRoute-Launcher"})
            with urllib.request.urlopen(req, timeout=1.0) as resp:
                if resp.status == 200:
                    return True
        except Exception:
            pass

        # Fallback check on root URL
        try:
            req_root = urllib.request.Request(url, headers={"User-Agent": "ResQRoute-Launcher"})
            with urllib.request.urlopen(req_root, timeout=1.0) as resp:
                if resp.status == 200:
                    return True
        except Exception:
            pass

        time.sleep(0.3)
    return False

def main():
    print("=" * 70)
    print("ResQRoute: Intelligent Emergency Vehicle Dispatch & Route Prioritization")
    print("=" * 70)

    # 1. Dynamic Port Selection
    preferred_port = 8501
    if is_port_in_use(preferred_port):
        print(f"[*] Port {preferred_port} is currently in use by another application.")
        print("[*] Performing dynamic port selection to avoid port collision...")
        selected_port = find_available_port(start_port=8502)
        print(f"[OK] Dynamic port selected: {selected_port}")
    else:
        selected_port = preferred_port
        print(f"[OK] Port {selected_port} is available.")

    clean_url = f"http://127.0.0.1:{selected_port}"

    # 2. Build Streamlit Execution Command
    cmd = [
        sys.executable,
        "-m",
        "streamlit",
        "run",
        "app.py",
        "--server.port",
        str(selected_port),
        "--server.address",
        "127.0.0.1",
        "--server.headless",
        "true",
        "--browser.serverAddress",
        "127.0.0.1",
        "--browser.gatherUsageStats",
        "false",
    ]

    env = os.environ.copy()
    env["PYTHONPATH"] = str(PROJECT_ROOT)

    print(f"[*] Starting ResQRoute application server on {clean_url}...")
    proc = subprocess.Popen(cmd, cwd=str(PROJECT_ROOT), env=env)

    try:
        # 3. Wait for confirmed server response
        is_ready = wait_for_server_health(clean_url, timeout_seconds=25.0)

        if is_ready:
            print("\n" + "=" * 70)
            print(">>> ResQRoute Application Server is ONLINE and READY! <<<")
            print(f"Clean Application URL: {clean_url}")
            print("[OK] Opened clean local address in your default web browser.")
            print("[INFO] Press Ctrl+C in this terminal window to stop the server.")
            print("=" * 70 + "\n")
            webbrowser.open(clean_url)
        else:
            print(f"\n[WARNING] Server did not report health within timeout. Checking URL: {clean_url}")
            webbrowser.open(clean_url)

        # 4. Keep alive and handle clean shutdown
        proc.wait()

    except KeyboardInterrupt:
        print("\n[*] Stopping ResQRoute application server...")
        proc.terminate()
        try:
            proc.wait(timeout=5)
        except subprocess.TimeoutExpired:
            proc.kill()
        print("[OK] ResQRoute server stopped cleanly.")
    except Exception as e:
        print(f"\n[ERROR] Launcher exception: {e}")
        proc.terminate()
        return 1

    return 0

if __name__ == "__main__":
    sys.exit(main())
