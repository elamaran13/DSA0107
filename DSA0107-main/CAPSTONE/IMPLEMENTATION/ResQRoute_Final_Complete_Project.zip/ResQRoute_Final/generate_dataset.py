import csv
from pathlib import Path
from config import DATA_DIR

def generate_all_datasets(target_dir: Path = DATA_DIR):
    target_dir.mkdir(parents=True, exist_ok=True)

    # 1. locations.csv (16 municipal locations)
    locations_file = target_dir / "locations.csv"
    locations_data = [
        {"id": "LOC-01", "name": "Central General Hospital", "type": "Hospital", "demand_weight": 5.0, "latitude": 12.9716, "longitude": 77.5946},
        {"id": "LOC-02", "name": "Northside Emergency Station", "type": "Station", "demand_weight": 4.0, "latitude": 12.9900, "longitude": 77.5900},
        {"id": "LOC-03", "name": "Metro Core Commercial Hub", "type": "Commercial", "demand_weight": 4.5, "latitude": 12.9750, "longitude": 77.6050},
        {"id": "LOC-04", "name": "Eastside Residential Heights", "type": "Residential", "demand_weight": 3.0, "latitude": 12.9650, "longitude": 77.6300},
        {"id": "LOC-05", "name": "South Apex Medical Center", "type": "Hospital", "demand_weight": 5.0, "latitude": 12.9250, "longitude": 77.5850},
        {"id": "LOC-06", "name": "West Valley Industrial Park", "type": "Industrial", "demand_weight": 3.5, "latitude": 12.9550, "longitude": 77.5450},
        {"id": "LOC-07", "name": "Suburban Junction North", "type": "Highway_Junction", "demand_weight": 2.5, "latitude": 13.0100, "longitude": 77.6100},
        {"id": "LOC-08", "name": "Tech Corridor South", "type": "Commercial", "demand_weight": 4.0, "latitude": 12.9150, "longitude": 77.6400},
        {"id": "LOC-09", "name": "Harbor Gate Waterfront", "type": "Industrial", "demand_weight": 2.0, "latitude": 12.9400, "longitude": 77.6600},
        {"id": "LOC-10", "name": "Grand Terminal Transit Hub", "type": "Commercial", "demand_weight": 4.5, "latitude": 12.9780, "longitude": 77.5720},
        {"id": "LOC-11", "name": "Hillside Residential Sector", "type": "Residential", "demand_weight": 2.5, "latitude": 12.9950, "longitude": 77.5500},
        {"id": "LOC-12", "name": "Greenfield Health Center", "type": "Hospital", "demand_weight": 4.0, "latitude": 12.9350, "longitude": 77.6150},
        {"id": "LOC-13", "name": "Old Town Heritage District", "type": "Residential", "demand_weight": 3.0, "latitude": 12.9600, "longitude": 77.5750},
        {"id": "LOC-14", "name": "Southwest Fleet Station", "type": "Station", "demand_weight": 3.5, "latitude": 12.9200, "longitude": 77.5550},
        {"id": "LOC-15", "name": "East Expressway Tollway", "type": "Highway_Junction", "demand_weight": 3.0, "latitude": 12.9850, "longitude": 77.6550},
        {"id": "LOC-16", "name": "Isolated River Peninsula", "type": "Residential", "demand_weight": 1.5, "latitude": 12.9100, "longitude": 77.6900}
    ]
    with open(locations_file, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["id", "name", "type", "demand_weight", "latitude", "longitude"])
        writer.writeheader()
        writer.writerows(locations_data)

    # 2. road_network.csv (28 road segments)
    roads_file = target_dir / "road_network.csv"
    roads_data = [
        {"road_id": "RD-01", "source": "LOC-01", "destination": "LOC-03", "distance_km": 2.2, "speed_limit_kmh": 45.0, "travel_time_min": 2.93, "is_closed": 0, "closure_reason": "", "is_bidirectional": 1},
        {"road_id": "RD-02", "source": "LOC-01", "destination": "LOC-10", "distance_km": 2.5, "speed_limit_kmh": 40.0, "travel_time_min": 3.75, "is_closed": 0, "closure_reason": "", "is_bidirectional": 1},
        {"road_id": "RD-03", "source": "LOC-01", "destination": "LOC-13", "distance_km": 2.0, "speed_limit_kmh": 35.0, "travel_time_min": 3.43, "is_closed": 0, "closure_reason": "", "is_bidirectional": 1},
        {"road_id": "RD-04", "source": "LOC-02", "destination": "LOC-07", "distance_km": 3.1, "speed_limit_kmh": 55.0, "travel_time_min": 3.38, "is_closed": 0, "closure_reason": "", "is_bidirectional": 1},
        {"road_id": "RD-05", "source": "LOC-02", "destination": "LOC-10", "distance_km": 3.4, "speed_limit_kmh": 45.0, "travel_time_min": 4.53, "is_closed": 0, "closure_reason": "", "is_bidirectional": 1},
        {"road_id": "RD-06", "source": "LOC-02", "destination": "LOC-01", "distance_km": 3.8, "speed_limit_kmh": 50.0, "travel_time_min": 4.56, "is_closed": 0, "closure_reason": "", "is_bidirectional": 1},
        {"road_id": "RD-07", "source": "LOC-03", "destination": "LOC-04", "distance_km": 4.0, "speed_limit_kmh": 50.0, "travel_time_min": 4.80, "is_closed": 0, "closure_reason": "", "is_bidirectional": 1},
        {"road_id": "RD-08", "source": "LOC-03", "destination": "LOC-12", "distance_km": 4.5, "speed_limit_kmh": 45.0, "travel_time_min": 6.00, "is_closed": 0, "closure_reason": "", "is_bidirectional": 1},
        {"road_id": "RD-09", "source": "LOC-03", "destination": "LOC-15", "distance_km": 5.2, "speed_limit_kmh": 60.0, "travel_time_min": 5.20, "is_closed": 0, "closure_reason": "", "is_bidirectional": 1},
        {"road_id": "RD-10", "source": "LOC-04", "destination": "LOC-08", "distance_km": 4.8, "speed_limit_kmh": 55.0, "travel_time_min": 5.24, "is_closed": 0, "closure_reason": "", "is_bidirectional": 1},
        {"road_id": "RD-11", "source": "LOC-04", "destination": "LOC-15", "distance_km": 3.3, "speed_limit_kmh": 50.0, "travel_time_min": 3.96, "is_closed": 0, "closure_reason": "", "is_bidirectional": 1},
        {"road_id": "RD-12", "source": "LOC-05", "destination": "LOC-08", "distance_km": 5.0, "speed_limit_kmh": 50.0, "travel_time_min": 6.00, "is_closed": 0, "closure_reason": "", "is_bidirectional": 1},
        {"road_id": "RD-13", "source": "LOC-05", "destination": "LOC-12", "distance_km": 2.8, "speed_limit_kmh": 40.0, "travel_time_min": 4.20, "is_closed": 0, "closure_reason": "", "is_bidirectional": 1},
        {"road_id": "RD-14", "source": "LOC-05", "destination": "LOC-14", "distance_km": 3.5, "speed_limit_kmh": 45.0, "travel_time_min": 4.67, "is_closed": 0, "closure_reason": "", "is_bidirectional": 1},
        {"road_id": "RD-15", "source": "LOC-06", "destination": "LOC-10", "distance_km": 4.2, "speed_limit_kmh": 45.0, "travel_time_min": 5.60, "is_closed": 0, "closure_reason": "", "is_bidirectional": 1},
        {"road_id": "RD-16", "source": "LOC-06", "destination": "LOC-11", "distance_km": 4.0, "speed_limit_kmh": 40.0, "travel_time_min": 6.00, "is_closed": 0, "closure_reason": "", "is_bidirectional": 1},
        {"road_id": "RD-17", "source": "LOC-06", "destination": "LOC-13", "distance_km": 3.2, "speed_limit_kmh": 40.0, "travel_time_min": 4.80, "is_closed": 0, "closure_reason": "", "is_bidirectional": 1},
        {"road_id": "RD-18", "source": "LOC-06", "destination": "LOC-14", "distance_km": 4.5, "speed_limit_kmh": 50.0, "travel_time_min": 5.40, "is_closed": 0, "closure_reason": "", "is_bidirectional": 1},
        {"road_id": "RD-19", "source": "LOC-07", "destination": "LOC-11", "distance_km": 5.5, "speed_limit_kmh": 60.0, "travel_time_min": 5.50, "is_closed": 0, "closure_reason": "", "is_bidirectional": 1},
        {"road_id": "RD-20", "source": "LOC-07", "destination": "LOC-15", "distance_km": 5.0, "speed_limit_kmh": 65.0, "travel_time_min": 4.62, "is_closed": 0, "closure_reason": "", "is_bidirectional": 1},
        {"road_id": "RD-21", "source": "LOC-08", "destination": "LOC-09", "distance_km": 4.1, "speed_limit_kmh": 45.0, "travel_time_min": 5.47, "is_closed": 0, "closure_reason": "", "is_bidirectional": 1},
        {"road_id": "RD-22", "source": "LOC-08", "destination": "LOC-12", "distance_km": 3.0, "speed_limit_kmh": 45.0, "travel_time_min": 4.00, "is_closed": 0, "closure_reason": "", "is_bidirectional": 1},
        {"road_id": "RD-23", "source": "LOC-09", "destination": "LOC-15", "distance_km": 4.8, "speed_limit_kmh": 50.0, "travel_time_min": 5.76, "is_closed": 0, "closure_reason": "", "is_bidirectional": 1},
        {"road_id": "RD-24", "source": "LOC-09", "destination": "LOC-16", "distance_km": 5.5, "speed_limit_kmh": 40.0, "travel_time_min": 8.25, "is_closed": 0, "closure_reason": "", "is_bidirectional": 1},
        {"road_id": "RD-25", "source": "LOC-10", "destination": "LOC-11", "distance_km": 3.5, "speed_limit_kmh": 40.0, "travel_time_min": 5.25, "is_closed": 0, "closure_reason": "", "is_bidirectional": 1},
        {"road_id": "RD-26", "source": "LOC-10", "destination": "LOC-13", "distance_km": 1.8, "speed_limit_kmh": 30.0, "travel_time_min": 3.60, "is_closed": 0, "closure_reason": "", "is_bidirectional": 1},
        {"road_id": "RD-27", "source": "LOC-12", "destination": "LOC-13", "distance_km": 3.9, "speed_limit_kmh": 40.0, "travel_time_min": 5.85, "is_closed": 0, "closure_reason": "", "is_bidirectional": 1},
        {"road_id": "RD-28", "source": "LOC-13", "destination": "LOC-14", "distance_km": 4.0, "speed_limit_kmh": 45.0, "travel_time_min": 5.33, "is_closed": 0, "closure_reason": "", "is_bidirectional": 1}
    ]
    with open(roads_file, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["road_id", "source", "destination", "distance_km", "speed_limit_kmh", "travel_time_min", "is_closed", "closure_reason", "is_bidirectional"])
        writer.writeheader()
        writer.writerows(roads_data)

    # 3. road_closures.csv (road closure records)
    closures_file = target_dir / "road_closures.csv"
    closures_data = [
        {"id": 1, "road_id": "RD-01", "closed_at": "2026-10-20 08:30:00", "reopened_at": "", "reason": "Major water main rupture", "is_active": 0},
        {"id": 2, "road_id": "RD-07", "closed_at": "2026-10-20 09:15:00", "reopened_at": "", "reason": "Overturned freight truck", "is_active": 0},
        {"id": 3, "road_id": "RD-24", "closed_at": "2026-10-20 11:00:00", "reopened_at": "", "reason": "Peninsula drawbridge maintenance", "is_active": 0}
    ]
    with open(closures_file, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["id", "road_id", "closed_at", "reopened_at", "reason", "is_active"])
        writer.writeheader()
        writer.writerows(closures_data)

    # 4. ambulances.csv (8 municipal emergency vehicles)
    ambulances_file = target_dir / "ambulances.csv"
    ambulances_data = [
        {"id": "AMB-01", "call_sign": "Medic-Alpha", "current_location": "LOC-01", "status": "Available", "station_id": "LOC-01", "fuel_level": 100.0, "assigned_incident_id": "", "busy_until_time": 0.0},
        {"id": "AMB-02", "call_sign": "Medic-Bravo", "current_location": "LOC-02", "status": "Available", "station_id": "LOC-02", "fuel_level": 95.0, "assigned_incident_id": "", "busy_until_time": 0.0},
        {"id": "AMB-03", "call_sign": "Medic-Charlie", "current_location": "LOC-05", "status": "Available", "station_id": "LOC-05", "fuel_level": 90.0, "assigned_incident_id": "", "busy_until_time": 0.0},
        {"id": "AMB-04", "call_sign": "Medic-Delta", "current_location": "LOC-06", "status": "Available", "station_id": "LOC-06", "fuel_level": 88.0, "assigned_incident_id": "", "busy_until_time": 0.0},
        {"id": "AMB-05", "call_sign": "Medic-Echo", "current_location": "LOC-10", "status": "Available", "station_id": "LOC-10", "fuel_level": 92.0, "assigned_incident_id": "", "busy_until_time": 0.0},
        {"id": "AMB-06", "call_sign": "Medic-Foxtrot", "current_location": "LOC-12", "status": "Available", "station_id": "LOC-12", "fuel_level": 85.0, "assigned_incident_id": "", "busy_until_time": 0.0},
        {"id": "AMB-07", "call_sign": "Medic-Golf", "current_location": "LOC-14", "status": "Available", "station_id": "LOC-14", "fuel_level": 98.0, "assigned_incident_id": "", "busy_until_time": 0.0},
        {"id": "AMB-08", "call_sign": "Medic-Hotel", "current_location": "LOC-08", "status": "Available", "station_id": "LOC-08", "fuel_level": 91.0, "assigned_incident_id": "", "busy_until_time": 0.0}
    ]
    with open(ambulances_file, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["id", "call_sign", "current_location", "status", "station_id", "fuel_level", "assigned_incident_id", "busy_until_time"])
        writer.writeheader()
        writer.writerows(ambulances_data)

    # 5. incidents.csv (35 realistic incidents)
    incidents_file = target_dir / "incidents.csv"
    incidents_data = [
        {"id": "INC-001", "location": "LOC-03", "severity": "Medium", "arrival_time": 2.0, "waiting_time": 0.0, "description": "Minor kitchen grease fire burn", "status": "Pending", "priority_score": 50.0, "severity_weight": 25.0, "waiting_time_weight": 2.0, "assigned_ambulance_id": ""},
        {"id": "INC-002", "location": "LOC-04", "severity": "Critical", "arrival_time": 4.5, "waiting_time": 0.0, "description": "Pedestrian struck at crosswalk", "status": "Pending", "priority_score": 100.0, "severity_weight": 25.0, "waiting_time_weight": 2.0, "assigned_ambulance_id": ""},
        {"id": "INC-003", "location": "LOC-13", "severity": "Low", "arrival_time": 6.0, "waiting_time": 0.0, "description": "Senior citizen trip and ankle sprain", "status": "Pending", "priority_score": 25.0, "severity_weight": 25.0, "waiting_time_weight": 2.0, "assigned_ambulance_id": ""},
        {"id": "INC-004", "location": "LOC-08", "severity": "High", "arrival_time": 8.0, "waiting_time": 0.0, "description": "Sudden onset severe chest pain and diaphoresis", "status": "Pending", "priority_score": 75.0, "severity_weight": 25.0, "waiting_time_weight": 2.0, "assigned_ambulance_id": ""},
        {"id": "INC-005", "location": "LOC-07", "severity": "Medium", "arrival_time": 10.5, "waiting_time": 0.0, "description": "Motorcycle slip on wet junction tarmac", "status": "Pending", "priority_score": 50.0, "severity_weight": 25.0, "waiting_time_weight": 2.0, "assigned_ambulance_id": ""},
        {"id": "INC-006", "location": "LOC-11", "severity": "Critical", "arrival_time": 12.0, "waiting_time": 0.0, "description": "Anaphylactic shock following wasp sting swarm", "status": "Pending", "priority_score": 100.0, "severity_weight": 25.0, "waiting_time_weight": 2.0, "assigned_ambulance_id": ""},
        {"id": "INC-007", "location": "LOC-06", "severity": "High", "arrival_time": 14.0, "waiting_time": 0.0, "description": "Industrial hydraulic press pinch injury", "status": "Pending", "priority_score": 75.0, "severity_weight": 25.0, "waiting_time_weight": 2.0, "assigned_ambulance_id": ""},
        {"id": "INC-008", "location": "LOC-15", "severity": "Low", "arrival_time": 15.5, "waiting_time": 0.0, "description": "Driver feeling lightheaded at tollbooth", "status": "Pending", "priority_score": 25.0, "severity_weight": 25.0, "waiting_time_weight": 2.0, "assigned_ambulance_id": ""},
        {"id": "INC-009", "location": "LOC-09", "severity": "Medium", "arrival_time": 18.0, "waiting_time": 0.0, "description": "Dockworker slip and dislocated shoulder", "status": "Pending", "priority_score": 50.0, "severity_weight": 25.0, "waiting_time_weight": 2.0, "assigned_ambulance_id": ""},
        {"id": "INC-010", "location": "LOC-10", "severity": "Critical", "arrival_time": 20.0, "waiting_time": 0.0, "description": "Unconscious passenger collapsed on concourse", "status": "Pending", "priority_score": 100.0, "severity_weight": 25.0, "waiting_time_weight": 2.0, "assigned_ambulance_id": ""},
        {"id": "INC-011", "location": "LOC-04", "severity": "High", "arrival_time": 22.5, "waiting_time": 0.0, "description": "Severe asthma attack unresponsive to inhaler", "status": "Pending", "priority_score": 75.0, "severity_weight": 25.0, "waiting_time_weight": 2.0, "assigned_ambulance_id": ""},
        {"id": "INC-012", "location": "LOC-03", "severity": "Low", "arrival_time": 25.0, "waiting_time": 0.0, "description": "Supermarket customer minor laceration", "status": "Pending", "priority_score": 25.0, "severity_weight": 25.0, "waiting_time_weight": 2.0, "assigned_ambulance_id": ""},
        {"id": "INC-013", "location": "LOC-12", "severity": "Medium", "arrival_time": 27.0, "waiting_time": 0.0, "description": "Bicycle rider collided with roadside curb", "status": "Pending", "priority_score": 50.0, "severity_weight": 25.0, "waiting_time_weight": 2.0, "assigned_ambulance_id": ""},
        {"id": "INC-014", "location": "LOC-02", "severity": "Critical", "arrival_time": 29.5, "waiting_time": 0.0, "description": "Sudden cardiac arrest at fitness studio", "status": "Pending", "priority_score": 100.0, "severity_weight": 25.0, "waiting_time_weight": 2.0, "assigned_ambulance_id": ""},
        {"id": "INC-015", "location": "LOC-14", "severity": "Low", "arrival_time": 31.0, "waiting_time": 0.0, "description": "Minor nosebleed persistent over 30 mins", "status": "Pending", "priority_score": 25.0, "severity_weight": 25.0, "waiting_time_weight": 2.0, "assigned_ambulance_id": ""},
        {"id": "INC-016", "location": "LOC-08", "severity": "High", "arrival_time": 33.0, "waiting_time": 0.0, "description": "Acute severe allergic facial swelling", "status": "Pending", "priority_score": 75.0, "severity_weight": 25.0, "waiting_time_weight": 2.0, "assigned_ambulance_id": ""},
        {"id": "INC-017", "location": "LOC-06", "severity": "Critical", "arrival_time": 35.0, "waiting_time": 0.0, "description": "Chemical vapor inhalation with respiratory failure", "status": "Pending", "priority_score": 100.0, "severity_weight": 25.0, "waiting_time_weight": 2.0, "assigned_ambulance_id": ""},
        {"id": "INC-018", "location": "LOC-13", "severity": "Medium", "arrival_time": 37.0, "waiting_time": 0.0, "description": "High fever with shaking chills in young adult", "status": "Pending", "priority_score": 50.0, "severity_weight": 25.0, "waiting_time_weight": 2.0, "assigned_ambulance_id": ""},
        {"id": "INC-019", "location": "LOC-07", "severity": "High", "arrival_time": 39.5, "waiting_time": 0.0, "description": "Two-vehicle collision with moderate entrapment", "status": "Pending", "priority_score": 75.0, "severity_weight": 25.0, "waiting_time_weight": 2.0, "assigned_ambulance_id": ""},
        {"id": "INC-020", "location": "LOC-01", "severity": "Low", "arrival_time": 41.0, "waiting_time": 0.0, "description": "Visitor fainting episode in reception area", "status": "Pending", "priority_score": 25.0, "severity_weight": 25.0, "waiting_time_weight": 2.0, "assigned_ambulance_id": ""},
        {"id": "INC-021", "location": "LOC-15", "severity": "Critical", "arrival_time": 43.0, "waiting_time": 0.0, "description": "Highway rollover with multiple critically injured", "status": "Pending", "priority_score": 100.0, "severity_weight": 25.0, "waiting_time_weight": 2.0, "assigned_ambulance_id": ""},
        {"id": "INC-022", "location": "LOC-05", "severity": "Medium", "arrival_time": 45.0, "waiting_time": 0.0, "description": "Elderly patient feeling confused and dehydrated", "status": "Pending", "priority_score": 50.0, "severity_weight": 25.0, "waiting_time_weight": 2.0, "assigned_ambulance_id": ""},
        {"id": "INC-023", "location": "LOC-11", "severity": "Low", "arrival_time": 47.0, "waiting_time": 0.0, "description": "Child finger caught in residential door frame", "status": "Pending", "priority_score": 25.0, "severity_weight": 25.0, "waiting_time_weight": 2.0, "assigned_ambulance_id": ""},
        {"id": "INC-024", "location": "LOC-09", "severity": "High", "arrival_time": 49.0, "waiting_time": 0.0, "description": "Deep puncture wound from maritime machinery", "status": "Pending", "priority_score": 75.0, "severity_weight": 25.0, "waiting_time_weight": 2.0, "assigned_ambulance_id": ""},
        {"id": "INC-025", "location": "LOC-12", "severity": "Critical", "arrival_time": 51.0, "waiting_time": 0.0, "description": "Child choking with complete airway blockage", "status": "Pending", "priority_score": 100.0, "severity_weight": 25.0, "waiting_time_weight": 2.0, "assigned_ambulance_id": ""},
        {"id": "INC-026", "location": "LOC-03", "severity": "Medium", "arrival_time": 53.0, "waiting_time": 0.0, "description": "Escalator stumble with deep shin laceration", "status": "Pending", "priority_score": 50.0, "severity_weight": 25.0, "waiting_time_weight": 2.0, "assigned_ambulance_id": ""},
        {"id": "INC-027", "location": "LOC-10", "severity": "High", "arrival_time": 55.0, "waiting_time": 0.0, "description": "Severe abdominal cramping with signs of shock", "status": "Pending", "priority_score": 75.0, "severity_weight": 25.0, "waiting_time_weight": 2.0, "assigned_ambulance_id": ""},
        {"id": "INC-028", "location": "LOC-04", "severity": "Low", "arrival_time": 57.0, "waiting_time": 0.0, "description": "Gardener allergic rash on forearms", "status": "Pending", "priority_score": 25.0, "severity_weight": 25.0, "waiting_time_weight": 2.0, "assigned_ambulance_id": ""},
        {"id": "INC-029", "location": "LOC-08", "severity": "Medium", "arrival_time": 59.0, "waiting_time": 0.0, "description": "Office worker sudden migraine and visual aura", "status": "Pending", "priority_score": 50.0, "severity_weight": 25.0, "waiting_time_weight": 2.0, "assigned_ambulance_id": ""},
        {"id": "INC-030", "location": "LOC-14", "severity": "Critical", "arrival_time": 61.0, "waiting_time": 0.0, "description": "Major structural collapse with multiple trauma", "status": "Pending", "priority_score": 100.0, "severity_weight": 25.0, "waiting_time_weight": 2.0, "assigned_ambulance_id": ""},
        {"id": "INC-031", "location": "LOC-13", "severity": "High", "arrival_time": 63.5, "waiting_time": 0.0, "description": "Suspected acute appendicitis with high pain", "status": "Pending", "priority_score": 75.0, "severity_weight": 25.0, "waiting_time_weight": 2.0, "assigned_ambulance_id": ""},
        {"id": "INC-032", "location": "LOC-07", "severity": "Low", "arrival_time": 65.0, "waiting_time": 0.0, "description": "Minor abrasion from falling off scooter", "status": "Pending", "priority_score": 25.0, "severity_weight": 25.0, "waiting_time_weight": 2.0, "assigned_ambulance_id": ""},
        {"id": "INC-033", "location": "LOC-06", "severity": "Medium", "arrival_time": 67.0, "waiting_time": 0.0, "description": "Factory worker severe heat exhaustion", "status": "Pending", "priority_score": 50.0, "severity_weight": 25.0, "waiting_time_weight": 2.0, "assigned_ambulance_id": ""},
        {"id": "INC-034", "location": "LOC-11", "severity": "High", "arrival_time": 69.0, "waiting_time": 0.0, "description": "Elderly patient with sudden unilateral paralysis", "status": "Pending", "priority_score": 75.0, "severity_weight": 25.0, "waiting_time_weight": 2.0, "assigned_ambulance_id": ""},
        {"id": "INC-035", "location": "LOC-02", "severity": "Critical", "arrival_time": 71.0, "waiting_time": 0.0, "description": "Active cardiac arrest undergoing bystander CPR", "status": "Pending", "priority_score": 100.0, "severity_weight": 25.0, "waiting_time_weight": 2.0, "assigned_ambulance_id": ""}
    ]
    with open(incidents_file, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["id", "location", "severity", "arrival_time", "waiting_time", "description", "status", "priority_score", "severity_weight", "waiting_time_weight", "assigned_ambulance_id"])
        writer.writeheader()
        writer.writerows(incidents_data)

    # 6. scenarios.csv (Predefined Scenario definitions A-H)
    scenarios_file = target_dir / "scenarios.csv"
    scenarios_data = [
        {"id": "SCENARIO_A", "name": "Normal Urban Operation", "description": "Standard distributed emergencies across municipal sectors with full fleet readiness.", "incident_count": 4, "fleet_count": 8},
        {"id": "SCENARIO_B", "name": "Simultaneous Multi-Incident Surge", "description": "High surge rate of 5 calls within a 3-minute window testing concurrent demand.", "incident_count": 5, "fleet_count": 8},
        {"id": "SCENARIO_C", "name": "Critical Emergency Contention", "description": "Life-threatening Critical incident competing with lower-severity calls.", "incident_count": 4, "fleet_count": 8},
        {"id": "SCENARIO_D", "name": "Coverage Loss Dilemma", "description": "Dispatching sole local ambulance creates a critical vacuum across high-demand zones.", "incident_count": 2, "fleet_count": 5},
        {"id": "SCENARIO_E", "name": "Major Arterial Road Disruption", "description": "Critical road segments RD-01 and RD-07 closed, forcing detours and rerouting.", "incident_count": 2, "fleet_count": 8},
        {"id": "SCENARIO_F", "name": "Isolated Unreachable Destination", "description": "Drawbridge failure severs peninsula access, testing infeasible dispatch handling.", "incident_count": 2, "fleet_count": 8},
        {"id": "SCENARIO_G", "name": "All Ambulances Busy Fleet Depletion", "description": "All units engaged on missions; validates queue persistence and priority ranking.", "incident_count": 2, "fleet_count": 8},
        {"id": "SCENARIO_H", "name": "Counterfactual Look-Ahead Consequence", "description": "Evaluates strategic preservation of local ambulance for impending critical emergency.", "incident_count": 2, "fleet_count": 3}
    ]
    with open(scenarios_file, "w", newline="", encoding="utf-8") as f:
        writer = csv.DictWriter(f, fieldnames=["id", "name", "description", "incident_count", "fleet_count"])
        writer.writeheader()
        writer.writerows(scenarios_data)

    print("All CSV datasets generated successfully.")

if __name__ == "__main__":
    generate_all_datasets()
