@echo off
setlocal enabledelayedexpansion

:: 1. Navigate to the project root directory
cd /d "%~dp0"

:: 2. Check if this is a parent/wrapper folder containing ResQRoute_Final
if exist "%~dp0ResQRoute_Final\setup.bat" (
    cd /d "%~dp0ResQRoute_Final"
    call setup.bat %*
    exit /b !ERRORLEVEL!
)

echo =====================================================================
echo ResQRoute: Intelligent Emergency Vehicle Dispatch System
echo Environment Setup, Dependency Installation and Build Script
echo =====================================================================
echo.

:: 3. Check Python installation and version
echo [*] Checking Python installation...
where python >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo [ERROR] Python was not found in your system PATH.
    echo.
    echo Please install Python 3.10 or higher from:
    echo   https://www.python.org/downloads/
    echo.
    echo IMPORTANT: Make sure to check the box "Add Python to PATH" during installation.
    echo.
    pause
    exit /b 1
)

for /f "delims=" %%v in ('python --version 2^>^&1') do set "PY_VER=%%v"
echo [OK] Detected %PY_VER%

:: Check Python version >= 3.9
python -c "import sys; exit(0 if sys.version_info >= (3, 9) else 1)" >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo [ERROR] %PY_VER% is not supported. ResQRoute requires Python 3.9 or higher.
    echo Please update your Python installation.
    pause
    exit /b 1
)

:: 4. Create Python virtual environment (.venv)
if not exist ".venv\Scripts\python.exe" (
    echo [*] Creating project-specific virtual environment in .venv...
    python -m venv .venv
    if !ERRORLEVEL! NEQ 0 (
        echo [ERROR] Failed to create virtual environment in .venv.
        echo Verify write permissions in "%cd%".
        pause
        exit /b 1
    )
    echo [OK] Virtual environment created successfully.
) else (
    echo [OK] Virtual environment already exists (.venv).
)

:: 5. Upgrade pip and install dependencies
if not exist "requirements.txt" (
    echo [ERROR] requirements.txt not found in "%cd%".
    pause
    exit /b 1
)

echo [*] Installing and verifying required Python packages...
".venv\Scripts\python.exe" -m pip install --upgrade pip >nul 2>&1
".venv\Scripts\python.exe" -m pip install -r requirements.txt
if %ERRORLEVEL% NEQ 0 (
    echo [ERROR] Failed to install Python dependencies from requirements.txt.
    echo Please verify your internet connection.
    pause
    exit /b 1
)
echo [OK] All Python packages installed (Streamlit, Pandas, NumPy, Plotly, Pytest, CMake).

:: Ensure .venv Scripts and common compiler paths are in PATH
set "PATH=%cd%\.venv\Scripts;%PATH%"
where g++ >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    if exist "C:\Program Files (x86)\Embarcadero\Dev-Cpp\TDM-GCC-64\bin\g++.exe" (
        set "PATH=C:\Program Files (x86)\Embarcadero\Dev-Cpp\TDM-GCC-64\bin;%PATH%"
    )
)

:: 6. Check C++17 compiler and compile C++ engine
echo.
echo [*] Checking C++17 compiler...
where g++ >nul 2>&1
if %ERRORLEVEL% EQU 0 (
    for /f "delims=" %%g in ('g++ --version 2^>^&1') do (
        set "GXX_VER=%%g"
        goto :found_gxx
    )
)
:found_gxx
if defined GXX_VER (
    echo [OK] Detected C++ compiler: !GXX_VER!
) else (
    echo [WARNING] No g++ compiler directly detected in PATH.
    echo If pre-compiled binary is present, it will be used automatically.
)

echo [*] Building C++17 Core Engine and Test Suite...
if exist "cpp_engine\build_engine.bat" (
    cd cpp_engine
    call build_engine.bat
    if !ERRORLEVEL! NEQ 0 (
        if exist "resqroute_engine.exe" (
            echo [INFO] Pre-compiled resqroute_engine.exe is available and will be used.
        ) else (
            echo [ERROR] C++ Engine build failed. Review compiler output above.
            cd /d "%~dp0"
            pause
            exit /b 1
        )
    )
    cd /d "%~dp0"
    echo [OK] C++17 Core Engine ready and verified.
)

:: 7. Initialize SQLite database and populate seed datasets
echo.
echo [*] Initializing SQLite database and loading seed data...
".venv\Scripts\python.exe" -c "from database import init_db; from data_manager import data_manager; init_db(); data_manager.load_csv_to_db(overwrite=True)"
if %ERRORLEVEL% NEQ 0 (
    echo [ERROR] Database initialization failed.
    pause
    exit /b 1
)
echo [OK] SQLite database initialized at database\resqroute.db.

:: 8. Run self-tests (Python & C++)
echo.
echo [*] Running full system verification tests...
".venv\Scripts\python.exe" -m pytest tests -q
if %ERRORLEVEL% NEQ 0 (
    echo [WARNING] Some automated tests reported issues. Review test output above.
) else (
    echo [OK] All system unit and integration tests passed!
)

echo.
echo =====================================================================
echo [SUCCESS] ResQRoute Setup Completed Successfully!
echo =====================================================================
echo All components are configured and ready for execution.
echo.
echo To start the ResQRoute application, execute:
echo     .\run.bat
echo =====================================================================
echo.
pause
endlocal
