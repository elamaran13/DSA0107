import sys
from pathlib import Path
import streamlit as st

# Add project root to sys.path for robust portable imports
PROJECT_ROOT = Path(__file__).resolve().parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from database import init_db
from data_manager import data_manager
from cpp_bridge import engine_bridge

from ui.theme import apply_global_styles
from ui.dashboard import render_dashboard
from ui.incidents_page import render_incidents_page
from ui.ambulances_page import render_ambulances_page
from ui.dispatch_page import render_dispatch_page
from ui.road_network_page import render_road_network_page
from ui.evaluation_page import render_evaluation_page

# Page Configuration
st.set_page_config(
    page_title="ResQRoute | Intelligent Emergency Vehicle Dispatch",
    page_icon="🚑",
    layout="wide",
    initial_sidebar_state="expanded",
)

# Apply high-contrast theme across all components
apply_global_styles()


@st.cache_resource
def bootstrap_application():
    init_db()
    data_manager.load_csv_to_db()
    return True


bootstrap_application()

NAV_PAGES = [
    "📊 Dashboard",
    "🚨 Emergency Management",
    "🚑 Ambulance Management",
    "🧠 Intelligent Dispatch",
    "🗺️ Route and Coverage",
    "📈 Performance Analysis",
]

# Sidebar Navigation (#10243A Dark Navy)
with st.sidebar:
    st.markdown(
        """
        <div style="padding: 4px 0 8px 0;">
            <div style="font-size: 1.55rem; font-weight: 800; color: #FFFFFF; letter-spacing: -0.01em;">
                🚑 ResQRoute
            </div>
            <div style="font-size: 0.82rem; color: #FFFFFF; line-height: 1.35; margin-top: 4px;">
                Intelligent Emergency Vehicle Dispatch &amp; Route Prioritization System
            </div>
        </div>
        """,
        unsafe_allow_html=True,
    )

    st.markdown("---")
    st.markdown(
        "<div style='font-size: 0.76rem; font-weight: 700; color: #FFFFFF; text-transform: uppercase; letter-spacing: 0.06em; margin-bottom: 6px;'>Navigation</div>",
        unsafe_allow_html=True,
    )
    menu_selection = st.radio(
        "Navigation Menu:",
        NAV_PAGES,
        index=0,
        label_visibility="collapsed",
    )

    st.markdown("---")
    st.markdown(
        "<div style='font-size: 0.76rem; font-weight: 700; color: #FFFFFF; text-transform: uppercase; letter-spacing: 0.06em; margin-bottom: 6px;'>System Telemetry</div>",
        unsafe_allow_html=True,
    )

    ping_res = engine_bridge.ping()
    if ping_res.get("status") == "ok":
        st.success("🟢 C++17 Engine: Active")
        st.caption(f"Core: {ping_res.get('engine', 'ResQRoute C++17 Core')}")
    else:
        st.error("🔴 C++ Engine: Offline")
        if st.button("🛠️ Build C++ Engine", use_container_width=True):
            ok, msg = engine_bridge.compile_engine()
            if ok:
                st.success(msg)
                st.rerun()
            else:
                st.error(msg)

    st.info("🗄️ Storage: SQLite Active")

    with st.expander("🛠️ Maintenance & Reset", expanded=False):
        if st.button("🔄 Reset Demo Data", use_container_width=True):
            data_manager.load_csv_to_db(overwrite=True)
            st.success("Demonstration data reloaded from CSV.")
            st.rerun()

    st.markdown("---")
    st.caption(
        "Simulation Environment: Algorithmic decision-support simulation for dispatch optimization and routing analysis."
    )

# Simulation Notice
st.markdown(
    "<div class='sim-disclaimer'>ℹ️ <b>Operational Simulation Mode:</b> All incident locations, emergency calls, and response metrics are computed dynamically by the C++ engine and SQLite database.</div>",
    unsafe_allow_html=True,
)

# Route to selected page
if menu_selection == "📊 Dashboard":
    render_dashboard()
elif menu_selection == "🚨 Emergency Management":
    render_incidents_page()
elif menu_selection == "🚑 Ambulance Management":
    render_ambulances_page()
elif menu_selection == "🧠 Intelligent Dispatch":
    render_dispatch_page()
elif menu_selection == "🗺️ Route and Coverage":
    render_road_network_page()
elif menu_selection == "📈 Performance Analysis":
    render_evaluation_page()
