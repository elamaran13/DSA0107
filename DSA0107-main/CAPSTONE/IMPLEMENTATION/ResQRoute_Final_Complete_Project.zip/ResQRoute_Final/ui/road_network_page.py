import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from services.road_service import road_service
from services.ambulance_service import ambulance_service
from ui.theme import (
    THEME_COLORS,
    render_page_header,
    render_kpi_card,
    render_styled_table,
    apply_plotly_theme,
    style_bar_traces,
)


def render_road_network_page():
    render_page_header(
        title="Route Optimization, Road Network & Coverage",
        subtitle="Urban transportation topology, C++ Dijkstra shortest-path routing, dynamic road closures, detour impact analysis, and regional coverage assessment.",
        module_badge="Module 3 • Dynamic Routing & Coverage Assessment",
    )

    locations = road_service.get_locations()
    roads = road_service.get_roads()
    closures = road_service.get_road_closures()
    ambulances = ambulance_service.get_all_ambulances()

    tab_map, tab_route, tab_closures, tab_coverage = st.tabs([
        "🗺️ Interactive City Network Map",
        "🧭 Dijkstra Route & Detour Calculator",
        "🚧 Road Closure Management",
        "📡 Regional Ambulance Coverage",
    ])

    with tab_map:
        st.markdown("#### Urban Transportation Graph Topology")

        loc_lookup = {l["id"]: l for l in locations}
        fig = go.Figure()

        open_legend_added = False
        closed_legend_added = False

        # Draw roads (edges)
        for r in roads:
            src = loc_lookup.get(r["source"])
            dst = loc_lookup.get(r["destination"])
            if not src or not dst:
                continue

            is_closed = bool(r["is_closed"])
            edge_color = THEME_COLORS["critical"] if is_closed else "#4A6B8A"
            edge_width = 3.5 if is_closed else 2.2
            dash_style = "dash" if is_closed else "solid"

            show_leg = False
            leg_name = ""
            if is_closed and not closed_legend_added:
                show_leg = True
                leg_name = "Closed Road Segment"
                closed_legend_added = True
            elif not is_closed and not open_legend_added:
                show_leg = True
                leg_name = "Open Road Corridor"
                open_legend_added = True

            fig.add_trace(
                go.Scatter(
                    x=[src["longitude"], dst["longitude"]],
                    y=[src["latitude"], dst["latitude"]],
                    mode="lines",
                    line=dict(color=edge_color, width=edge_width, dash=dash_style),
                    hoverinfo="text",
                    text=(
                        f"<b>Road {r['road_id']}</b> ({r['source']} ➔ {r['destination']})<br>"
                        f"Distance: {r['distance_km']} km | Travel Time: {r['travel_time_min']:.1f} min<br>"
                        f"Status: {'CLOSED' if is_closed else 'OPEN'}"
                    ),
                    name=leg_name,
                    showlegend=show_leg,
                )
            )

        # Draw locations (nodes)
        node_x = [l["longitude"] for l in locations]
        node_y = [l["latitude"] for l in locations]
        node_text = [
            f"<b>{l['id']}</b>: {l['name']}<br>Type: {l['type']}<br>Demand Weight: {l['demand_weight']}"
            for l in locations
        ]

        color_type_map = {
            "Hospital": "#DC3545",
            "Station": "#174A78",
            "Commercial": "#F59E0B",
            "Residential": "#198754",
            "Industrial": "#596579",
            "Highway_Junction": "#6F42C1",
        }
        node_colors = [color_type_map.get(l["type"], "#202B38") for l in locations]

        fig.add_trace(
            go.Scatter(
                x=node_x,
                y=node_y,
                mode="markers+text",
                marker=dict(size=16, color=node_colors, line=dict(width=2, color="#FFFFFF")),
                text=[l["id"] for l in locations],
                textposition="top center",
                textfont=dict(color="#142B45", size=11, family="Segoe UI"),
                hoverinfo="text",
                hovertext=node_text,
                name="Municipal Nodes",
            )
        )

        # Overlay active ambulance locations
        amb_locs = [a for a in ambulances if a["current_location"] in loc_lookup]
        amb_x = [loc_lookup[a["current_location"]]["longitude"] for a in amb_locs]
        amb_y = [loc_lookup[a["current_location"]]["latitude"] for a in amb_locs]
        amb_text = [
            f"<b>🚑 {a['id']}</b> ({a['call_sign']})<br>Base: {a['current_location']}<br>Status: {a['status']}"
            for a in amb_locs
        ]

        fig.add_trace(
            go.Scatter(
                x=amb_x,
                y=amb_y,
                mode="markers",
                marker=dict(symbol="diamond", size=13, color="#F59E0B", line=dict(width=2, color="#10243A")),
                hoverinfo="text",
                hovertext=amb_text,
                name="Ambulance Units",
            )
        )

        apply_plotly_theme(
            fig,
            title="Municipal Road Network Topology & Active Ambulance Fleet",
            height=540,
            show_legend=True,
            xaxis_title="Longitude",
            yaxis_title="Latitude",
        )
        fig.update_xaxes(showgrid=True, zeroline=False, showticklabels=True)
        fig.update_yaxes(showgrid=True, zeroline=False, showticklabels=True)
        fig.update_layout(legend=dict(orientation="h", yanchor="bottom", y=1.02, xanchor="right", x=1.0))
        st.plotly_chart(fig, use_container_width=True)
        st.caption("🔴 Red dashed lines = Closed roads. 🔵 Solid steel-blue lines = Open corridors. 🔶 Amber diamonds = Positioned ambulances.")

    with tab_route:
        st.markdown("#### C++ Dijkstra Shortest-Path & Detour Analysis")
        loc_ids = [l["id"] for l in locations]
        loc_names = {l["id"]: f"{l['id']} - {l['name']}" for l in locations}
        col_s, col_d = st.columns(2)
        with col_s:
            src_node = st.selectbox("Source Location Node:", loc_ids, index=0, format_func=lambda x: loc_names.get(x, x))
        with col_d:
            dst_node = st.selectbox("Destination Location Node:", loc_ids, index=min(2, len(loc_ids) - 1), format_func=lambda x: loc_names.get(x, x))

        ignore_cl = st.checkbox("Ignore Road Closures (Baseline Ideal Route)", value=False)

        if st.button("🧭 Compute Shortest Path via Dijkstra", type="primary"):
            res = road_service.find_route(src_node, dst_node, ignore_closures=ignore_cl)
            if res.get("success"):
                route = res["route"]
                st.success(f"Route Found: **{' ➔ '.join(route['path_nodes'])}**")
                r1, r2, r3 = st.columns(3)
                with r1:
                    render_kpi_card("Total Travel Time", f"{route['total_travel_time_min']:.2f} min", "Dijkstra optimal time", THEME_COLORS["primary_btn"])
                with r2:
                    render_kpi_card("Total Distance", f"{route['total_distance_km']:.2f} km", "Corridor length", THEME_COLORS["available"])
                with r3:
                    render_kpi_card("Edges Traversed", str(route["edges_traversed"]), "Network segments", THEME_COLORS["heading"])

                if not ignore_cl:
                    ideal_res = road_service.find_route(src_node, dst_node, ignore_closures=True)
                    if ideal_res.get("success"):
                        ideal_route = ideal_res["route"]
                        delay = route["total_travel_time_min"] - ideal_route["total_travel_time_min"]
                        if delay > 0.05:
                            st.warning(
                                f"⚠️ **Detour Impact:** Active road closures add **+{delay:.2f} minutes** and "
                                f"**+{route['total_distance_km'] - ideal_route['total_distance_km']:.2f} km** compared to the unblocked baseline."
                            )
            else:
                st.error(f"❌ Route Unreachable: {res.get('route', {}).get('status_message', 'No feasible path exists between nodes.')}")

    with tab_closures:
        st.markdown("#### Manage Road Closures & Infrastructure Disruptions")

        if closures:
            st.markdown("##### Active Road Closures")
            df_cl = pd.DataFrame(closures)[["road_id", "source", "destination", "distance_km", "reason"]].copy()
            df_cl.columns = ["Road ID", "From", "To", "Distance (km)", "Closure Reason"]
            render_styled_table(df_cl, max_rows=30)

        col_close, col_reopen = st.columns(2)

        with col_close:
            st.markdown("##### 🚧 Close Road Segment")
            road_ids = [f"{r['road_id']} ({r['source']} ➔ {r['destination']}, {r['distance_km']} km)" for r in roads if not r["is_closed"]]
            if road_ids:
                sel_road = st.selectbox("Select Road to Close:", road_ids)
                target_rid = sel_road.split(" ")[0]
                reason = st.text_input("Closure Reason:", value="Traffic accident / Emergency cordon")
                if st.button("Apply Road Closure", type="primary", use_container_width=True):
                    ok, msg = road_service.close_road(target_rid, reason)
                    if ok:
                        st.success(msg)
                        st.rerun()
            else:
                st.info("All roads are currently closed.")

        with col_reopen:
            st.markdown("##### 🟢 Reopen Road Segment")
            closed_list = [f"{r['road_id']} ({r['source']} ➔ {r['destination']}) - {r['closure_reason']}" for r in roads if r["is_closed"]]
            if closed_list:
                sel_reopen = st.selectbox("Select Road to Reopen:", closed_list)
                target_reopen_id = sel_reopen.split(" ")[0]
                if st.button("Reopen Selected Road", type="primary", use_container_width=True):
                    ok, msg = road_service.reopen_road(target_reopen_id)
                    if ok:
                        st.success(msg)
                        st.rerun()
            else:
                st.info("No roads are currently closed.")

        st.markdown("<br>", unsafe_allow_html=True)
        if st.button("🔄 Reset All Road Closures"):
            road_service.reset_closures()
            st.success("All roads reopened.")
            st.rerun()

    with tab_coverage:
        st.markdown("#### Ambulance Fleet Regional Coverage Assessment")
        thresh = st.slider("Maximum Response Travel Time Threshold (minutes):", min_value=5.0, max_value=25.0, value=10.0, step=1.0)
        cov_res = road_service.analyze_coverage(ambulances, threshold_minutes=thresh)

        c1, c2, c3 = st.columns(3)
        with c1:
            render_kpi_card("Demand-Weighted Coverage", f"{cov_res.get('weighted_coverage_pct', 0.0):.1f}%", f"Within {thresh:.0f} min threshold", THEME_COLORS["available"])
        with c2:
            render_kpi_card("Unweighted City Coverage", f"{cov_res.get('unweighted_coverage_pct', 0.0):.1f}%", "Equal-node basis", THEME_COLORS["primary_btn"])
        with c3:
            render_kpi_card(
                "Covered Nodes",
                f"{cov_res.get('covered_locations_count', 0)} / {cov_res.get('total_locations', 0)}",
                "Reachable within threshold",
                THEME_COLORS["heading"],
            )

        st.markdown("##### Reachability Breakdown by Location")
        min_times = cov_res.get("min_arrival_times", {})
        cov_rows = []
        chart_rows = []
        for loc in locations:
            lid = loc["id"]
            best_t = min_times.get(lid, -1.0)
            is_cov = lid in cov_res.get("covered_location_ids", [])
            status_lbl = "Covered" if is_cov else "Uncovered"
            cov_rows.append({
                "Location ID": lid,
                "Name": loc["name"],
                "Type": loc["type"],
                "Demand Weight": f"{loc['demand_weight']:.1f}",
                "Fastest Arrival (min)": f"{best_t:.1f}" if best_t >= 0 else "Unreachable",
                "Status": status_lbl,
            })
            if best_t >= 0:
                chart_rows.append({
                    "Location": lid,
                    "Arrival Time (min)": round(best_t, 2),
                    "Status": status_lbl,
                })

        if chart_rows:
            fig_cov_nodes = px.bar(
                pd.DataFrame(chart_rows),
                x="Location",
                y="Arrival Time (min)",
                color="Status",
                color_discrete_map={"Covered": THEME_COLORS["available"], "Uncovered": THEME_COLORS["critical"]},
                text="Arrival Time (min)",
            )
            fig_cov_nodes.add_hline(
                y=thresh,
                line_dash="dash",
                line_color=THEME_COLORS["warning"],
                annotation_text=f"Threshold ({thresh:.0f} min)",
                annotation_font=dict(color="#142B45", size=11),
            )
            apply_plotly_theme(
                fig_cov_nodes,
                title=f"Fastest Ambulance Arrival Time by Node (Threshold: {thresh:.0f} min)",
                height=340,
                show_legend=True,
                xaxis_title="Municipal Location Node",
                yaxis_title="Fastest Arrival (min)",
            )
            style_bar_traces(fig_cov_nodes, value_format=".1f", y_max_padding=1.22)
            st.plotly_chart(fig_cov_nodes, use_container_width=True)

        render_styled_table(pd.DataFrame(cov_rows), badge_columns=["Status"], max_rows=50)
