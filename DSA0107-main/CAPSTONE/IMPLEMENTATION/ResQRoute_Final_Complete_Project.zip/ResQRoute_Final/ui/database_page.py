import streamlit as st
import pandas as pd
from database import get_connection
from data_manager import data_manager
from ui.theme import render_page_header, render_styled_table


def render_database_page():
    render_page_header(
        title="Database & Dataset Management",
        subtitle="Inspect SQLite persistence tables, export operational CSV audit reports, and safely restore baseline simulation datasets.",
        module_badge="SQLite Persistence & CSV Data Manager",
    )

    tab_inspect, tab_export, tab_reset = st.tabs([
        "🔍 Table Explorer",
        "📤 CSV Exporter",
        "⚠️ System Data Reset",
    ])

    tables = [
        "incidents",
        "ambulances",
        "locations",
        "roads",
        "road_closures",
        "dispatch_decisions",
        "candidate_evaluations",
        "simulation_runs",
        "simulation_results",
        "scenario_definitions",
    ]

    with tab_inspect:
        st.markdown("#### Inspect SQLite Database Tables")
        selected_table = st.selectbox("Select Table to View:", tables)

        conn = get_connection()
        query = f"SELECT * FROM {selected_table} LIMIT 100;"
        df = pd.read_sql_query(query, conn)
        cursor = conn.cursor()
        cursor.execute(f"SELECT COUNT(*) as cnt FROM {selected_table};")
        total_records = cursor.fetchone()["cnt"]
        conn.close()

        st.write(f"Showing up to 100 rows (Total records: **{total_records}**):")
        if df.empty:
            st.info(f"Table `{selected_table}` currently has no records.")
        else:
            render_styled_table(df, max_rows=100)

    with tab_export:
        st.markdown("#### Export Data to CSV")
        table_to_export = st.selectbox("Select Table to Export:", tables, key="exp_tbl")
        if st.button("Generate Downloadable CSV", type="primary"):
            out_file = data_manager.export_table_to_csv(table_to_export)
            with open(out_file, "r", encoding="utf-8") as f:
                csv_bytes = f.read()

            st.download_button(
                label=f"⬇️ Download {table_to_export}.csv",
                data=csv_bytes,
                file_name=f"{table_to_export}_export.csv",
                mime="text/csv",
            )
            st.success(f"CSV exported successfully to `{out_file.name}`")

    with tab_reset:
        st.markdown("#### Reset Database to Baseline State")
        st.warning("⚠️ This action will clear current session records and reload the baseline sample dataset.")

        confirm_box = st.checkbox("I understand this will overwrite current session records with baseline data.")
        if st.button("Confirm and Reset Database", type="primary", disabled=not confirm_box):
            try:
                data_manager.reset_and_reload(confirm=True)
                st.success("Database restored to baseline state.")
                st.rerun()
            except Exception as e:
                st.error(f"Reset failed: {e}")
