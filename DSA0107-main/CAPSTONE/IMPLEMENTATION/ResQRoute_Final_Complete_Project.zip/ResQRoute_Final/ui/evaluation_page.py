import streamlit as st
import pandas as pd
import plotly.express as px
from services.evaluation_service import evaluation_service
from ui.theme import (
    STRATEGY_COLOR_MAP,
    THEME_COLORS,
    render_page_header,
    render_kpi_card,
    render_styled_table,
    apply_plotly_theme,
    style_bar_traces,
)


def render_evaluation_page():
    render_page_header(
        title="Multi-Scenario Performance Analysis",
        subtitle="Comparative benchmarking of Nearest-Available Ambulance, Immediate Priority-Coverage Scoring, and Counterfactual Look-Ahead Optimization across standardized scenarios.",
        module_badge="Module 3 • Dynamic Routing, Coverage & Performance Evaluation",
    )

    scenarios = evaluation_service.get_available_scenarios()
    scen_map = {f"{s['id']}: {s['name']}": s["id"] for s in scenarios}

    col_select, col_run = st.columns([3, 1])
    with col_select:
        selected_scen_label = st.selectbox(
            "Select Test Scenario:",
            list(scen_map.keys()) if scen_map else ["SCENARIO_A: Normal Operation"],
        )
        chosen_scen_id = scen_map.get(selected_scen_label, "SCENARIO_A")
    with col_run:
        st.markdown("<div style='height: 28px;'></div>", unsafe_allow_html=True)
        run_btn = st.button("▶️ Run Scenario Benchmark", type="primary", use_container_width=True)

    matching_scen = next((s for s in scenarios if s["id"] == chosen_scen_id), None)
    if matching_scen:
        closed_list = matching_scen.get("closed_roads", [])
        closed_str = ", ".join(closed_list) if closed_list else "None"
        st.markdown(
            f"""
            <div class='resq-info-card'>
                <b>Scenario Condition:</b> {matching_scen['description']}<br>
                <b>Workload:</b> {matching_scen.get('incident_count', 'N/A')} Emergencies |
                <b>Fleet:</b> {matching_scen.get('fleet_count', 'N/A')} Ambulances |
                <b>Road Closures:</b> <code>{closed_str}</code>
            </div>
            """,
            unsafe_allow_html=True,
        )

    if run_btn:
        with st.spinner(f"Running C++ simulation for {chosen_scen_id} across all 3 strategies..."):
            eval_results = evaluation_service.run_benchmark(chosen_scen_id)

        if "error" in eval_results:
            st.error(f"Scenario benchmark failed: {eval_results['error']}")
            return

        st.session_state["last_eval_results"] = eval_results

    if "last_eval_results" in st.session_state:
        eval_results = st.session_state["last_eval_results"]
        result_scen_id = eval_results.get("scenario_id", chosen_scen_id)
        strategies = eval_results.get("strategies", {})

        st.markdown("---")
        st.markdown(f"#### 📊 Benchmark Results — `{result_scen_id}`")

        look_data = strategies.get("lookahead_optimizer", {})
        near_data = strategies.get("nearest_available", {})
        imm_data = strategies.get("immediate_scoring", {})

        s1, s2, s3 = st.columns(3)
        with s1:
            render_kpi_card(
                "Nearest-Available Baseline",
                f"{near_data.get('avg_response_time_min', 0.0):.2f} min",
                f"Coverage: {near_data.get('final_remaining_coverage_pct', 0.0):.1f}% • Grey/Blue",
                accent_color=STRATEGY_COLOR_MAP["Nearest-Available Baseline"],
            )
        with s2:
            render_kpi_card(
                "Immediate Priority-Coverage",
                f"{imm_data.get('avg_response_time_min', 0.0):.2f} min",
                f"Coverage: {imm_data.get('final_remaining_coverage_pct', 0.0):.1f}% • Amber",
                accent_color=STRATEGY_COLOR_MAP["Immediate Priority-Coverage Baseline"],
            )
        with s3:
            render_kpi_card(
                "Counterfactual Look-Ahead",
                f"{look_data.get('avg_response_time_min', 0.0):.2f} min",
                f"Coverage: {look_data.get('final_remaining_coverage_pct', 0.0):.1f}% • Dark Navy",
                accent_color=STRATEGY_COLOR_MAP["Counterfactual Look-Ahead Optimizer"],
            )

        st.markdown("<br>", unsafe_allow_html=True)

        df_comp = evaluation_service.get_comparison_dataframe(eval_results)
        render_styled_table(df_comp, max_rows=10)

        summary = eval_results.get("objective_summary", "Evaluation complete.")
        st.info(f"📊 **Performance Analysis:** {summary}")

        st.markdown("#### 📈 Comparative Visual Analytics")

        chart_rows = []
        for sk, s in strategies.items():
            chart_rows.append({
                "Strategy": s.get("strategy_name", sk),
                "Avg Response Time (min)": round(s.get("avg_response_time_min", 0.0), 2),
                "Critical Response Time (min)": round(s.get("critical_avg_response_time_min", 0.0), 2),
                "Total Travel Distance (km)": round(s.get("total_travel_distance_km", 0.0), 2),
                "Remaining Coverage %": round(s.get("final_remaining_coverage_pct", 0.0), 1),
                "Computation Time (ms)": round(s.get("avg_computation_time_ms", 0.0), 3),
            })
        df_charts = pd.DataFrame(chart_rows)

        c_chart1, c_chart2 = st.columns(2)
        with c_chart1:
            df_resp_melted = df_charts.melt(
                id_vars="Strategy",
                value_vars=["Avg Response Time (min)", "Critical Response Time (min)"],
                var_name="Metric",
                value_name="Minutes",
            )
            fig_resp = px.bar(
                df_resp_melted,
                x="Metric",
                y="Minutes",
                color="Strategy",
                barmode="group",
                color_discrete_map=STRATEGY_COLOR_MAP,
                text="Minutes",
            )
            apply_plotly_theme(
                fig_resp,
                title="Response Time Comparison (Lower is Better)",
                height=360,
                show_legend=True,
                xaxis_title="Response Metric",
                yaxis_title="Time (minutes)",
            )
            style_bar_traces(fig_resp, value_format=".2f", y_max_padding=1.22)
            fig_resp.update_layout(legend=dict(orientation="h", yanchor="top", y=-0.22, xanchor="center", x=0.5))
            st.plotly_chart(fig_resp, use_container_width=True)

        with c_chart2:
            fig_cov = px.bar(
                df_charts,
                x="Strategy",
                y="Remaining Coverage %",
                color="Strategy",
                color_discrete_map=STRATEGY_COLOR_MAP,
                text="Remaining Coverage %",
            )
            apply_plotly_theme(
                fig_cov,
                title="Remaining Fleet Coverage % (Higher is Better)",
                height=360,
                show_legend=True,
                xaxis_title="Dispatch Strategy",
                yaxis_title="Coverage (%)",
            )
            style_bar_traces(fig_cov, value_format=".1f", y_max_padding=1.20)
            fig_cov.update_layout(legend=dict(orientation="h", yanchor="top", y=-0.22, xanchor="center", x=0.5))
            st.plotly_chart(fig_cov, use_container_width=True)

        c_chart3, c_chart4 = st.columns(2)
        with c_chart3:
            fig_dist = px.bar(
                df_charts,
                x="Strategy",
                y="Total Travel Distance (km)",
                color="Strategy",
                color_discrete_map=STRATEGY_COLOR_MAP,
                text="Total Travel Distance (km)",
            )
            apply_plotly_theme(
                fig_dist,
                title="Total Fleet Travel Distance (km)",
                height=360,
                show_legend=True,
                xaxis_title="Dispatch Strategy",
                yaxis_title="Distance (km)",
            )
            style_bar_traces(fig_dist, value_format=".2f", y_max_padding=1.20)
            fig_dist.update_layout(legend=dict(orientation="h", yanchor="top", y=-0.22, xanchor="center", x=0.5))
            st.plotly_chart(fig_dist, use_container_width=True)

        with c_chart4:
            fig_comp = px.bar(
                df_charts,
                x="Strategy",
                y="Computation Time (ms)",
                color="Strategy",
                color_discrete_map=STRATEGY_COLOR_MAP,
                text="Computation Time (ms)",
            )
            apply_plotly_theme(
                fig_comp,
                title="Actual Algorithm Execution Time (ms)",
                height=360,
                show_legend=True,
                xaxis_title="Dispatch Strategy",
                yaxis_title="Computation Time (ms)",
            )
            style_bar_traces(fig_comp, value_format=".3f", y_max_padding=1.22)
            fig_comp.update_layout(legend=dict(orientation="h", yanchor="top", y=-0.22, xanchor="center", x=0.5))
            st.plotly_chart(fig_comp, use_container_width=True)

        with st.expander("🔍 View Detailed Step-by-Step Dispatch Logs per Strategy"):
            for sk, s in strategies.items():
                st.markdown(f"**{s.get('strategy_name', sk)} Decisions:**")
                decs = s.get("decisions", [])
                if decs:
                    dec_list = []
                    for d in decs:
                        dec_list.append({
                            "Incident": d["incident_id"],
                            "Assigned Ambulance": d["selected_ambulance_id"] or "Unserved",
                            "Feasible": "Yes" if d.get("is_feasible") else "No",
                            "Travel Time": f"{d['estimated_travel_time_min']:.1f} min",
                            "Distance": f"{d['estimated_distance_km']:.1f} km",
                            "Cost": f"{d['total_cost']:.2f}",
                            "Rationale": d["selection_reason"],
                        })
                    render_styled_table(pd.DataFrame(dec_list), badge_columns=["Feasible"], max_rows=30)

        csv_path = evaluation_service.export_benchmark_csv(eval_results)
        with open(csv_path, "r", encoding="utf-8") as f:
            csv_data = f.read()

        st.download_button(
            label="📥 Download Comparative Evaluation CSV Report",
            data=csv_data,
            file_name=f"evaluation_{result_scen_id}.csv",
            mime="text/csv",
            use_container_width=True,
        )
