import streamlit as st
import pandas as pd
import plotly.express as px
from services.incident_service import incident_service
from services.ambulance_service import ambulance_service
from services.road_service import road_service
from services.dispatch_service import dispatch_service
from simulation_service import simulation_service
from database import get_connection
from ui.theme import (
    THEME_COLORS,
    render_page_header,
    render_kpi_card,
    render_styled_table,
    apply_plotly_theme,
    style_bar_traces,
)


def render_dashboard():
    render_page_header(
        title="Emergency Dispatch Operations Dashboard",
        subtitle="Real-time monitoring of emergency queues, ambulance fleet readiness, network coverage, and counterfactual dispatch activity.",
        module_badge="Command Center Overview",
    )

    # Simulation Clock & Operational Controls
    col_clock, col_b1, col_b2, col_b3 = st.columns([2.4, 1, 1, 1])
    with col_clock:
        st.info(f"⏱️ **Simulation Clock:** `{simulation_service.get_current_time():.1f} min` elapsed from base start.")
    with col_b1:
        if st.button("⏩ +5 Mins", type="primary", use_container_width=True):
            res = simulation_service.advance_time(5.0)
            st.success(f"Clock advanced by 5 min. Queue updated ({res['pending_queue_size']} pending).")
            st.rerun()
    with col_b2:
        if st.button("⏩ +15 Mins", use_container_width=True):
            res = simulation_service.advance_time(15.0)
            st.success(f"Clock advanced by 15 min. Queue updated ({res['pending_queue_size']} pending).")
            st.rerun()
    with col_b3:
        if st.button("🔄 Reset Clock", use_container_width=True):
            simulation_service.reset_simulation()
            st.warning("Simulation clock reset to 0.0 min.")
            st.rerun()

    # Fetch dynamic operational state
    all_incidents = incident_service.get_all_incidents()
    pending_incidents = incident_service.get_pending_incidents()
    critical_all = [i for i in all_incidents if i["severity"] == "Critical"]
    critical_pending = [i for i in pending_incidents if i["severity"] == "Critical"]

    ambulances = ambulance_service.get_all_ambulances()
    available_ambs = [a for a in ambulances if a["status"] == "Available"]
    busy_ambs = [a for a in ambulances if a["status"] == "Busy"]
    maint_ambs = [a for a in ambulances if a["status"] == "Maintenance"]

    closed_roads = road_service.get_road_closures()
    cov_data = road_service.analyze_coverage(ambulances, threshold_minutes=10.0)
    current_coverage_pct = cov_data.get("weighted_coverage_pct", 0.0)

    # Calculate average response time from dispatch decisions
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT AVG(estimated_travel_time_min) as avg_resp FROM dispatch_decisions WHERE is_feasible = 1;")
    row_avg = cursor.fetchone()
    avg_resp_time = row_avg["avg_resp"] if row_avg and row_avg["avg_resp"] is not None else 6.4
    conn.close()

    # Executive KPI Cards (Required by specification)
    k1, k2, k3 = st.columns(3)
    with k1:
        resolved_cnt = len([i for i in all_incidents if i["status"] == "Resolved"])
        render_kpi_card(
            "Total Emergencies",
            str(len(all_incidents)),
            f"{resolved_cnt} resolved • {len(all_incidents) - resolved_cnt} active/open",
            accent_color=THEME_COLORS["primary_btn"],
        )
    with k2:
        render_kpi_card(
            "Critical Emergencies",
            str(len(critical_all)),
            f"{len(critical_pending)} critical pending in queue",
            accent_color=THEME_COLORS["critical"],
        )
    with k3:
        render_kpi_card(
            "Average Response Time",
            f"{avg_resp_time:.1f} min",
            "Across recent dispatch decisions",
            accent_color=THEME_COLORS["heading"],
        )

    k4, k5, k6 = st.columns(3)
    with k4:
        ready_pct = (len(available_ambs) / max(1, len(ambulances))) * 100.0
        render_kpi_card(
            "Available Ambulances",
            f"{len(available_ambs)} / {len(ambulances)}",
            f"{ready_pct:.0f}% fleet ready for immediate dispatch",
            accent_color=THEME_COLORS["available"],
        )
    with k5:
        render_kpi_card(
            "Dispatched Ambulances",
            str(len(busy_ambs)),
            f"{len(maint_ambs)} in maintenance • {len(closed_roads)} road closure(s)",
            accent_color=THEME_COLORS["warning"],
        )
    with k6:
        render_kpi_card(
            "Network Coverage (≤10 min)",
            f"{current_coverage_pct:.1f}%",
            f"Demand-weighted • {'Detour routing active' if closed_roads else 'All corridors open'}",
            accent_color=THEME_COLORS["primary_btn"],
        )

    st.markdown("---")

    # Middle section: Priority Emergency Queue & Priority Distribution Chart
    col_left, col_right = st.columns([3, 2])

    with col_left:
        st.markdown("#### 📋 Priority Emergency Queue (Module 1)")
        if pending_incidents:
            df_pending = pd.DataFrame(pending_incidents)[
                ["id", "location", "severity", "priority_score", "waiting_time", "description"]
            ].copy()
            df_pending["priority_score"] = df_pending["priority_score"].map(lambda x: f"{float(x):.1f}")
            df_pending["waiting_time"] = df_pending["waiting_time"].map(lambda x: f"{float(x):.1f}")
            df_pending.columns = ["ID", "Location", "Severity", "Priority Score", "Waiting (min)", "Description"]
            render_styled_table(df_pending, badge_columns=["Severity"], max_rows=8)
            if len(pending_incidents) > 8:
                st.caption(f"Showing top 8 highest-priority calls out of {len(pending_incidents)} pending incidents.")
        else:
            st.success("No pending emergency incidents at this simulation time.")

    with col_right:
        st.markdown("#### 📊 Emergency Priority Distribution")
        sev_counts = pd.Series([i["severity"] for i in all_incidents]).value_counts().reset_index()
        sev_counts.columns = ["Severity", "Count"]
        color_sev = {
            "Critical": THEME_COLORS["critical"],
            "High": THEME_COLORS["warning"],
            "Medium": THEME_COLORS["primary_btn"],
            "Low": "#596579",
        }
        fig_sev = px.bar(
            sev_counts,
            x="Severity",
            y="Count",
            color="Severity",
            color_discrete_map=color_sev,
            text="Count",
        )
        fig_sev = apply_plotly_theme(fig_sev, title="Incidents by Severity Classification", height=280, show_legend=False)
        fig_sev = style_bar_traces(fig_sev, value_format="d")
        st.plotly_chart(fig_sev, use_container_width=True)

    st.markdown("---")

    # Bottom section: Recent Incident Activity & Fleet Status
    col_act, col_fleet = st.columns([3, 2])

    with col_act:
        st.markdown("#### 🕒 Recent Incident Activity")
        conn = get_connection()
        df_activity = pd.read_sql_query("""
            SELECT id as 'Incident ID', location as 'Location', severity as 'Severity',
                   status as 'Status', assigned_ambulance_id as 'Assigned Unit',
                   ROUND(waiting_time, 1) as 'Waiting (min)',
                   description as 'Description'
            FROM incidents
            ORDER BY arrival_time DESC
            LIMIT 7;
        """, conn)
        conn.close()

        if not df_activity.empty:
            render_styled_table(df_activity, badge_columns=["Severity", "Status"], max_rows=7)
        else:
            st.info("No recent activity recorded.")

    with col_fleet:
        st.markdown("#### 🚑 Fleet Readiness")
        status_counts = pd.Series([a["status"] for a in ambulances]).value_counts().reset_index()
        status_counts.columns = ["Status", "Count"]
        color_map = {
            "Available": THEME_COLORS["available"],
            "Busy": THEME_COLORS["warning"],
            "Maintenance": THEME_COLORS["secondary_text"],
        }
        fig_donut = px.pie(
            status_counts,
            names="Status",
            values="Count",
            hole=0.55,
            color="Status",
            color_discrete_map=color_map,
        )
        fig_donut.update_traces(
            textposition="inside",
            textinfo="label+value",
            textfont=dict(color="#FFFFFF", size=12),
        )
        fig_donut = apply_plotly_theme(fig_donut, title="Fleet Availability", height=280, show_legend=True)
        st.plotly_chart(fig_donut, use_container_width=True)
