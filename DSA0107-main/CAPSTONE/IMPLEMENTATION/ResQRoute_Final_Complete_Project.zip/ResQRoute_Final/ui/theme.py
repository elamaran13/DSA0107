import html
from typing import List, Optional
import pandas as pd
import streamlit as st
import plotly.graph_objects as go

THEME_COLORS = {
    "main_bg": "#F3F6FA",
    "sidebar_bg": "#10243A",
    "heading": "#142B45",
    "text": "#000000",
    "secondary_text": "#333333",
    "card_bg": "#FFFFFF",
    "primary_btn": "#174A78",
    "btn_text": "#FFFFFF",
    "critical": "#DC3545",
    "available": "#198754",
    "warning": "#F59E0B",
    "border": "#D9E1EA",
}

STRATEGY_COLOR_MAP = {
    "Nearest-Available Baseline": "#5B7083",           # Slate Grey/Blue
    "Immediate Priority-Coverage Baseline": "#F59E0B", # Amber
    "Counterfactual Look-Ahead Optimizer": "#142B45",  # Deep Navy (Proposed)
}


def apply_global_styles() -> None:
    """
    Injects high-contrast CSS ensuring 100% text visibility throughout the application.
    Enforces the emergency management theme palette:
      Main Background: #F3F6FA | Sidebar: #10243A | Headings: #142B45
      Body Text: #000000 | Secondary: #333333 | Buttons: #174A78 / #FFFFFF
    """
    st.markdown(
        """
        <style>
        /* === Root Variable Overrides === */
        :root {
            --primary-color: #174A78 !important;
            --background-color: #F3F6FA !important;
            --secondary-background-color: #FFFFFF !important;
            --text-color: #000000 !important;
            --font: 'Segoe UI', -apple-system, BlinkMacSystemFont, Roboto, sans-serif;
        }

        /* === App Container & Global Canvas === */
        html, body, .stApp, [data-testid="stAppViewContainer"], [data-testid="stMain"], section.main {
            background-color: #F3F6FA !important;
            color: #000000 !important;
            font-family: 'Segoe UI', -apple-system, BlinkMacSystemFont, Roboto, sans-serif;
        }

        [data-testid="stHeader"] {
            background-color: #F3F6FA !important;
            border-bottom: 1px solid #D9E1EA;
        }
        [data-testid="stHeader"] button, [data-testid="stHeader"] svg {
            color: #142B45 !important;
            fill: #142B45 !important;
        }

        .block-container {
            padding-top: 1.4rem !important;
            padding-bottom: 2.5rem !important;
            max-width: 1400px;
        }

        /* === Sidebar Styling (#10243A Dark Navy) === */
        [data-testid="stSidebar"], [data-testid="stSidebar"] > div:first-child {
            background-color: #10243A !important;
            border-right: 1px solid #1E3A5F !important;
        }
        [data-testid="stSidebar"] h1,
        [data-testid="stSidebar"] h2,
        [data-testid="stSidebar"] h3,
        [data-testid="stSidebar"] h4 {
            color: #FFFFFF !important;
            font-weight: 700 !important;
        }
        [data-testid="stSidebar"] p,
        [data-testid="stSidebar"] span,
        [data-testid="stSidebar"] label,
        [data-testid="stSidebar"] div,
        [data-testid="stSidebar"] small,
        [data-testid="stSidebar"] [data-testid="stCaptionContainer"] {
            color: #FFFFFF !important;
        }
        [data-testid="stSidebar"] hr {
            border-color: rgba(217, 225, 234, 0.25) !important;
        }
        [data-testid="stSidebar"] [role="radiogroup"] label {
            background-color: rgba(255, 255, 255, 0.08);
            border: 1px solid rgba(255, 255, 255, 0.16);
            border-radius: 8px;
            padding: 8px 12px !important;
            margin-bottom: 6px !important;
            transition: background-color 0.15s ease, border-color 0.15s ease;
        }
        [data-testid="stSidebar"] [role="radiogroup"] label:hover {
            background-color: rgba(23, 74, 120, 0.85) !important;
            border-color: rgba(255, 255, 255, 0.35) !important;
        }
        [data-testid="stSidebar"] [role="radiogroup"] label:has(input:checked) {
            background-color: #174A78 !important;
            border-color: #60A5FA !important;
        }
        [data-testid="stSidebar"] [role="radiogroup"] label:has(input:checked) p,
        [data-testid="stSidebar"] [role="radiogroup"] label:has(input:checked) span {
            color: #FFFFFF !important;
            font-weight: 700 !important;
        }
        [data-testid="stSidebar"] [data-testid="stAlert"] {
            background-color: rgba(255, 255, 255, 0.10) !important;
            border: 1px solid rgba(255, 255, 255, 0.22) !important;
            border-radius: 8px !important;
        }
        [data-testid="stSidebar"] [data-testid="stAlert"] p,
        [data-testid="stSidebar"] [data-testid="stAlert"] span {
            color: #FFFFFF !important;
        }
        [data-testid="stSidebar"] button {
            background-color: #174A78 !important;
            color: #FFFFFF !important;
            border: 1px solid #4A80B0 !important;
            border-radius: 8px !important;
            font-weight: 600 !important;
        }
        [data-testid="stSidebar"] button p,
        [data-testid="stSidebar"] button span {
            color: #FFFFFF !important;
        }
        [data-testid="stSidebarCollapseButton"] svg,
        [data-testid="collapsedControl"] svg {
            color: #FFFFFF !important;
            fill: #FFFFFF !important;
        }

        /* === Main Content Area Typography === */
        [data-testid="stMain"] h1,
        [data-testid="stMain"] h2,
        [data-testid="stMain"] h3,
        [data-testid="stMain"] h4,
        [data-testid="stMain"] h5,
        [data-testid="stMain"] h6 {
            color: #142B45 !important;
            font-weight: 700 !important;
        }
        [data-testid="stMain"] p,
        [data-testid="stMain"] [data-testid="stMarkdownContainer"] p,
        [data-testid="stMain"] [data-testid="stMarkdownContainer"] li,
        [data-testid="stMain"] span:not([data-testid="stSidebar"] span):not(.resq-badge) {
            color: #000000;
        }
        [data-testid="stMain"] small,
        [data-testid="stMain"] [data-testid="stCaptionContainer"],
        [data-testid="stMain"] [data-testid="stCaptionContainer"] p {
            color: #333333 !important;
        }
        [data-testid="stMain"] code {
            background-color: #E8EEF5 !important;
            color: #142B45 !important;
            border: 1px solid #D9E1EA !important;
            padding: 1px 6px;
            border-radius: 4px;
            font-size: 0.88em;
            font-weight: 600;
        }

        /* === Page Header & Cards === */
        .resq-page-header {
            background-color: #FFFFFF;
            border: 1px solid #D9E1EA;
            border-left: 5px solid #174A78;
            border-radius: 10px;
            padding: 16px 20px;
            margin-bottom: 14px;
            box-shadow: 0 2px 6px rgba(16, 36, 58, 0.04);
        }
        .resq-page-title {
            color: #142B45;
            font-size: 1.55rem;
            font-weight: 700;
            margin: 0 0 4px 0;
            line-height: 1.25;
        }
        .resq-page-subtitle {
            color: #333333;
            font-size: 0.95rem;
            margin: 0;
        }
        .resq-module-badge {
            display: inline-block;
            background-color: #E8F0F8;
            color: #174A78;
            border: 1px solid #C5D6E8;
            font-size: 0.76rem;
            font-weight: 700;
            padding: 2px 10px;
            border-radius: 999px;
            margin-bottom: 6px;
            letter-spacing: 0.02em;
        }

        .resq-kpi-card {
            background-color: #FFFFFF;
            border: 1px solid #D9E1EA;
            border-radius: 10px;
            padding: 14px 16px;
            box-shadow: 0 2px 6px rgba(16, 36, 58, 0.04);
            margin-bottom: 10px;
            height: 100%;
        }
        .resq-kpi-label {
            color: #333333;
            font-size: 0.82rem;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.03em;
            margin-bottom: 6px;
        }
        .resq-kpi-value {
            color: #142B45;
            font-size: 1.75rem;
            font-weight: 700;
            line-height: 1.15;
            margin-bottom: 4px;
        }
        .resq-kpi-sub {
            color: #333333;
            font-size: 0.82rem;
            font-weight: 500;
        }

        .resq-info-card {
            background-color: #FFFFFF;
            border: 1px solid #D9E1EA;
            border-left: 5px solid #174A78;
            border-radius: 8px;
            padding: 14px 18px;
            margin-bottom: 14px;
            color: #000000;
            box-shadow: 0 1px 4px rgba(16, 36, 58, 0.04);
        }
        .resq-info-card b, .resq-info-card strong {
            color: #142B45;
        }

        .sim-disclaimer {
            background-color: #FFFFFF;
            border: 1px solid #D9E1EA;
            border-left: 4px solid #174A78;
            padding: 9px 14px;
            font-size: 0.86rem;
            color: #000000;
            border-radius: 8px;
            margin-bottom: 14px;
        }

        /* === Streamlit Native Metrics === */
        [data-testid="stMetric"] {
            background-color: #FFFFFF !important;
            border: 1px solid #D9E1EA !important;
            border-radius: 10px !important;
            padding: 14px 16px !important;
            box-shadow: 0 2px 6px rgba(16, 36, 58, 0.04) !important;
        }
        [data-testid="stMetricLabel"],
        [data-testid="stMetricLabel"] p,
        [data-testid="stMetricLabel"] label {
            color: #333333 !important;
            font-weight: 600 !important;
        }
        [data-testid="stMetricValue"],
        [data-testid="stMetricValue"] div {
            color: #142B45 !important;
            font-weight: 700 !important;
        }
        [data-testid="stMetricDelta"] {
            color: #174A78 !important;
            font-weight: 600 !important;
        }

        /* === Buttons: Primary, Secondary, Submit, Download === */
        [data-testid="stMain"] button[kind="primary"],
        [data-testid="stMain"] button[data-testid="baseButton-primary"],
        [data-testid="stMain"] [data-testid="stFormSubmitButton"] button,
        [data-testid="stMain"] [data-testid="stDownloadButton"] button,
        [data-testid="stMain"] .stButton > button {
            background-color: #174A78 !important;
            color: #FFFFFF !important;
            border: 1px solid #174A78 !important;
            border-radius: 8px !important;
            font-weight: 600 !important;
            min-height: 40px;
        }
        [data-testid="stMain"] button[kind="primary"] *,
        [data-testid="stMain"] button[data-testid="baseButton-primary"] *,
        [data-testid="stMain"] [data-testid="stFormSubmitButton"] button *,
        [data-testid="stMain"] [data-testid="stDownloadButton"] button *,
        [data-testid="stMain"] .stButton > button * {
            color: #FFFFFF !important;
        }
        [data-testid="stMain"] button[kind="primary"]:hover,
        [data-testid="stMain"] button[data-testid="baseButton-primary"]:hover,
        [data-testid="stMain"] [data-testid="stFormSubmitButton"] button:hover,
        [data-testid="stMain"] [data-testid="stDownloadButton"] button:hover,
        [data-testid="stMain"] .stButton > button:hover {
            background-color: #142B45 !important;
            border-color: #142B45 !important;
        }

        [data-testid="stMain"] button[kind="secondary"],
        [data-testid="stMain"] button[data-testid="baseButton-secondary"] {
            background-color: #FFFFFF !important;
            color: #142B45 !important;
            border: 1px solid #174A78 !important;
            border-radius: 8px !important;
            font-weight: 600 !important;
            min-height: 40px;
        }
        [data-testid="stMain"] button[kind="secondary"] *,
        [data-testid="stMain"] button[data-testid="baseButton-secondary"] * {
            color: #142B45 !important;
        }
        [data-testid="stMain"] button[kind="secondary"]:hover,
        [data-testid="stMain"] button[data-testid="baseButton-secondary"]:hover {
            background-color: #E8F0F8 !important;
            border-color: #142B45 !important;
        }
        [data-testid="stMain"] button:disabled,
        [data-testid="stMain"] .stButton > button:disabled {
            background-color: #E2E8F0 !important;
            color: #596579 !important;
            border-color: #D9E1EA !important;
            opacity: 0.85 !important;
        }
        [data-testid="stMain"] button:disabled *,
        [data-testid="stMain"] .stButton > button:disabled * {
            color: #596579 !important;
        }

        /* === Forms, Inputs, Dropdowns, Popovers === */
        [data-testid="stForm"] {
            background-color: #FFFFFF !important;
            border: 1px solid #D9E1EA !important;
            border-radius: 10px !important;
            padding: 18px !important;
            box-shadow: 0 2px 6px rgba(16, 36, 58, 0.04);
        }
        [data-testid="stWidgetLabel"] p,
        [data-testid="stWidgetLabel"] label,
        [data-testid="stCheckbox"] label p,
        [data-testid="stSlider"] label p {
            color: #142B45 !important;
            font-weight: 600 !important;
        }
        [data-baseweb="select"] > div,
        [data-baseweb="input"] > div,
        [data-baseweb="base-input"],
        [data-testid="stTextInput"] input,
        [data-testid="stNumberInput"] input,
        [data-testid="stTextArea"] textarea {
            background-color: #FFFFFF !important;
            color: #000000 !important;
            border-color: #D9E1EA !important;
        }
        [data-baseweb="select"] span,
        [data-baseweb="select"] div,
        [data-baseweb="select"] svg {
            color: #000000 !important;
            fill: #000000 !important;
        }
        [data-baseweb="popover"],
        [data-baseweb="menu"],
        ul[role="listbox"] {
            background-color: #FFFFFF !important;
            color: #000000 !important;
            border: 1px solid #D9E1EA !important;
        }
        li[role="option"] {
            background-color: #FFFFFF !important;
            color: #000000 !important;
        }
        li[role="option"] * {
            color: #000000 !important;
        }
        li[role="option"]:hover,
        li[role="option"][aria-selected="true"] {
            background-color: #E8F0F8 !important;
            color: #142B45 !important;
        }
        li[role="option"]:hover *,
        li[role="option"][aria-selected="true"] * {
            color: #142B45 !important;
        }
        [data-testid="stNumberInputStepUp"],
        [data-testid="stNumberInputStepDown"] {
            background-color: #F3F6FA !important;
            color: #142B45 !important;
            border-color: #D9E1EA !important;
        }

        /* === Tabs === */
        [data-baseweb="tab-list"] {
            border-bottom: 2px solid #D9E1EA !important;
            gap: 6px;
        }
        [data-baseweb="tab"] {
            background-color: transparent !important;
            color: #333333 !important;
            font-weight: 600 !important;
            padding: 8px 14px !important;
        }
        [data-baseweb="tab"] p, [data-baseweb="tab"] span {
            color: #333333 !important;
            font-weight: 600 !important;
        }
        [data-baseweb="tab"][aria-selected="true"] {
            color: #174A78 !important;
            border-bottom: 3px solid #174A78 !important;
        }
        [data-baseweb="tab"][aria-selected="true"] p, [data-baseweb="tab"][aria-selected="true"] span {
            color: #174A78 !important;
            font-weight: 700 !important;
        }

        /* === Expanders === */
        [data-testid="stExpander"] {
            background-color: #FFFFFF !important;
            border: 1px solid #D9E1EA !important;
            border-radius: 10px !important;
            overflow: hidden;
        }
        [data-testid="stExpander"] summary,
        [data-testid="stExpander"] summary p,
        [data-testid="stExpander"] summary span,
        [data-testid="stExpander"] summary svg {
            color: #142B45 !important;
            fill: #142B45 !important;
            font-weight: 600 !important;
        }
        [data-testid="stExpander"] [data-testid="stExpanderDetails"] * {
            color: #000000;
        }

        /* === Alerts in Main Content === */
        [data-testid="stMain"] [data-testid="stAlert"] {
            border-radius: 8px !important;
            border: 1px solid #D9E1EA !important;
            color: #000000 !important;
        }
        [data-testid="stMain"] [data-testid="stAlert"] p,
        [data-testid="stMain"] [data-testid="stAlert"] li,
        [data-testid="stMain"] [data-testid="stAlert"] strong {
            color: #000000 !important;
        }

        /* === Dataframes & Custom High-Contrast Tables === */
        [data-testid="stDataFrame"] {
            background-color: #FFFFFF !important;
            border: 1px solid #D9E1EA !important;
            border-radius: 10px !important;
            padding: 4px !important;
            box-shadow: 0 2px 6px rgba(16, 36, 58, 0.04);
        }

        .resq-table-card {
            background-color: #FFFFFF;
            border: 1px solid #D9E1EA;
            border-radius: 10px;
            overflow-x: auto;
            box-shadow: 0 2px 6px rgba(16, 36, 58, 0.04);
            margin-bottom: 12px;
        }
        .resq-table {
            width: 100%;
            border-collapse: collapse;
            font-size: 0.88rem;
            color: #000000;
        }
        .resq-table thead tr {
            background-color: #E8EEF5;
            border-bottom: 2px solid #174A78;
        }
        .resq-table th {
            color: #142B45;
            font-weight: 700;
            text-align: left;
            padding: 10px 12px;
            white-space: nowrap;
        }
        .resq-table td {
            color: #000000;
            padding: 9px 12px;
            border-bottom: 1px solid #D9E1EA;
            vertical-align: middle;
        }
        .resq-table tbody tr:nth-child(even) {
            background-color: #F8FAFC;
        }
        .resq-table tbody tr:hover {
            background-color: #EFF5FB;
        }

        /* === Status Badges === */
        .resq-badge {
            display: inline-block;
            padding: 2px 9px;
            border-radius: 999px;
            font-size: 0.78rem;
            font-weight: 700;
            white-space: nowrap;
        }
        .badge-critical { background-color: #FDECEC; color: #DC3545 !important; border: 1px solid #F5C2C7; }
        .badge-available { background-color: #E8F6EE; color: #198754 !important; border: 1px solid #BADBCC; }
        .badge-warning { background-color: #FEF5E6; color: #B45309 !important; border: 1px solid #FDE68A; }
        .badge-primary { background-color: #E8F0F8; color: #174A78 !important; border: 1px solid #B6D0E8; }
        .badge-neutral { background-color: #EEF2F6; color: #333333 !important; border: 1px solid #D9E1EA; }
        </style>
        """,
        unsafe_allow_html=True,
    )


def render_page_header(title: str, subtitle: str, module_badge: str = "") -> None:
    badge_html = f"<div class='resq-module-badge'>{html.escape(module_badge)}</div>" if module_badge else ""
    st.markdown(
        f"""
        <div class="resq-page-header">
            {badge_html}
            <div class="resq-page-title">{html.escape(title)}</div>
            <p class="resq-page-subtitle">{html.escape(subtitle)}</p>
        </div>
        """,
        unsafe_allow_html=True,
    )


def render_kpi_card(label: str, value: str, subtitle: str = "", accent_color: str = "#174A78") -> None:
    sub_html = f"<div class='resq-kpi-sub'>{html.escape(subtitle)}</div>" if subtitle else ""
    st.markdown(
        f"""
        <div class="resq-kpi-card" style="border-top: 4px solid {accent_color};">
            <div class="resq-kpi-label">{html.escape(label)}</div>
            <div class="resq-kpi-value">{html.escape(str(value))}</div>
            {sub_html}
        </div>
        """,
        unsafe_allow_html=True,
    )


def _status_badge_html(val: object) -> str:
    s = str(val)
    norm = s.strip().lower()
    if norm in {"critical", "uncovered", "no", "closed", "cancelled"}:
        cls = "badge-critical"
    elif norm in {"available", "covered", "yes", "open", "resolved"}:
        cls = "badge-available"
    elif norm in {"high", "busy", "pending", "warning"}:
        cls = "badge-warning"
    elif norm in {"medium", "dispatched", "in-transit"}:
        cls = "badge-primary"
    else:
        cls = "badge-neutral"
    return f"<span class='resq-badge {cls}'>{html.escape(s)}</span>"


def render_styled_table(df: pd.DataFrame, badge_columns: Optional[List[str]] = None, max_rows: int = 50) -> None:
    """Renders a crisp, high-contrast HTML table with dark navy headings and visible black text."""
    badge_set = set(badge_columns or [])
    display_df = df.head(max_rows)
    headers = "".join(f"<th>{html.escape(str(col))}</th>" for col in display_df.columns)

    rows_html = []
    for _, row in display_df.iterrows():
        cells = []
        for col in display_df.columns:
            val = row[col]
            if col in badge_set:
                cells.append(f"<td>{_status_badge_html(val)}</td>")
            else:
                cells.append(f"<td>{html.escape(str(val))}</td>")
        rows_html.append(f"<tr>{''.join(cells)}</tr>")

    st.markdown(
        f"""
        <div class="resq-table-card">
            <table class="resq-table">
                <thead><tr>{headers}</tr></thead>
                <tbody>{''.join(rows_html)}</tbody>
            </table>
        </div>
        """,
        unsafe_allow_html=True,
    )


def apply_plotly_theme(
    fig: go.Figure,
    title: Optional[str] = None,
    height: int = 340,
    show_legend: bool = True,
    xaxis_title: Optional[str] = None,
    yaxis_title: Optional[str] = None,
) -> go.Figure:
    """Applies consistent white-background, dark-navy-title, black-text styling to any Plotly chart."""
    resolved_title = title if title is not None else (fig.layout.title.text if fig.layout.title else None)
    layout_kwargs = dict(
        template="plotly_white",
        paper_bgcolor="#FFFFFF",
        plot_bgcolor="#FFFFFF",
        height=height,
        showlegend=show_legend,
        font=dict(family="Segoe UI, -apple-system, Roboto, sans-serif", size=12, color="#000000"),
        margin=dict(l=30, r=24, t=54 if resolved_title else 24, b=36),
        legend=dict(
            font=dict(color="#000000", size=11),
            title_font=dict(color="#142B45", size=12),
            bgcolor="rgba(255,255,255,0.96)",
            bordercolor="#D9E1EA",
            borderwidth=1,
        ),
        hoverlabel=dict(
            bgcolor="#10243A",
            bordercolor="#174A78",
            font=dict(color="#FFFFFF", size=12),
        ),
    )
    if resolved_title:
        layout_kwargs["title"] = dict(
            text=resolved_title,
            font=dict(size=15, color="#142B45", family="Segoe UI, -apple-system, Roboto, sans-serif"),
            x=0.02,
            xanchor="left",
        )

    fig.update_layout(**layout_kwargs)
    fig.update_xaxes(
        title_font=dict(color="#142B45", size=12),
        tickfont=dict(color="#000000", size=11),
        gridcolor="#E5EBF2",
        linecolor="#D9E1EA",
        zerolinecolor="#D9E1EA",
        automargin=True,
    )
    fig.update_yaxes(
        title_font=dict(color="#142B45", size=12),
        tickfont=dict(color="#000000", size=11),
        gridcolor="#E5EBF2",
        linecolor="#D9E1EA",
        zerolinecolor="#D9E1EA",
        automargin=True,
    )
    if xaxis_title is not None:
        fig.update_xaxes(title_text=xaxis_title)
    if yaxis_title is not None:
        fig.update_yaxes(title_text=yaxis_title)
    return fig


def style_bar_traces(fig: go.Figure, value_format: str = ".2f", y_max_padding: float = 1.18) -> go.Figure:
    """Adds crisp dark-navy data labels above bars and adds top y-axis headroom."""
    fig.update_traces(
        texttemplate="%{y:" + value_format + "}",
        textposition="outside",
        textfont=dict(color="#142B45", size=11),
        cliponaxis=False,
    )
    y_vals = []
    for trace in fig.data:
        if getattr(trace, "y", None) is not None:
            for v in trace.y:
                if isinstance(v, (int, float)):
                    y_vals.append(float(v))
    if y_vals:
        max_y = max(y_vals)
        if max_y > 0:
            fig.update_yaxes(range=[0, max_y * y_max_padding])
    return fig
