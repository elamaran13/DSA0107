import streamlit as st
import pandas as pd
from services.incident_service import incident_service
from services.road_service import road_service
from simulation_service import simulation_service
from config import DEFAULT_SEVERITY_WEIGHT, DEFAULT_WAITING_TIME_WEIGHT
from ui.theme import render_page_header, render_styled_table, render_kpi_card, THEME_COLORS


def render_incidents_page():
    render_page_header(
        title="Emergency Incident Management",
        subtitle="Dynamic emergency prioritization, priority queue ranking, emergency type classification, and validated incident lifecycle state management powered by the C++ PriorityEngine.",
        module_badge="Module 1 • Prioritization & Incident Management",
    )

    all_inc = incident_service.get_all_incidents()
    pending = incident_service.get_pending_incidents()
    crit_pending = [i for i in pending if i["severity"] == "Critical"]
    dispatched = [i for i in all_inc if i["status"] in ("Dispatched", "In-Transit")]

    m1, m2, m3, m4 = st.columns(4)
    with m1:
        render_kpi_card("Total Incidents", str(len(all_inc)), "Registered in database", THEME_COLORS["primary_btn"])
    with m2:
        render_kpi_card("Pending Queue", str(len(pending)), "Awaiting dispatch", THEME_COLORS["warning"])
    with m3:
        render_kpi_card("Critical Pending", str(len(crit_pending)), "Highest urgency tier", THEME_COLORS["critical"])
    with m4:
        render_kpi_card("Active Missions", str(len(dispatched)), "Dispatched or In-Transit", THEME_COLORS["available"])

    st.markdown("<br>", unsafe_allow_html=True)

    locations = road_service.get_locations()
    loc_options = [f"{loc['id']} - {loc['name']}" for loc in locations]
    loc_id_map = {opt: opt.split(" - ")[0] for opt in loc_options}

    tab_register, tab_queue, tab_all, tab_state = st.tabs([
        "➕ Register New Emergency",
        "📋 Priority Pending Queue",
        "🗃️ All Incident Records",
        "🔄 Status Transitions",
    ])

    with tab_register:
        st.markdown("#### Register New Emergency Incident")
        with st.form("register_emergency_form"):
            col1, col2 = st.columns(2)
            with col1:
                selected_loc_opt = st.selectbox("Incident Location Node:", loc_options, key="reg_loc")
                emergency_type = st.selectbox(
                    "Emergency Incident Type:",
                    [
                        "Cardiac Arrest / Chest Pain",
                        "Trauma / Severe Accident",
                        "Respiratory Distress / Asthma",
                        "Stroke / Neurological Emergency",
                        "Burns / Chemical Inhalation",
                        "Anaphylaxis / Severe Allergy",
                        "Fall / Orthopedic Injury",
                        "General Medical Emergency"
                    ],
                    key="reg_type"
                )
                severity = st.selectbox(
                    "Severity Urgency Level:",
                    ["Critical", "High", "Medium", "Low"],
                    index=1,
                    key="reg_sev"
                )
            with col2:
                arrival_time = st.number_input(
                    "Arrival Time (Simulation Minute):",
                    min_value=0.0,
                    value=float(simulation_service.get_current_time()),
                    step=0.5,
                    key="reg_arr",
                )
                patient_info = st.text_input(
                    "Patient Details (Age / Gender / Conscious Status):",
                    placeholder="e.g. 58M, conscious, diaphoretic",
                    key="reg_patient"
                )
                description = st.text_input(
                    "Incident Description & Symptoms:",
                    placeholder="e.g. Sudden severe crushing chest pain radiating to left arm",
                    key="reg_desc",
                )

            with st.expander("⚙️ Dynamic Priority Engine Tuning"):
                col_w1, col_w2 = st.columns(2)
                with col_w1:
                    sev_w = st.slider("Severity Weight (Base Multiplier):", min_value=1.0, max_value=50.0, value=DEFAULT_SEVERITY_WEIGHT, step=1.0)
                with col_w2:
                    wait_w = st.slider("Waiting-Time Escalation Weight (/min):", min_value=0.1, max_value=10.0, value=DEFAULT_WAITING_TIME_WEIGHT, step=0.1)

            submitted = st.form_submit_button("🚨 Submit & Calculate C++ Priority Score", use_container_width=True)

            if submitted:
                target_loc_id = loc_id_map[selected_loc_opt]
                full_desc = f"[{emergency_type}] {description}"
                if patient_info.strip():
                    full_desc += f" (Patient: {patient_info.strip()})"

                success, msg, created = incident_service.register_incident(
                    location=target_loc_id,
                    severity=severity,
                    description=full_desc,
                    arrival_time=arrival_time,
                    severity_weight=sev_w,
                    waiting_time_weight=wait_w,
                )
                if success:
                    st.success(msg)
                    st.info(
                        f"**Dynamic Priority Formula:** `Priority Score = ({sev_w} × Severity Multiplier) + ({wait_w} × Waiting Time in Minutes)`"
                    )
                    st.rerun()
                else:
                    st.error(msg)

    with tab_queue:
        st.markdown("#### Dynamically Ranked Priority Queue (C++ Priority Queue)")
        st.markdown(
            "<div class='resq-info-card'><b>Priority Scheduling:</b> Incidents are actively maintained in a <b>max-priority queue</b>. As simulation time advances, waiting times escalate, progressively increasing priority scores to prevent call starvation.</div>",
            unsafe_allow_html=True
        )
        if pending:
            df = pd.DataFrame(pending)[
                ["id", "location", "severity", "priority_score", "waiting_time", "arrival_time", "description"]
            ].copy()
            df["priority_score"] = df["priority_score"].map(lambda x: f"{float(x):.1f}")
            df["waiting_time"] = df["waiting_time"].map(lambda x: f"{float(x):.1f}")
            df["arrival_time"] = df["arrival_time"].map(lambda x: f"{float(x):.1f}")
            df.columns = ["Incident ID", "Location", "Severity", "Priority Score", "Waiting (min)", "Arrival (min)", "Description"]
            render_styled_table(df, badge_columns=["Severity"], max_rows=50)
            st.caption("Ranked in descending order of dynamic priority score. Tied scores resolve deterministically via FIFO arrival time.")
        else:
            st.info("No pending emergency incidents in queue.")

    with tab_all:
        st.markdown("#### All Registered Municipal Incidents")
        if all_inc:
            df_all = pd.DataFrame(all_inc)[
                ["id", "location", "severity", "status", "priority_score", "arrival_time", "waiting_time", "assigned_ambulance_id", "description"]
            ].copy()
            df_all["priority_score"] = df_all["priority_score"].map(lambda x: f"{float(x):.1f}")
            df_all["arrival_time"] = df_all["arrival_time"].map(lambda x: f"{float(x):.1f}")
            df_all["waiting_time"] = df_all["waiting_time"].map(lambda x: f"{float(x):.1f}")
            df_all["assigned_ambulance_id"] = df_all["assigned_ambulance_id"].replace("", "—")
            df_all.columns = ["ID", "Location", "Severity", "Status", "Priority", "Arrival", "Waiting", "Assigned Unit", "Description"]
            render_styled_table(df_all, badge_columns=["Severity", "Status"], max_rows=100)
        else:
            st.info("No records in incidents database.")

    with tab_state:
        st.markdown("#### Incident State Machine Transitions")
        st.markdown(
            "<div class='resq-info-card'><b>State Transition Rules:</b> <code>Pending</code> ➔ <code>Dispatched</code> ➔ <code>In-Transit</code> ➔ <code>Resolved</code> (or <code>Cancelled</code>). Invalid backward transitions are rejected by C++ validation.</div>",
            unsafe_allow_html=True,
        )

        inc_map = {f"{i['id']} ({i['status']}) - {i['location']}": i["id"] for i in all_inc}
        if inc_map:
            sel_inc_key = st.selectbox("Select Incident to Transition:", list(inc_map.keys()))
            target_inc_id = inc_map[sel_inc_key]
            current_inc = incident_service.get_incident_by_id(target_inc_id)

            st.write(f"Current Status: **`{current_inc['status']}`** | Location: **`{current_inc['location']}`** | Severity: **`{current_inc['severity']}`**")
            new_target_status = st.selectbox("Target New Status:", ["Pending", "Dispatched", "In-Transit", "Resolved", "Cancelled"])

            if st.button("Apply Status Transition", type="primary"):
                ok, tr_msg = incident_service.update_incident_status(target_inc_id, new_target_status)
                if ok:
                    st.success(tr_msg)
                    st.rerun()
                else:
                    st.error(tr_msg)
        else:
            st.info("No incidents available for transition.")
