import streamlit as st
import pandas as pd
import plotly.express as px
from services.incident_service import incident_service
from services.dispatch_service import dispatch_service
from simulation_service import simulation_service
from config import (
    DEFAULT_LOOKAHEAD_WEIGHTS,
    DEFAULT_SCENARIO_ROLLOUT_COUNT,
    DEFAULT_LOOKAHEAD_HORIZON_MIN,
    DEFAULT_RANDOM_SEED,
)
from ui.theme import (
    THEME_COLORS,
    render_page_header,
    render_kpi_card,
    render_styled_table,
    apply_plotly_theme,
    style_bar_traces,
)


def render_dispatch_page():
    render_page_header(
        title="Intelligent Dispatch Optimizer",
        subtitle="Counterfactual Look-Ahead Ambulance Dispatch Optimization evaluating immediate response, prospective delays, critical vulnerabilities, regional coverage loss, and detour impact.",
        module_badge="Module 2 • Counterfactual Look-Ahead Optimization",
    )

    pending_incidents = incident_service.get_pending_incidents()
    w_imm = DEFAULT_LOOKAHEAD_WEIGHTS["immediate_weight"]

    if pending_incidents:
        inc_choices = [
            f"{i['id']} [{i['severity']}] - {i['location']} : {i['description'][:45]}... (Priority: {i['priority_score']:.1f})"
            for i in pending_incidents
        ]
        selected_choice = st.selectbox("Select Pending Emergency Call to Dispatch:", inc_choices)
        selected_inc_id = selected_choice.split(" ")[0]
        target_inc = incident_service.get_incident_by_id(selected_inc_id)

        sev_color = (
            THEME_COLORS["critical"]
            if target_inc["severity"] == "Critical"
            else (THEME_COLORS["warning"] if target_inc["severity"] == "High" else THEME_COLORS["primary_btn"])
        )

        st.markdown(
            f"""
            <div class='resq-info-card' style='border-left-color: {sev_color};'>
                <b>Target Incident:</b> <code>{target_inc['id']}</code> |
                <b>Location:</b> <code>{target_inc['location']}</code> |
                <b>Severity:</b> <span style='color: {sev_color}; font-weight: 700;'>{target_inc['severity']}</span> |
                <b>Waiting Time:</b> {target_inc['waiting_time']:.1f} min |
                <b>Priority Score:</b> {target_inc['priority_score']:.1f}<br>
                <b>Description:</b> {target_inc['description']}
            </div>
            """,
            unsafe_allow_html=True,
        )

        with st.expander("⚙️ Configure Multi-Objective Look-Ahead Weights & Horizon", expanded=False):
            c1, c2, c3 = st.columns(3)
            with c1:
                w_imm = st.slider("Immediate Response Weight (w_imm):", 0.1, 5.0, DEFAULT_LOOKAHEAD_WEIGHTS["immediate_weight"], 0.1)
                w_fut = st.slider("Future Delay Penalty Weight (w_fut):", 0.1, 5.0, DEFAULT_LOOKAHEAD_WEIGHTS["future_delay_weight"], 0.1)
            with c2:
                w_crit = st.slider("Critical Delay Penalty (w_crit):", 0.1, 10.0, DEFAULT_LOOKAHEAD_WEIGHTS["critical_penalty_weight"], 0.5)
                w_cov = st.slider("Coverage Loss Penalty (w_cov):", 0.1, 5.0, DEFAULT_LOOKAHEAD_WEIGHTS["coverage_loss_weight"], 0.1)
            with c3:
                w_disrupt = st.slider("Road Disruption Penalty (w_disrupt):", 0.1, 5.0, DEFAULT_LOOKAHEAD_WEIGHTS["road_disruption_weight"], 0.1)
                horizon = st.slider("Evaluation Horizon (min):", 15.0, 90.0, DEFAULT_LOOKAHEAD_HORIZON_MIN, 5.0)

            c_scen1, c_scen2 = st.columns(2)
            with c_scen1:
                scen_count = st.number_input("Rollout Scenario Count:", min_value=1, max_value=20, value=DEFAULT_SCENARIO_ROLLOUT_COUNT)
            with c_scen2:
                seed = st.number_input("Deterministic Random Seed:", min_value=1, max_value=9999, value=DEFAULT_RANDOM_SEED)

        weights_dict = {
            "immediate_weight": w_imm,
            "future_delay_weight": w_fut,
            "critical_penalty_weight": w_crit,
            "coverage_loss_weight": w_cov,
            "road_disruption_weight": w_disrupt,
        }

        if st.button("🚀 Run Counterfactual Look-Ahead Dispatch Optimization", type="primary", use_container_width=True):
            with st.spinner("Executing C++ LookAheadOptimizer..."):
                success, msg, decision = dispatch_service.execute_dispatch(
                    incident_id=selected_inc_id,
                    current_sim_time=simulation_service.get_current_time(),
                    weights=weights_dict,
                    scenario_count=scen_count,
                    horizon_minutes=horizon,
                    random_seed=seed,
                )

            if not success:
                st.error(f"Dispatch Optimization Failed: {msg}")
            else:
                st.session_state["last_dispatch_decision"] = decision
                st.session_state["last_dispatch_w_imm"] = w_imm
                st.success(f"✅ **Optimal Dispatch Decision:** Assigned **{decision['selected_ambulance_id']}** to **{decision['incident_id']}**")
    else:
        st.warning("⚠️ No pending emergency incidents in queue. Register a new emergency in **🚨 Emergency Management** first.")

    if "last_dispatch_decision" in st.session_state:
        decision = st.session_state["last_dispatch_decision"]
        used_w_imm = st.session_state.get("last_dispatch_w_imm", w_imm)
        st.markdown(f"#### 🧠 Dispatch Result — `{decision['incident_id']}` ➔ `{decision['selected_ambulance_id']}`")

        m1, m2, m3, m4 = st.columns(4)
        with m1:
            render_kpi_card("Selected Unit", str(decision["selected_ambulance_id"]), "Optimal counterfactual choice", THEME_COLORS["available"])
        with m2:
            render_kpi_card(
                "Estimated Travel Time",
                f"{decision['estimated_travel_time_min']:.1f} min",
                f"{decision['estimated_distance_km']:.1f} km shortest path",
                THEME_COLORS["primary_btn"],
            )
        with m3:
            render_kpi_card(
                "Post-Dispatch Coverage",
                f"{decision['post_coverage_pct']:.1f}%",
                f"-{decision['coverage_loss_pct']:.1f}% coverage loss",
                THEME_COLORS["warning"],
            )
        with m4:
            render_kpi_card(
                "C++ Execution Time",
                f"{decision['computation_time_ms']:.2f} ms",
                "LookAheadOptimizer latency",
                THEME_COLORS["heading"],
            )

        st.info(f"💡 **Algorithmic Selection Justification:** {decision['selection_reason']}")

        st.markdown("---")
        st.markdown("#### 📊 Comprehensive Candidate Evaluation Breakdown")
        candidates = decision.get("candidate_evaluations", [])
        if candidates:
            cand_rows = []
            for c in candidates:
                cand_rows.append({
                    "Ambulance": c["ambulance_id"],
                    "Call Sign": c["call_sign"],
                    "Current Base": c["current_location"],
                    "Reachable": "Yes" if c["is_reachable"] else "No",
                    "Travel (min)": f"{c['travel_time_min']:.1f}" if c["is_reachable"] else "N/A",
                    "Immediate Cost": f"{c['immediate_response_cost']:.1f}" if c["is_reachable"] else "N/A",
                    "Future Delay": f"{c['future_delay_cost']:.1f}" if c["is_reachable"] else "N/A",
                    "Critical Penalty": f"{c['critical_delay_penalty']:.1f}" if c["is_reachable"] else "N/A",
                    "Coverage Loss": f"{c['coverage_loss_pct']:.1f}%" if c["is_reachable"] else "N/A",
                    "Total Cost": f"{c['total_cost']:.2f}" if c["is_reachable"] else "Inf",
                    "Explanation": c["rank_explanation"],
                })
            render_styled_table(pd.DataFrame(cand_rows), badge_columns=["Reachable"], max_rows=30)

            reachable_cands = [c for c in candidates if c["is_reachable"]]
            if reachable_cands:
                chart_data = []
                for c in reachable_cands:
                    chart_data.append({"Ambulance": c["ambulance_id"], "Cost Component": "Immediate Cost", "Cost": round(c["immediate_response_cost"] * used_w_imm, 2)})
                    chart_data.append({"Ambulance": c["ambulance_id"], "Cost Component": "Future Delay Penalty", "Cost": round(c["future_delay_cost"], 2)})
                    chart_data.append({"Ambulance": c["ambulance_id"], "Cost Component": "Critical Delay Penalty", "Cost": round(c["critical_delay_penalty"], 2)})
                    chart_data.append({"Ambulance": c["ambulance_id"], "Cost Component": "Coverage Loss Penalty", "Cost": round(c["coverage_loss_penalty"], 2)})
                    chart_data.append({"Ambulance": c["ambulance_id"], "Cost Component": "Road Disruption Penalty", "Cost": round(c["road_disruption_penalty"], 2)})

                component_colors = {
                    "Immediate Cost": "#142B45",
                    "Future Delay Penalty": "#5B7083",
                    "Critical Delay Penalty": "#DC3545",
                    "Coverage Loss Penalty": "#F59E0B",
                    "Road Disruption Penalty": "#198754",
                }
                fig_costs = px.bar(
                    pd.DataFrame(chart_data),
                    x="Ambulance",
                    y="Cost",
                    color="Cost Component",
                    barmode="stack",
                    color_discrete_map=component_colors,
                )
                apply_plotly_theme(
                    fig_costs,
                    title="Multi-Objective Cost Breakdown by Candidate Ambulance (Lowest Feasible Cost Wins)",
                    height=380,
                    show_legend=True,
                    xaxis_title="Candidate Ambulance",
                    yaxis_title="Weighted Objective Cost",
                )
                st.plotly_chart(fig_costs, use_container_width=True)

        st.caption("The candidate minimizing feasible total objective cost is dispatched. A unit with slightly longer immediate travel time may be selected if dispatching the nearest unit leaves a critical sector uncovered.")
