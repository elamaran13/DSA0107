import streamlit as st
import pandas as pd
from services.ambulance_service import ambulance_service
from services.road_service import road_service
from ui.theme import render_page_header, render_kpi_card, render_styled_table, THEME_COLORS


def render_ambulances_page():
    render_page_header(
        title="Ambulance Fleet Management",
        subtitle="Monitor real-time fleet readiness, station deployment, vehicle capabilities, fuel status, and operational state transitions.",
        module_badge="Fleet Operations & Readiness",
    )

    ambulances = ambulance_service.get_all_ambulances()
    locations = road_service.get_locations()
    loc_ids = [l["id"] for l in locations]

    total = len(ambulances)
    available = len([a for a in ambulances if a["status"] == "Available"])
    busy = len([a for a in ambulances if a["status"] == "Busy"])
    maint = len([a for a in ambulances if a["status"] == "Maintenance"])

    c1, c2, c3, c4 = st.columns(4)
    with c1:
        render_kpi_card("Total Fleet", str(total), "Registered EMS units", THEME_COLORS["primary_btn"])
    with c2:
        render_kpi_card("Available", str(available), "Ready for dispatch", THEME_COLORS["available"])
    with c3:
        render_kpi_card("Busy on Mission", str(busy), "Active response deployments", THEME_COLORS["warning"])
    with c4:
        render_kpi_card("Maintenance", str(maint), "Offline / servicing", THEME_COLORS["secondary_text"])

    st.markdown("<br>", unsafe_allow_html=True)

    col_table, col_ops = st.columns([3, 2])

    with col_table:
        st.markdown("#### 🚑 Fleet Roster & Availability")
        if ambulances:
            df_amb = pd.DataFrame(ambulances)[
                ["id", "call_sign", "current_location", "status", "station_id", "fuel_level", "assigned_incident_id", "busy_until_time"]
            ].copy()
            df_amb["fuel_level"] = df_amb["fuel_level"].map(lambda x: f"{float(x):.0f}%")
            df_amb["busy_until_time"] = df_amb["busy_until_time"].map(lambda x: f"{float(x):.1f}m")
            df_amb["assigned_incident_id"] = df_amb["assigned_incident_id"].replace("", "—")
            df_amb.columns = ["Unit ID", "Call Sign", "Location", "Status", "Home Station", "Fuel", "Assigned Incident", "Busy Until"]
            render_styled_table(df_amb, badge_columns=["Status"], max_rows=50)
        else:
            st.info("No ambulances registered in database.")

        with st.expander("➕ Register New Ambulance to Fleet", expanded=False):
            with st.form("add_ambulance_form"):
                new_id = st.text_input("Ambulance Unit ID:", value=f"AMB-{len(ambulances)+1:02d}")
                new_callsign = st.text_input("Call Sign:", placeholder="e.g. Medic-India")
                new_station = st.selectbox("Base Station Location:", loc_ids)
                new_loc = st.selectbox("Initial Deployment Location:", loc_ids)
                new_fuel = st.slider("Initial Fuel Level (%):", 50.0, 100.0, 100.0, 5.0)

                add_submit = st.form_submit_button("Register Ambulance", use_container_width=True)
                if add_submit:
                    ok, msg = ambulance_service.add_ambulance(
                        amb_id=new_id.strip(),
                        call_sign=new_callsign.strip(),
                        station_id=new_station,
                        current_location=new_loc,
                        fuel_level=new_fuel
                    )
                    if ok:
                        st.success(msg)
                        st.rerun()
                    else:
                        st.error(msg)

    with col_ops:
        st.markdown("#### ⚙️ Unit Status & Reassignment")
        amb_options = [f"{a['id']} ({a['call_sign']}) - {a['status']}" for a in ambulances]
        if amb_options:
            selected_amb_opt = st.selectbox("Select Ambulance Unit:", amb_options)
            target_amb_id = selected_amb_opt.split(" ")[0]
            amb_data = ambulance_service.get_ambulance_by_id(target_amb_id)

            st.markdown(
                f"""
                <div class='resq-info-card'>
                    <b>Selected Unit:</b> <code>{amb_data['id']}</code> ({amb_data['call_sign']})<br>
                    <b>Current Location:</b> <code>{amb_data['current_location']}</code> | <b>Status:</b> <b>{amb_data['status']}</b>
                </div>
                """,
                unsafe_allow_html=True,
            )

            with st.form("update_amb_form"):
                new_status = st.selectbox(
                    "Set Operating Status:",
                    ["Available", "Busy", "Maintenance"],
                    index=["Available", "Busy", "Maintenance"].index(amb_data["status"]),
                )
                new_loc = st.selectbox(
                    "Reassign Location Node:",
                    loc_ids,
                    index=loc_ids.index(amb_data["current_location"]) if amb_data["current_location"] in loc_ids else 0,
                )

                update_btn = st.form_submit_button("Update Ambulance State", use_container_width=True)
                if update_btn:
                    if new_status != amb_data["status"]:
                        ambulance_service.update_ambulance_status(target_amb_id, new_status)
                    if new_loc != amb_data["current_location"]:
                        ambulance_service.update_ambulance_location(target_amb_id, new_loc)
                    st.success(f"Ambulance {target_amb_id} updated successfully.")
                    st.rerun()

            if amb_data["status"] == "Busy":
                if st.button(f"🚨 Force Release {target_amb_id} to Available", type="primary", use_container_width=True):
                    ambulance_service.release_from_mission(target_amb_id)
                    st.success(f"Unit {target_amb_id} released.")
                    st.rerun()
        else:
            st.info("No ambulance units to manage.")
