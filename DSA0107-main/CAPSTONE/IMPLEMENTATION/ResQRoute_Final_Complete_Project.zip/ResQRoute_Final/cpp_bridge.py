import os
import sys
import json
import shutil
import subprocess
import logging
from pathlib import Path
from typing import Dict, Any, List, Optional, Tuple

from config import (
    CPP_ENGINE_DIR,
    CPP_ENGINE_EXE,
    DEFAULT_SEVERITY_WEIGHT,
    DEFAULT_WAITING_TIME_WEIGHT,
    DEFAULT_LOOKAHEAD_WEIGHTS,
    DEFAULT_COVERAGE_THRESHOLD_MIN,
    DEFAULT_SCENARIO_ROLLOUT_COUNT,
    DEFAULT_LOOKAHEAD_HORIZON_MIN,
    DEFAULT_RANDOM_SEED
)

logger = logging.getLogger("ResQRoute.CppBridge")

class CppEngineBridge:
    """
    Robust subprocess-based bridge connecting Python backend services
    with the compiled C++17 core computational engine.
    """

    def __init__(self, executable_path: Optional[Path] = None):
        self.exe_path = Path(executable_path) if executable_path else CPP_ENGINE_EXE

    def is_available(self) -> bool:
        return self.exe_path.exists() and os.access(self.exe_path, os.X_OK if os.name != "nt" else os.R_OK)

    def compile_engine(self) -> Tuple[bool, str]:
        """
        Attempts compilation of C++ engine using CMake or direct g++.
        """
        # 1. Try CMake if available
        cmake_bin = shutil.which("cmake")
        if not cmake_bin:
            venv_cmake = Path(sys.executable).parent / ("cmake.exe" if os.name == "nt" else "cmake")
            if venv_cmake.exists():
                cmake_bin = str(venv_cmake)

        if cmake_bin and (CPP_ENGINE_DIR / "CMakeLists.txt").exists():
            build_dir = CPP_ENGINE_DIR / "build"
            build_dir.mkdir(parents=True, exist_ok=True)
            cfg_cmd = [cmake_bin, "-S", str(CPP_ENGINE_DIR), "-B", str(build_dir), "-DCMAKE_BUILD_TYPE=Release"]
            if os.name == "nt" and shutil.which("mingw32-make"):
                cfg_cmd.extend(["-G", "MinGW Makefiles"])
            try:
                subprocess.run(cfg_cmd, capture_output=True, text=True, check=True)
                subprocess.run([cmake_bin, "--build", str(build_dir), "--config", "Release"], capture_output=True, text=True, check=True)
                if self.exe_path.exists():
                    return True, "C++ engine compiled successfully via CMake."
            except Exception as cmake_err:
                logger.warning("CMake build fallback to g++: %s", cmake_err)

        # 2. Direct compiler fallback (g++)
        gxx_bin = shutil.which("g++")
        if not gxx_bin and os.name == "nt":
            common_tdm = Path(r"C:\Program Files (x86)\Embarcadero\Dev-Cpp\TDM-GCC-64\bin\g++.exe")
            if common_tdm.exists():
                gxx_bin = str(common_tdm)

        if not gxx_bin:
            return False, "Neither CMake nor g++ compiler was found in PATH."

        src_files = [
            "src/main.cpp",
            "src/Incident.cpp",
            "src/Ambulance.cpp",
            "src/RoadNetwork.cpp",
            "src/PriorityEngine.cpp",
            "src/DispatchStrategy.cpp",
            "src/RouteOptimizer.cpp",
            "src/CoverageAnalyzer.cpp",
            "src/LookAheadOptimizer.cpp",
            "src/PerformanceEvaluator.cpp"
        ]

        cmd = [
            gxx_bin, "-std=c++17", "-O2", "-Iinclude"
        ] + src_files + ["-o", str(self.exe_path.name)]

        try:
            subprocess.run(
                cmd,
                cwd=str(CPP_ENGINE_DIR),
                capture_output=True,
                text=True,
                check=True
            )
            return True, "C++ engine compiled successfully via g++."
        except Exception as e:
            err_msg = f"Failed to compile C++ engine: {e}"
            if hasattr(e, "stderr") and e.stderr:
                err_msg += f"\nCompiler output: {e.stderr}"
            logger.error(err_msg)
            return False, err_msg

    def _execute(self, mode: str, payload: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        """
        Invokes resqroute_engine with --mode and passes JSON payload through stdin.
        """
        if not self.is_available():
            success, msg = self.compile_engine()
            if not success:
                return {
                    "success": False,
                    "error": f"C++ engine executable not available and auto-compilation failed: {msg}"
                }

        cmd = [str(self.exe_path), "--mode", mode]
        input_data = json.dumps(payload if payload is not None else {})

        try:
            process = subprocess.run(
                cmd,
                input=input_data,
                capture_output=True,
                text=True,
                timeout=30.0,
                check=False
            )

            if process.returncode != 0:
                logger.error("Engine returned error code %s: %s", process.returncode, process.stderr)
                try:
                    return json.loads(process.stdout or process.stderr)
                except Exception:
                    return {
                        "success": False,
                        "error": f"C++ engine process exited with code {process.returncode}: {process.stderr}"
                    }

            return json.loads(process.stdout)
        except subprocess.TimeoutExpired:
            return {"success": False, "error": "C++ engine execution timed out after 30 seconds."}
        except json.JSONDecodeError as jde:
            return {"success": False, "error": f"Failed to parse engine JSON output: {jde}\nRaw stdout: {process.stdout}"}
        except Exception as ex:
            return {"success": False, "error": f"Subprocess invocation failure: {str(ex)}"}

    def ping(self) -> Dict[str, Any]:
        return self._execute("ping")

    def prioritize_incidents(
        self,
        incidents: List[Dict[str, Any]],
        current_sim_time: float = 0.0,
        severity_weight: float = DEFAULT_SEVERITY_WEIGHT,
        waiting_time_weight: float = DEFAULT_WAITING_TIME_WEIGHT
    ) -> Dict[str, Any]:
        payload = {
            "incidents": incidents,
            "current_sim_time": current_sim_time,
            "severity_weight": severity_weight,
            "waiting_time_weight": waiting_time_weight
        }
        return self._execute("prioritize", payload)

    def compute_route(
        self,
        source: str,
        destination: str,
        road_network: Optional[Dict[str, Any]] = None,
        ignore_closures: bool = False
    ) -> Dict[str, Any]:
        payload = {
            "source": source,
            "destination": destination,
            "ignore_closures": ignore_closures
        }
        if road_network:
            payload["road_network"] = road_network
        return self._execute("route", payload)

    def compute_coverage(
        self,
        road_network: Optional[Dict[str, Any]] = None,
        ambulances: Optional[List[Dict[str, Any]]] = None,
        threshold_minutes: float = DEFAULT_COVERAGE_THRESHOLD_MIN,
        candidate_id: Optional[str] = None
    ) -> Dict[str, Any]:
        payload = {
            "threshold_minutes": threshold_minutes
        }
        if road_network:
            payload["road_network"] = road_network
        if ambulances:
            payload["ambulances"] = ambulances
        if candidate_id:
            payload["candidate_id"] = candidate_id
        return self._execute("coverage", payload)

    def dispatch_incident(
        self,
        incident: Dict[str, Any],
        ambulances: List[Dict[str, Any]],
        road_network: Dict[str, Any],
        pending_queue: Optional[List[Dict[str, Any]]] = None,
        current_sim_time: float = 0.0,
        weights: Optional[Dict[str, float]] = None,
        scenario_count: int = DEFAULT_SCENARIO_ROLLOUT_COUNT,
        horizon_minutes: float = DEFAULT_LOOKAHEAD_HORIZON_MIN,
        random_seed: int = DEFAULT_RANDOM_SEED
    ) -> Dict[str, Any]:
        payload = {
            "incident": incident,
            "ambulances": ambulances,
            "road_network": road_network,
            "pending_queue": pending_queue or [],
            "current_sim_time": current_sim_time,
            "weights": weights or DEFAULT_LOOKAHEAD_WEIGHTS,
            "scenario_count": scenario_count,
            "horizon_minutes": horizon_minutes,
            "random_seed": random_seed
        }
        return self._execute("dispatch", payload)

    def evaluate_scenario(self, scenario_id: str = "SCENARIO_A") -> Dict[str, Any]:
        payload = {"scenario_id": scenario_id}
        return self._execute("evaluate", payload)

    def list_scenarios(self) -> List[Dict[str, Any]]:
        return self._execute("list_scenarios")


# Global bridge singleton
engine_bridge = CppEngineBridge()
