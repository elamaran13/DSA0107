import sqlite3
import json
import logging
from typing import Dict, Any, List, Optional
from pathlib import Path
from config import DATABASE_PATH

logger = logging.getLogger("ResQRoute.Database")

def get_connection(db_path: Optional[Path] = None) -> sqlite3.Connection:
    path = db_path or DATABASE_PATH
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(str(path), timeout=30.0)
    conn.row_factory = sqlite3.Row
    conn.execute("PRAGMA foreign_keys = ON;")
    return conn

def init_db(db_path: Optional[Path] = None) -> None:
    """
    Creates all required SQLite database tables, constraints, and indexes.
    """
    conn = get_connection(db_path)
    cursor = conn.cursor()

    cursor.executescript("""
    CREATE TABLE IF NOT EXISTS locations (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        type TEXT NOT NULL,
        demand_weight REAL DEFAULT 1.0,
        latitude REAL,
        longitude REAL
    );

    CREATE TABLE IF NOT EXISTS roads (
        road_id TEXT PRIMARY KEY,
        source TEXT NOT NULL,
        destination TEXT NOT NULL,
        distance_km REAL NOT NULL,
        speed_limit_kmh REAL NOT NULL,
        travel_time_min REAL NOT NULL,
        is_closed INTEGER DEFAULT 0,
        closure_reason TEXT DEFAULT '',
        is_bidirectional INTEGER DEFAULT 1,
        FOREIGN KEY (source) REFERENCES locations(id),
        FOREIGN KEY (destination) REFERENCES locations(id)
    );

    CREATE TABLE IF NOT EXISTS road_closures (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        road_id TEXT NOT NULL,
        closed_at TEXT DEFAULT CURRENT_TIMESTAMP,
        reopened_at TEXT,
        reason TEXT NOT NULL,
        is_active INTEGER DEFAULT 1,
        FOREIGN KEY (road_id) REFERENCES roads(road_id)
    );

    CREATE TABLE IF NOT EXISTS ambulances (
        id TEXT PRIMARY KEY,
        call_sign TEXT NOT NULL,
        current_location TEXT NOT NULL,
        status TEXT NOT NULL CHECK(status IN ('Available', 'Busy', 'Maintenance')),
        station_id TEXT NOT NULL,
        fuel_level REAL DEFAULT 100.0,
        assigned_incident_id TEXT DEFAULT '',
        busy_until_time REAL DEFAULT 0.0,
        FOREIGN KEY (current_location) REFERENCES locations(id),
        FOREIGN KEY (station_id) REFERENCES locations(id)
    );

    CREATE TABLE IF NOT EXISTS incidents (
        id TEXT PRIMARY KEY,
        location TEXT NOT NULL,
        severity TEXT NOT NULL CHECK(severity IN ('Critical', 'High', 'Medium', 'Low')),
        arrival_time REAL NOT NULL,
        waiting_time REAL DEFAULT 0.0,
        description TEXT NOT NULL,
        status TEXT NOT NULL CHECK(status IN ('Pending', 'Dispatched', 'In-Transit', 'Resolved', 'Cancelled')),
        priority_score REAL DEFAULT 0.0,
        severity_weight REAL DEFAULT 25.0,
        waiting_time_weight REAL DEFAULT 2.0,
        assigned_ambulance_id TEXT DEFAULT '',
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (location) REFERENCES locations(id)
    );

    CREATE TABLE IF NOT EXISTS assignments (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        incident_id TEXT NOT NULL,
        ambulance_id TEXT NOT NULL,
        assigned_at REAL NOT NULL,
        status TEXT NOT NULL,
        FOREIGN KEY (incident_id) REFERENCES incidents(id),
        FOREIGN KEY (ambulance_id) REFERENCES ambulances(id)
    );

    CREATE TABLE IF NOT EXISTS dispatch_decisions (
        decision_id TEXT PRIMARY KEY,
        incident_id TEXT NOT NULL,
        selected_ambulance_id TEXT,
        strategy_name TEXT NOT NULL,
        is_feasible INTEGER NOT NULL,
        estimated_travel_time_min REAL,
        estimated_distance_km REAL,
        total_cost REAL,
        pre_coverage_pct REAL,
        post_coverage_pct REAL,
        coverage_loss_pct REAL,
        selection_reason TEXT,
        computation_time_ms REAL,
        simulation_time REAL,
        created_at TEXT DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (incident_id) REFERENCES incidents(id)
    );

    CREATE TABLE IF NOT EXISTS candidate_evaluations (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        decision_id TEXT NOT NULL,
        ambulance_id TEXT NOT NULL,
        call_sign TEXT,
        is_reachable INTEGER NOT NULL,
        travel_time_min REAL,
        travel_distance_km REAL,
        immediate_response_cost REAL,
        future_delay_cost REAL,
        critical_delay_penalty REAL,
        coverage_loss_penalty REAL,
        road_disruption_penalty REAL,
        total_cost REAL,
        remaining_coverage_pct REAL,
        coverage_loss_pct REAL,
        rank_explanation TEXT,
        FOREIGN KEY (decision_id) REFERENCES dispatch_decisions(decision_id)
    );

    CREATE TABLE IF NOT EXISTS simulation_runs (
        run_id TEXT PRIMARY KEY,
        scenario_id TEXT NOT NULL,
        run_timestamp TEXT DEFAULT CURRENT_TIMESTAMP,
        settings_json TEXT
    );

    CREATE TABLE IF NOT EXISTS simulation_results (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        run_id TEXT NOT NULL,
        strategy_name TEXT NOT NULL,
        total_incidents INTEGER,
        incidents_served INTEGER,
        incidents_unserved INTEGER,
        completion_rate_pct REAL,
        avg_response_time_min REAL,
        median_response_time_min REAL,
        critical_avg_response_time_min REAL,
        critical_avg_waiting_time_min REAL,
        total_travel_distance_km REAL,
        final_remaining_coverage_pct REAL,
        avg_coverage_loss_pct REAL,
        total_computation_time_ms REAL,
        avg_computation_time_ms REAL,
        FOREIGN KEY (run_id) REFERENCES simulation_runs(run_id)
    );

    CREATE TABLE IF NOT EXISTS scenario_definitions (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        description TEXT NOT NULL,
        incident_count INTEGER,
        fleet_count INTEGER
    );

    CREATE INDEX IF NOT EXISTS idx_incident_status ON incidents(status);
    CREATE INDEX IF NOT EXISTS idx_ambulance_status ON ambulances(status);
    CREATE INDEX IF NOT EXISTS idx_roads_closure ON roads(is_closed);
    CREATE INDEX IF NOT EXISTS idx_eval_decision ON candidate_evaluations(decision_id);
    """)

    conn.commit()
    conn.close()
    logger.info("SQLite database tables verified at %s", str(db_path or DATABASE_PATH))

def reset_database(db_path: Optional[Path] = None, confirm: bool = False) -> bool:
    """
    Safely resets all table data requiring explicit confirmation flag.
    """
    if not confirm:
        raise ValueError("Explicit confirmation (confirm=True) is required to reset the database.")

    conn = get_connection(db_path)
    cursor = conn.cursor()
    tables = [
        "candidate_evaluations",
        "dispatch_decisions",
        "assignments",
        "simulation_results",
        "simulation_runs",
        "road_closures",
        "roads",
        "incidents",
        "ambulances",
        "locations",
        "scenario_definitions"
    ]
    cursor.execute("PRAGMA foreign_keys = OFF;")
    for table in tables:
        cursor.execute(f"DELETE FROM {table};")
    cursor.execute("PRAGMA foreign_keys = ON;")
    conn.commit()
    conn.close()
    logger.info("Database reset completed successfully.")
    return True
