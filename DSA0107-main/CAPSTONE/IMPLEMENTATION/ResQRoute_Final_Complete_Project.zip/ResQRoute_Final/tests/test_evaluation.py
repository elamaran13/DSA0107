import pytest
from services.evaluation_service import evaluation_service

def test_evaluation_scenarios_listing():
    scenarios = evaluation_service.get_available_scenarios()
    assert len(scenarios) >= 8
    scen_ids = [s["id"] for s in scenarios]
    for s_id in ["SCENARIO_A", "SCENARIO_B", "SCENARIO_C", "SCENARIO_D", "SCENARIO_E", "SCENARIO_F", "SCENARIO_G", "SCENARIO_H"]:
        assert s_id in scen_ids

def test_scenario_a_benchmark_execution():
    res = evaluation_service.run_benchmark("SCENARIO_A")
    assert "strategies" in res
    strategies = res["strategies"]
    assert "nearest_available" in strategies
    assert "immediate_scoring" in strategies
    assert "lookahead_optimizer" in strategies

    for s_name, s_data in strategies.items():
        assert s_data["total_incidents"] == 4
        assert s_data["incidents_served"] <= 4
        assert s_data["avg_response_time_min"] >= 0.0
        assert s_data["avg_computation_time_ms"] >= 0.0

def test_dataframe_and_csv_export():
    res = evaluation_service.run_benchmark("SCENARIO_A")
    df = evaluation_service.get_comparison_dataframe(res)
    assert not df.empty
    assert len(df) == 3  # 3 strategies
    csv_path = evaluation_service.export_benchmark_csv(res)
    assert csv_path.endswith(".csv")
