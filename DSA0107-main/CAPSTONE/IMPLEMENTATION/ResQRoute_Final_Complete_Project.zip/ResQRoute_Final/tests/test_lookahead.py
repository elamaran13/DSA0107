import pytest
from cpp_bridge import engine_bridge
from services.road_service import road_service

def test_lookahead_optimizer_execution():
    network = road_service.get_road_network_payload()
    incident = {
        "id": "INC-TEST-LA",
        "location": "LOC-03",
        "severity": "Critical",
        "arrival_time": 2.0,
        "waiting_time": 0.0,
        "description": "Severe incident",
        "status": "Pending"
    }
    ambulances = [
        {"id": "AMB-01", "call_sign": "Medic-1", "current_location": "LOC-01", "status": "Available"},
        {"id": "AMB-02", "call_sign": "Medic-2", "current_location": "LOC-05", "status": "Available"}
    ]

    res = engine_bridge.dispatch_incident(
        incident=incident,
        ambulances=ambulances,
        road_network=network,
        pending_queue=[],
        current_sim_time=2.0
    )

    assert res["success"] is True
    decision = res["decision"]
    assert decision["is_feasible"] is True
    assert decision["selected_ambulance_id"] in ["AMB-01", "AMB-02"]
    assert decision["estimated_travel_time_min"] > 0
    assert len(decision["candidate_evaluations"]) == 2
    assert decision["computation_time_ms"] >= 0

def test_lookahead_all_busy():
    network = road_service.get_road_network_payload()
    incident = {
        "id": "INC-BUSY-TEST",
        "location": "LOC-03",
        "severity": "Medium",
        "arrival_time": 5.0,
        "waiting_time": 0.0,
        "description": "Routine call",
        "status": "Pending"
    }
    # All ambulances busy
    ambulances = [
        {"id": "AMB-01", "call_sign": "Medic-1", "current_location": "LOC-01", "status": "Busy"},
        {"id": "AMB-02", "call_sign": "Medic-2", "current_location": "LOC-05", "status": "Busy"}
    ]

    res = engine_bridge.dispatch_incident(
        incident=incident,
        ambulances=ambulances,
        road_network=network,
        pending_queue=[],
        current_sim_time=5.0
    )

    assert res["success"] is True
    decision = res["decision"]
    assert decision["is_feasible"] is False
    assert decision["selected_ambulance_id"] == ""
