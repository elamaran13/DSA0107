import pytest
from services.road_service import road_service
from services.ambulance_service import ambulance_service

def test_coverage_calculation():
    ambs = ambulance_service.get_all_ambulances()
    res = road_service.analyze_coverage(ambs, threshold_minutes=10.0)
    assert "weighted_coverage_pct" in res
    assert res["total_locations"] == 16
    assert res["covered_locations_count"] > 0
    assert 0.0 <= res["weighted_coverage_pct"] <= 100.0

def test_coverage_loss_after_dispatch():
    ambs = ambulance_service.get_all_ambulances()
    # Evaluate impact of dispatching AMB-01
    res = road_service.analyze_coverage(ambs, threshold_minutes=10.0, candidate_id="AMB-01")
    assert "pre_dispatch_coverage" in res
    assert "post_dispatch_coverage" in res
    assert "coverage_loss_pct" in res
    assert res["coverage_loss_pct"] >= 0.0
