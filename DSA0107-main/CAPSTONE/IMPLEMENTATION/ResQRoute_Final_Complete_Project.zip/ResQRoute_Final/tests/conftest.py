import sys
import pytest
from pathlib import Path

# Add project root directory to sys.path so tests can run from any working directory
PROJECT_ROOT = Path(__file__).resolve().parent.parent
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

@pytest.fixture(scope="session", autouse=True)
def setup_test_environment():
    """Ensure database and seed data are ready before running tests."""
    from database import init_db
    from data_manager import data_manager
    init_db()
    data_manager.load_csv_to_db()
