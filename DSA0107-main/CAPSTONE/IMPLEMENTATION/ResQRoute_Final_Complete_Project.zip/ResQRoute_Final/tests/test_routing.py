import pytest
from services.road_service import road_service

def test_dijkstra_shortest_path():
    res = road_service.calculate_route("LOC-01", "LOC-03")
    assert res["success"] is True
    route = res["route"]
    assert route["is_reachable"] is True
    assert route["path_nodes"][0] == "LOC-01"
    assert route["path_nodes"][-1] == "LOC-03"
    assert route["total_distance_km"] > 0
    assert route["total_travel_time_min"] > 0

def test_road_closure_rerouting():
    # Close direct link RD-01 (LOC-01 <-> LOC-03)
    road_service.close_road("RD-01", "Testing road closure")

    # Compute path with closure active
    res_closed = road_service.calculate_route("LOC-01", "LOC-03", ignore_closures=False)
    assert res_closed["success"] is True
    route_closed = res_closed["route"]

    # Compute baseline path ignoring closure
    res_base = road_service.calculate_route("LOC-01", "LOC-03", ignore_closures=True)
    route_base = res_base["route"]

    # Detour path must take longer than direct baseline path
    assert route_closed["total_travel_time_min"] > route_base["total_travel_time_min"]

    # Reopen
    road_service.reopen_road("RD-01")

def test_unreachable_destination():
    # Close RD-24 leading to isolated peninsula LOC-16
    road_service.close_road("RD-24", "Bridge severed")
    res = road_service.calculate_route("LOC-01", "LOC-16", ignore_closures=False)
    assert res["success"] is False
    assert res["route"]["is_reachable"] is False

    # Cleanup
    road_service.reopen_road("RD-24")
