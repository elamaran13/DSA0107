import pytest
from services.ambulance_service import AmbulanceService
from services.dispatch_service import DispatchService
from services.incident_service import IncidentService

def test_ambulance_state_transitions():
    srv = AmbulanceService()
    # Test valid status
    ok, _ = srv.update_ambulance_status("AMB-01", "Busy")
    assert ok is True
    amb = srv.get_ambulance_by_id("AMB-01")
    assert amb["status"] == "Busy"

    # Test invalid status
    ok, msg = srv.update_ambulance_status("AMB-01", "Flying")
    assert ok is False

    # Restore to Available
    srv.update_ambulance_status("AMB-01", "Available")

def test_prevent_double_assignment():
    inc_srv = IncidentService()
    amb_srv = AmbulanceService()

    # Ensure test incidents exist
    ok1, _, inc1 = inc_srv.register_incident("LOC-01", "High", "Dispatch unit test incident 1")
    ok2, _, inc2 = inc_srv.register_incident("LOC-02", "Medium", "Dispatch unit test incident 2")

    inc1_id = inc1["id"]
    inc2_id = inc2["id"]

    # Assign AMB-02 to mission
    ok, _ = amb_srv.assign_to_mission("AMB-02", inc1_id, duration_min=20.0, current_sim_time=5.0)
    assert ok is True

    # Attempt to assign already busy ambulance
    ok_double, err_msg = amb_srv.assign_to_mission("AMB-02", inc2_id, duration_min=15.0, current_sim_time=6.0)
    assert ok_double is False
    assert "currently Busy" in err_msg

    # Release
    amb_srv.release_from_mission("AMB-02")
    amb = amb_srv.get_ambulance_by_id("AMB-02")
    assert amb["status"] == "Available"
