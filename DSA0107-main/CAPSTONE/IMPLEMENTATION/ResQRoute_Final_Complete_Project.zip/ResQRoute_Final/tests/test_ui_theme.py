import plotly.express as px
import pandas as pd
from ui.theme import THEME_COLORS, STRATEGY_COLOR_MAP, apply_plotly_theme, style_bar_traces
from ui import (
    dashboard,
    incidents_page,
    ambulances_page,
    dispatch_page,
    road_network_page,
    evaluation_page,
    database_page,
)


def test_theme_palette_tokens():
    assert THEME_COLORS["main_bg"] == "#F3F6FA"
    assert THEME_COLORS["sidebar_bg"] == "#10243A"
    assert THEME_COLORS["heading"] == "#142B45"
    assert THEME_COLORS["text"] == "#000000"
    assert THEME_COLORS["secondary_text"] == "#333333"
    assert THEME_COLORS["card_bg"] == "#FFFFFF"
    assert THEME_COLORS["primary_btn"] == "#174A78"
    assert THEME_COLORS["btn_text"] == "#FFFFFF"
    assert THEME_COLORS["critical"] == "#DC3545"
    assert THEME_COLORS["available"] == "#198754"
    assert THEME_COLORS["warning"] == "#F59E0B"
    assert THEME_COLORS["border"] == "#D9E1EA"


def test_strategy_color_mapping():
    assert "Nearest-Available Baseline" in STRATEGY_COLOR_MAP
    assert "Immediate Priority-Coverage Baseline" in STRATEGY_COLOR_MAP
    assert "Counterfactual Look-Ahead Optimizer" in STRATEGY_COLOR_MAP
    assert STRATEGY_COLOR_MAP["Counterfactual Look-Ahead Optimizer"] == "#142B45"


def test_plotly_theme_application():
    df = pd.DataFrame({
        "Strategy": list(STRATEGY_COLOR_MAP.keys()),
        "Score": [12.3, 10.5, 8.2],
    })
    fig = px.bar(df, x="Strategy", y="Score", color="Strategy", color_discrete_map=STRATEGY_COLOR_MAP)
    apply_plotly_theme(fig, title="Test Chart", height=320)
    style_bar_traces(fig, value_format=".1f")

    assert fig.layout.paper_bgcolor == "#FFFFFF"
    assert fig.layout.plot_bgcolor == "#FFFFFF"
    assert fig.layout.title.font.color == "#142B45"
    assert fig.layout.font.color == "#000000"
    assert fig.layout.xaxis.tickfont.color == "#000000"
    assert fig.layout.yaxis.tickfont.color == "#000000"


def test_all_ui_modules_importable():
    for mod in [dashboard, incidents_page, ambulances_page, dispatch_page, road_network_page, evaluation_page, database_page]:
        assert mod is not None
