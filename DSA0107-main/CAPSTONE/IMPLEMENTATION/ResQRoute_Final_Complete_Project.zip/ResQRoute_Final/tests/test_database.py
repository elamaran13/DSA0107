import pytest
from database import get_connection, init_db, reset_database
from data_manager import data_manager

def test_database_initialization():
    init_db()
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table';")
    tables = [row["name"] for row in cursor.fetchall()]
    conn.close()

    expected = [
        "locations", "roads", "road_closures", "ambulances",
        "incidents", "assignments", "dispatch_decisions",
        "candidate_evaluations", "simulation_runs", "simulation_results"
    ]
    for tbl in expected:
        assert tbl in tables

def test_data_persistence_and_reset():
    # Verify data exists
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) as cnt FROM locations;")
    count_before = cursor.fetchone()["cnt"]
    conn.close()
    assert count_before >= 16

    # Test reset requires confirmation
    with pytest.raises(ValueError):
        reset_database(confirm=False)

    # Confirm and reload
    data_manager.reset_and_reload(confirm=True)
    conn = get_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT COUNT(*) as cnt FROM locations;")
    count_after = cursor.fetchone()["cnt"]
    conn.close()
    assert count_after == count_before
