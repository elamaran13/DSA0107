import pytest
from services.incident_service import IncidentService
from cpp_bridge import engine_bridge

def test_priority_engine_calculation():
    incidents = [
        {"id": "INC-T1", "location": "LOC-01", "severity": "Critical", "arrival_time": 0.0, "waiting_time": 0.0, "description": "Cardiac arrest", "status": "Pending"},
        {"id": "INC-T2", "location": "LOC-02", "severity": "Low", "arrival_time": 0.0, "waiting_time": 0.0, "description": "Minor sprain", "status": "Pending"}
    ]
    res = engine_bridge.prioritize_incidents(incidents, current_sim_time=0.0, severity_weight=25.0, waiting_time_weight=2.0)
    assert res["success"] is True
    queue = res["ranked_pending_queue"]
    assert len(queue) == 2
    # Critical should have higher priority score than Low
    assert queue[0]["id"] == "INC-T1"
    assert queue[0]["priority_score"] == 100.0  # 4 * 25
    assert queue[1]["priority_score"] == 25.0   # 1 * 25

def test_waiting_time_advancement():
    incidents = [
        {"id": "INC-T3", "location": "LOC-03", "severity": "Medium", "arrival_time": 5.0, "waiting_time": 0.0, "description": "Laceration", "status": "Pending"}
    ]
    # Advance time to 15.0 -> waiting time = 10.0 min -> Priority = (2 * 25) + (10 * 2) = 70.0
    res = engine_bridge.prioritize_incidents(incidents, current_sim_time=15.0, severity_weight=25.0, waiting_time_weight=2.0)
    assert res["success"] is True
    inc = res["ranked_pending_queue"][0]
    assert inc["waiting_time"] == 10.0
    assert inc["priority_score"] == 70.0

def test_incident_service_validation():
    srv = IncidentService()
    # Invalid severity
    ok, msg, _ = srv.register_incident("LOC-01", "SevereEmergency", "Desc")
    assert ok is False
    assert "Invalid severity level" in msg

    # Empty description
    ok, msg, _ = srv.register_incident("LOC-01", "Critical", "")
    assert ok is False
    assert "description is required" in msg
