# Antigravity Execution Guide for ResQRoute

This guide explains how to open, build, test, and run the **ResQRoute** project within **Google Antigravity**.

---

## 1. Opening the Project in Antigravity

1. Launch the **Antigravity IDE** or open your workspace.
2. Open the folder containing the project:
   ```
   ResQRoute_Final
   ```
3. Open an Antigravity terminal session in the workspace directory.

---

## 2. Environment Setup

Run the setup batch script from the terminal:

```powershell
.\setup.bat
```

Alternatively, you can manually trigger environment creation and tests:
```powershell
# 1. Create venv
python -m venv .venv

# 2. Install dependencies
.\.venv\Scripts\pip.exe install -r requirements.txt

# 3. Build C++ Engine
cd cpp_engine
.\build_engine.bat
cd ..

# 4. Initialize Database
.\.venv\Scripts\python.exe -c "from database import init_db; from data_manager import data_manager; init_db(); data_manager.load_csv_to_db(overwrite=True)"
```

---

## 3. Launching the Dashboard

To launch the web dashboard:

```powershell
.\run.bat
```

Or invoke the dynamic port launcher directly:
```powershell
.\.venv\Scripts\python.exe launcher.py
```

The launcher will:
- Automatically select an open port (preferring `8501`, falling back to `8502+` if occupied).
- Wait for the Streamlit health endpoint to respond.
- Open the clean browser address: `http://127.0.0.1:8501`.

---

## 4. Running Verification Tests in Antigravity

### Python Unit & Integration Tests:
```powershell
.\.venv\Scripts\python.exe -m pytest tests -v
```

### C++ Core Engine Tests:
```powershell
.\cpp_engine\resqroute_tests.exe
```

### Engine CLI Communication Ping:
```powershell
.\cpp_engine\resqroute_engine.exe --mode ping
```

---

## 5. Clean Termination

To gracefully stop the dashboard, press `Ctrl + C` in the running terminal. The launcher cleanly terminates only the ResQRoute server process, keeping other active workspaces and servers untouched.
