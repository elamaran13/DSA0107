@echo off
setlocal enabledelayedexpansion

:: 1. Navigate to project root directory
cd /d "%~dp0"

:: 2. Check if this is a parent/wrapper folder containing ResQRoute_Final
if exist "%~dp0ResQRoute_Final\run.bat" (
    cd /d "%~dp0ResQRoute_Final"
    call run.bat %*
    exit /b !ERRORLEVEL!
)

echo =====================================================================
echo ResQRoute: Intelligent Emergency Vehicle Dispatch System
echo Counterfactual Look-Ahead Dispatch ^& Dynamic Route Prioritization
echo =====================================================================
echo.

:: 3. Locate Python executable (prefer .venv, fallback to system Python if available)
set "PY_EXE="
if exist ".venv\Scripts\python.exe" (
    set "PY_EXE=.venv\Scripts\python.exe"
    echo [OK] Using virtual environment: .venv\Scripts\python.exe
) else (
    where python >nul 2>&1
    if !ERRORLEVEL! EQU 0 (
        python -c "import streamlit, pandas, numpy, plotly, pytest" >nul 2>&1
        if !ERRORLEVEL! EQU 0 (
            set "PY_EXE=python"
            echo [OK] Using system Python environment with verified packages.
        )
    )
    if not defined PY_EXE (
        echo [*] Virtual environment not detected. Automatically running first-time setup...
        call setup.bat
        if exist ".venv\Scripts\python.exe" (
            set "PY_EXE=.venv\Scripts\python.exe"
        ) else (
            echo [ERROR] Setup could not prepare the Python environment.
            pause
            exit /b 1
        )
    )
)

:: 4. Verify C++ Engine executable
if not exist "cpp_engine\resqroute_engine.exe" (
    echo [*] C++ Engine binary missing. Attempting auto-compilation...
    "!PY_EXE!" -c "from cpp_bridge import engine_bridge; ok, msg = engine_bridge.compile_engine(); print(msg); exit(0 if ok else 1)"
    if !ERRORLEVEL! NEQ 0 (
        echo [ERROR] Failed to compile C++ engine.
        echo Run .\setup.bat or check compiler installation.
        echo.
        pause
        exit /b 1
    )
)

:: 5. Verify SQLite database
if not exist "database\resqroute.db" (
    echo [*] SQLite database not detected. Initializing database...
    "!PY_EXE!" -c "from database import init_db; from data_manager import data_manager; init_db(); data_manager.load_csv_to_db()"
    if !ERRORLEVEL! NEQ 0 (
        echo [ERROR] Failed to initialize SQLite database.
        echo.
        pause
        exit /b 1
    )
)

:: 6. Quick check mode validation
if "%1"=="--check" (
    echo [OK] All ResQRoute runtime components verified successfully.
    exit /b 0
)

:: 7. Launch via dynamic port launcher
echo [*] Launching ResQRoute dynamic launcher...
"!PY_EXE!" launcher.py %*
if !ERRORLEVEL! NEQ 0 (
    echo.
    echo [ERROR] Application exited with error code !ERRORLEVEL!.
    pause
    exit /b !ERRORLEVEL!
)

endlocal
