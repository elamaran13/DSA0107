#include "Ambulance.h"

Ambulance::Ambulance()
    : id(""), call_sign(""), current_location(""), status("Available"),
      station_id(""), fuel_level(100.0), assigned_incident_id(""), busy_until_time(0.0) {}

Ambulance::Ambulance(const std::string& id,
                     const std::string& call_sign,
                     const std::string& current_location,
                     const std::string& status,
                     const std::string& station_id,
                     double fuel_level,
                     const std::string& assigned_incident_id,
                     double busy_until_time)
    : id(id), call_sign(call_sign), current_location(current_location), status(status),
      station_id(station_id.empty() ? current_location : station_id),
      fuel_level(fuel_level), assigned_incident_id(assigned_incident_id),
      busy_until_time(busy_until_time) {}

bool Ambulance::assign_mission(const std::string& incident_id, double mission_duration, double current_time) {
    if (!is_available()) return false;
    status = "Busy";
    assigned_incident_id = incident_id;
    busy_until_time = current_time + mission_duration;
    return true;
}

void Ambulance::release_mission() {
    status = "Available";
    assigned_incident_id = "";
    busy_until_time = 0.0;
}

void Ambulance::update_status(double current_sim_time) {
    if (status == "Busy" && current_sim_time >= busy_until_time) {
        release_mission();
    }
}

nlohmann::json Ambulance::to_json() const {
    nlohmann::json j;
    j["id"] = id;
    j["call_sign"] = call_sign;
    j["current_location"] = current_location;
    j["status"] = status;
    j["station_id"] = station_id;
    j["fuel_level"] = fuel_level;
    j["assigned_incident_id"] = assigned_incident_id;
    j["busy_until_time"] = busy_until_time;
    j["is_available"] = is_available();
    return j;
}

Ambulance Ambulance::from_json(const nlohmann::json& j) {
    Ambulance amb;
    if (j.contains("id")) amb.id = j["id"].get<std::string>();
    if (j.contains("call_sign")) amb.call_sign = j["call_sign"].get<std::string>();
    if (j.contains("current_location")) amb.current_location = j["current_location"].get<std::string>();
    if (j.contains("status")) amb.status = j["status"].get<std::string>();
    if (j.contains("station_id")) amb.station_id = j["station_id"].get<std::string>();
    if (j.contains("fuel_level")) amb.fuel_level = j["fuel_level"].get<double>();
    if (j.contains("assigned_incident_id")) amb.assigned_incident_id = j["assigned_incident_id"].get<std::string>();
    if (j.contains("busy_until_time")) amb.busy_until_time = j["busy_until_time"].get<double>();
    return amb;
}
