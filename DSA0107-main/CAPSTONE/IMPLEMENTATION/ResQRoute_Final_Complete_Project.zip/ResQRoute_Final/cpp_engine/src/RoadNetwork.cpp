#include "RoadNetwork.h"
#include <algorithm>
#include <cmath>

Road::Road()
    : road_id(""), source(""), destination(""), distance_km(0.0), speed_limit_kmh(50.0),
      base_travel_time_min(0.0), is_closed(false), closure_reason(""), is_bidirectional(true) {}

Road::Road(const std::string& road_id,
           const std::string& source,
           const std::string& destination,
           double distance_km,
           double speed_limit_kmh,
           bool is_closed,
           const std::string& closure_reason,
           bool is_bidirectional)
    : road_id(road_id), source(source), destination(destination),
      distance_km(distance_km), speed_limit_kmh(speed_limit_kmh > 0 ? speed_limit_kmh : 50.0),
      is_closed(is_closed), closure_reason(closure_reason), is_bidirectional(is_bidirectional) {
    base_travel_time_min = (distance_km / this->speed_limit_kmh) * 60.0;
}

nlohmann::json Road::to_json() const {
    return {
        {"road_id", road_id},
        {"source", source},
        {"destination", destination},
        {"distance_km", distance_km},
        {"speed_limit_kmh", speed_limit_kmh},
        {"travel_time_min", base_travel_time_min},
        {"is_closed", is_closed},
        {"closure_reason", closure_reason},
        {"is_bidirectional", is_bidirectional}
    };
}

Road Road::from_json(const nlohmann::json& j) {
    bool closed = false;
    if (j.contains("is_closed")) {
        if (j["is_closed"].is_boolean()) {
            closed = j["is_closed"].get<bool>();
        } else if (j["is_closed"].is_number()) {
            closed = (j["is_closed"].get<int>() != 0);
        }
    }

    bool bi = true;
    if (j.contains("is_bidirectional")) {
        if (j["is_bidirectional"].is_boolean()) {
            bi = j["is_bidirectional"].get<bool>();
        } else if (j["is_bidirectional"].is_number()) {
            bi = (j["is_bidirectional"].get<int>() != 0);
        }
    }

    return Road(
        j.value("road_id", ""),
        j.value("source", ""),
        j.value("destination", ""),
        j.value("distance_km", 1.0),
        j.value("speed_limit_kmh", 50.0),
        closed,
        j.value("closure_reason", ""),
        bi
    );
}

RoadNetwork::RoadNetwork() {}

void RoadNetwork::add_location(const Location& loc) {
    locations[loc.id] = loc;
    if (adjacency_list.find(loc.id) == adjacency_list.end()) {
        adjacency_list[loc.id] = std::vector<Road>();
    }
}

void RoadNetwork::add_road(const Road& road) {
    roads[road.get_road_id()] = road;
    adjacency_list[road.get_source()].push_back(road);
    if (road.get_is_bidirectional()) {
        Road reverse_road(road.get_road_id() + "_REV",
                          road.get_destination(),
                          road.get_source(),
                          road.get_distance_km(),
                          road.get_speed_limit_kmh(),
                          road.get_is_closed(),
                          road.get_closure_reason(),
                          true);
        adjacency_list[road.get_destination()].push_back(reverse_road);
    }
}

bool RoadNetwork::has_location(const std::string& loc_id) const {
    return locations.find(loc_id) != locations.end();
}

Location RoadNetwork::get_location(const std::string& loc_id) const {
    auto it = locations.find(loc_id);
    if (it != locations.end()) return it->second;
    return Location{loc_id, "Unknown", "Residential", 1.0, 0.0, 0.0};
}

bool RoadNetwork::has_road(const std::string& road_id) const {
    return roads.find(road_id) != roads.end();
}

Road RoadNetwork::get_road(const std::string& road_id) const {
    auto it = roads.find(road_id);
    if (it != roads.end()) return it->second;
    return Road();
}

bool RoadNetwork::close_road(const std::string& road_id, const std::string& reason) {
    auto it = roads.find(road_id);
    if (it != roads.end()) {
        it->second.set_closed(true, reason);
        // Update in adjacency lists
        for (auto& pair : adjacency_list) {
            for (auto& r : pair.second) {
                if (r.get_road_id() == road_id || r.get_road_id() == road_id + "_REV") {
                    r.set_closed(true, reason);
                }
            }
        }
        return true;
    }
    return false;
}

bool RoadNetwork::reopen_road(const std::string& road_id) {
    auto it = roads.find(road_id);
    if (it != roads.end()) {
        it->second.set_closed(false, "");
        for (auto& pair : adjacency_list) {
            for (auto& r : pair.second) {
                if (r.get_road_id() == road_id || r.get_road_id() == road_id + "_REV") {
                    r.set_closed(false, "");
                }
            }
        }
        return true;
    }
    return false;
}

void RoadNetwork::reset_all_closures() {
    for (auto& pair : roads) {
        pair.second.set_closed(false, "");
    }
    for (auto& pair : adjacency_list) {
        for (auto& r : pair.second) {
            r.set_closed(false, "");
        }
    }
}

std::vector<Road> RoadNetwork::get_active_roads() const {
    std::vector<Road> active;
    for (const auto& pair : roads) {
        if (!pair.second.get_is_closed()) {
            active.push_back(pair.second);
        }
    }
    return active;
}

std::vector<Road> RoadNetwork::get_closed_roads() const {
    std::vector<Road> closed;
    for (const auto& pair : roads) {
        if (pair.second.get_is_closed()) {
            closed.push_back(pair.second);
        }
    }
    return closed;
}

std::vector<Road> RoadNetwork::get_outgoing_roads(const std::string& loc_id, bool include_closed) const {
    std::vector<Road> result;
    auto it = adjacency_list.find(loc_id);
    if (it != adjacency_list.end()) {
        for (const auto& r : it->second) {
            if (include_closed || !r.get_is_closed()) {
                result.push_back(r);
            }
        }
    }
    return result;
}

nlohmann::json RoadNetwork::to_json() const {
    nlohmann::json j;
    j["locations"] = nlohmann::json::array();
    for (const auto& pair : locations) {
        j["locations"].push_back(pair.second.to_json());
    }
    j["roads"] = nlohmann::json::array();
    for (const auto& pair : roads) {
        j["roads"].push_back(pair.second.to_json());
    }
    return j;
}

RoadNetwork RoadNetwork::from_json(const nlohmann::json& j) {
    RoadNetwork net;
    if (j.contains("locations") && j["locations"].is_array()) {
        for (const auto& item : j["locations"]) {
            net.add_location(Location::from_json(item));
        }
    }
    if (j.contains("roads") && j["roads"].is_array()) {
        for (const auto& item : j["roads"]) {
            net.add_road(Road::from_json(item));
        }
    }
    return net;
}

void RoadNetwork::populate_default_urban_network() {
    std::vector<Location> default_locs = {
        {"LOC-01", "Central General Hospital", "Hospital", 5.0, 12.9716, 77.5946},
        {"LOC-02", "Northside Emergency Station", "Station", 4.0, 12.9900, 77.5900},
        {"LOC-03", "Metro Core Commercial Hub", "Commercial", 4.5, 12.9750, 77.6050},
        {"LOC-04", "Eastside Residential Heights", "Residential", 3.0, 12.9650, 77.6300},
        {"LOC-05", "South Apex Medical Center", "Hospital", 5.0, 12.9250, 77.5850},
        {"LOC-06", "West Valley Industrial Park", "Industrial", 3.5, 12.9550, 77.5450},
        {"LOC-07", "Suburban Junction North", "Highway_Junction", 2.5, 13.0100, 77.6100},
        {"LOC-08", "Tech Corridor South", "Commercial", 4.0, 12.9150, 77.6400},
        {"LOC-09", "Harbor Gate Waterfront", "Industrial", 2.0, 12.9400, 77.6600},
        {"LOC-10", "Grand Terminal Transit Hub", "Commercial", 4.5, 12.9780, 77.5720},
        {"LOC-11", "Hillside Residential Sector", "Residential", 2.5, 12.9950, 77.5500},
        {"LOC-12", "Greenfield Health Center", "Hospital", 4.0, 12.9350, 77.6150},
        {"LOC-13", "Old Town Heritage District", "Residential", 3.0, 12.9600, 77.5750},
        {"LOC-14", "Southwest Fleet Station", "Station", 3.5, 12.9200, 77.5550},
        {"LOC-15", "East Expressway Tollway", "Highway_Junction", 3.0, 12.9850, 77.6550},
        {"LOC-16", "Isolated River Peninsula", "Residential", 1.5, 12.9100, 77.6900}
    };

    for (const auto& loc : default_locs) {
        add_location(loc);
    }

    std::vector<Road> default_roads = {
        {"RD-01", "LOC-01", "LOC-03", 2.2, 45.0},
        {"RD-02", "LOC-01", "LOC-10", 2.5, 40.0},
        {"RD-03", "LOC-01", "LOC-13", 2.0, 35.0},
        {"RD-04", "LOC-02", "LOC-07", 3.1, 55.0},
        {"RD-05", "LOC-02", "LOC-10", 3.4, 45.0},
        {"RD-06", "LOC-02", "LOC-01", 3.8, 50.0},
        {"RD-07", "LOC-03", "LOC-04", 4.0, 50.0},
        {"RD-08", "LOC-03", "LOC-12", 4.5, 45.0},
        {"RD-09", "LOC-03", "LOC-15", 5.2, 60.0},
        {"RD-10", "LOC-04", "LOC-08", 4.8, 55.0},
        {"RD-11", "LOC-04", "LOC-15", 3.3, 50.0},
        {"RD-12", "LOC-05", "LOC-08", 5.0, 50.0},
        {"RD-13", "LOC-05", "LOC-12", 2.8, 40.0},
        {"RD-14", "LOC-05", "LOC-14", 3.5, 45.0},
        {"RD-15", "LOC-06", "LOC-10", 4.2, 45.0},
        {"RD-16", "LOC-06", "LOC-11", 4.0, 40.0},
        {"RD-17", "LOC-06", "LOC-13", 3.2, 40.0},
        {"RD-18", "LOC-06", "LOC-14", 4.5, 50.0},
        {"RD-19", "LOC-07", "LOC-11", 5.5, 60.0},
        {"RD-20", "LOC-07", "LOC-15", 5.0, 65.0},
        {"RD-21", "LOC-08", "LOC-09", 4.1, 45.0},
        {"RD-22", "LOC-08", "LOC-12", 3.0, 45.0},
        {"RD-23", "LOC-09", "LOC-15", 4.8, 50.0},
        {"RD-24", "LOC-09", "LOC-16", 5.5, 40.0},
        {"RD-25", "LOC-10", "LOC-11", 3.5, 40.0},
        {"RD-26", "LOC-10", "LOC-13", 1.8, 30.0},
        {"RD-27", "LOC-12", "LOC-13", 3.9, 40.0},
        {"RD-28", "LOC-13", "LOC-14", 4.0, 45.0}
    };

    for (const auto& r : default_roads) {
        add_road(r);
    }
}
