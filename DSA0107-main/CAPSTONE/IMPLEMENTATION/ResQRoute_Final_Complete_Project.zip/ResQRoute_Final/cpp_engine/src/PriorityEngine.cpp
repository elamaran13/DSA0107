#include "PriorityEngine.h"
#include <algorithm>

PriorityEngine::PriorityEngine(double sev_w, double wait_w)
    : default_severity_weight(sev_w), default_waiting_time_weight(wait_w) {}

void PriorityEngine::set_weights(double sev_w, double wait_w) {
    if (sev_w >= 0.0) default_severity_weight = sev_w;
    if (wait_w >= 0.0) default_waiting_time_weight = wait_w;
}

double PriorityEngine::evaluate_incident(Incident& incident, double current_sim_time) const {
    if (current_sim_time >= 0.0) {
        incident.update_waiting_time(current_sim_time);
    }
    return incident.calculate_priority(default_severity_weight, default_waiting_time_weight);
}

void PriorityEngine::rank_queue(std::vector<Incident>& incidents, double current_sim_time) const {
    for (auto& inc : incidents) {
        evaluate_incident(inc, current_sim_time);
    }
    // Sort descending by priority score; tie-break by arrival time ascending (FIFO for identical scores)
    std::sort(incidents.begin(), incidents.end(), [](const Incident& a, const Incident& b) {
        if (std::abs(a.get_priority_score() - b.get_priority_score()) > 1e-5) {
            return a.get_priority_score() > b.get_priority_score();
        }
        return a.get_arrival_time() < b.get_arrival_time();
    });
}

bool PriorityEngine::validate_status_transition(const Incident& incident, const std::string& target_status, std::string& err_msg) const {
    if (incident.can_transition_to(target_status)) {
        err_msg = "";
        return true;
    }
    err_msg = "Invalid status transition from '" + incident.get_status() + "' to '" + target_status + "'.";
    return false;
}

bool PriorityEngine::execute_status_transition(Incident& incident, const std::string& target_status, std::string& err_msg) const {
    if (validate_status_transition(incident, target_status, err_msg)) {
        return incident.transition_to(target_status);
    }
    return false;
}

nlohmann::json PriorityEngine::process_incidents_json(const nlohmann::json& input_json) const {
    nlohmann::json result;
    double current_time = input_json.value("current_sim_time", 0.0);
    double sw = input_json.value("severity_weight", default_severity_weight);
    double ww = input_json.value("waiting_time_weight", default_waiting_time_weight);

    PriorityEngine local_engine(sw, ww);

    std::vector<Incident> pending_list;
    std::vector<Incident> all_list;

    if (input_json.contains("incidents") && input_json["incidents"].is_array()) {
        for (const auto& item : input_json["incidents"]) {
            Incident inc = Incident::from_json(item);
            local_engine.evaluate_incident(inc, current_time);
            all_list.push_back(inc);
            if (inc.get_status() == "Pending") {
                pending_list.push_back(inc);
            }
        }
    }

    local_engine.rank_queue(pending_list, current_time);

    result["success"] = true;
    result["current_sim_time"] = current_time;
    result["configured_severity_weight"] = sw;
    result["configured_waiting_time_weight"] = ww;
    result["total_incidents"] = all_list.size();
    result["pending_count"] = pending_list.size();

    result["ranked_pending_queue"] = nlohmann::json::array();
    for (const auto& inc : pending_list) {
        result["ranked_pending_queue"].push_back(inc.to_json());
    }

    result["all_incidents"] = nlohmann::json::array();
    for (const auto& inc : all_list) {
        result["all_incidents"].push_back(inc.to_json());
    }

    return result;
}
