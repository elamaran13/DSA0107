#include <iostream>
#include <fstream>
#include <string>
#include "json.hpp"
#include "Incident.h"
#include "Ambulance.h"
#include "RoadNetwork.h"
#include "PriorityEngine.h"
#include "RouteOptimizer.h"
#include "CoverageAnalyzer.h"
#include "LookAheadOptimizer.h"
#include "PerformanceEvaluator.h"

void print_usage() {
    std::cout << "ResQRoute C++ Engine\n"
              << "Usage: resqroute_engine --mode <mode> [options]\n"
              << "Modes:\n"
              << "  --mode prioritize       Rank pending incidents by dynamic priority\n"
              << "  --mode route            Compute Dijkstra shortest path with road closures\n"
              << "  --mode coverage         Analyze ambulance network coverage\n"
              << "  --mode dispatch         Run Counterfactual Look-Ahead Dispatch Optimizer\n"
              << "  --mode evaluate         Run multi-scenario 3-strategy evaluation\n"
              << "  --mode list_scenarios   Output predefined scenario metadata\n"
              << "  --mode ping             Verify engine communication\n";
}

int main(int argc, char* argv[]) {
    std::string mode = "ping";
    std::string input_file = "";

    for (int i = 1; i < argc; ++i) {
        std::string arg = argv[i];
        if (arg == "--mode" && i + 1 < argc) {
            mode = argv[++i];
        } else if (arg == "--input" && i + 1 < argc) {
            input_file = argv[++i];
        } else if (arg == "--help" || arg == "-h") {
            print_usage();
            return 0;
        }
    }

    if (mode == "ping") {
        nlohmann::json pong;
        pong["status"] = "ok";
        pong["engine"] = "ResQRoute C++17 Core Engine";
        pong["version"] = "1.0.0";
        pong["contribution"] = "Counterfactual Look-Ahead Ambulance Dispatch Optimization";
        std::cout << pong.dump(2) << std::endl;
        return 0;
    }

    // Read input JSON from file or stdin
    nlohmann::json input_json;
    if (!input_file.empty()) {
        std::ifstream ifs(input_file);
        if (ifs.is_open()) {
            ifs >> input_json;
        } else {
            std::cerr << "{\"error\": \"Could not open input file: " << input_file << "\"}" << std::endl;
            return 1;
        }
    } else {
        // Read from standard input if available
        try {
            std::cin >> input_json;
        } catch (...) {
            input_json = nlohmann::json::object();
        }
    }

    try {
        if (mode == "prioritize") {
            PriorityEngine pe;
            nlohmann::json res = pe.process_incidents_json(input_json);
            std::cout << res.dump(2) << std::endl;
            return 0;
        }
        else if (mode == "route") {
            RoadNetwork net;
            if (input_json.contains("road_network")) {
                net = RoadNetwork::from_json(input_json["road_network"]);
            } else {
                net.populate_default_urban_network();
            }
            RouteOptimizer router;
            nlohmann::json res = router.process_route_json(net, input_json);
            std::cout << res.dump(2) << std::endl;
            return 0;
        }
        else if (mode == "coverage") {
            RoadNetwork net;
            if (input_json.contains("road_network")) {
                net = RoadNetwork::from_json(input_json["road_network"]);
            } else {
                net.populate_default_urban_network();
            }
            std::vector<Ambulance> ambs;
            if (input_json.contains("ambulances")) {
                for (const auto& a : input_json["ambulances"]) {
                    ambs.push_back(Ambulance::from_json(a));
                }
            }
            CoverageAnalyzer ca;
            if (input_json.contains("candidate_id")) {
                std::string cid = input_json["candidate_id"].get<std::string>();
                nlohmann::json res = ca.evaluate_dispatch_coverage_impact(net, ambs, cid);
                std::cout << res.dump(2) << std::endl;
            } else {
                nlohmann::json res = ca.process_coverage_json(net, ambs, input_json);
                std::cout << res.dump(2) << std::endl;
            }
            return 0;
        }
        else if (mode == "dispatch") {
            LookAheadOptimizer optimizer;
            nlohmann::json res = optimizer.process_dispatch_json(input_json);
            std::cout << res.dump(2) << std::endl;
            return 0;
        }
        else if (mode == "evaluate") {
            PerformanceEvaluator eval;
            nlohmann::json res = eval.process_evaluation_json(input_json);
            std::cout << res.dump(2) << std::endl;
            return 0;
        }
        else if (mode == "list_scenarios") {
            PerformanceEvaluator eval;
            nlohmann::json res = eval.get_scenarios_metadata();
            std::cout << res.dump(2) << std::endl;
            return 0;
        }
        else {
            std::cerr << "{\"error\": \"Unrecognized mode: " << mode << "\"}" << std::endl;
            return 1;
        }
    } catch (const std::exception& e) {
        nlohmann::json err;
        err["success"] = false;
        err["error"] = e.what();
        std::cout << err.dump(2) << std::endl;
        return 1;
    }

    return 0;
}
