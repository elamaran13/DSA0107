#include "RouteOptimizer.h"
#include <queue>
#include <limits>
#include <map>
#include <algorithm>

RouteOptimizer::RouteOptimizer() {}

RouteResult RouteOptimizer::find_shortest_path(const RoadNetwork& network,
                                               const std::string& source,
                                               const std::string& destination,
                                               bool ignore_closures) const {
    RouteResult result;
    result.source = source;
    result.destination = destination;
    result.is_reachable = false;
    result.total_distance_km = 0.0;
    result.total_travel_time_min = 0.0;
    result.edges_traversed = 0;

    if (!network.has_location(source)) {
        result.status_message = "Source location '" + source + "' not found in road network.";
        return result;
    }
    if (!network.has_location(destination)) {
        result.status_message = "Destination location '" + destination + "' not found in road network.";
        return result;
    }

    if (source == destination) {
        result.is_reachable = true;
        result.path_nodes.push_back(source);
        result.status_message = "Origin and destination are identical.";
        return result;
    }

    // Dijkstra's algorithm using travel time as priority metric
    // Priority queue holds pairs of (current_time, node_id)
    typedef std::pair<double, std::string> DistPair;
    std::priority_queue<DistPair, std::vector<DistPair>, std::greater<DistPair>> pq;

    std::map<std::string, double> min_time;
    std::map<std::string, double> dist_at_min_time;
    std::map<std::string, std::pair<std::string, std::string>> predecessor; // node -> (prev_node, road_id)

    for (const auto& pair : network.get_all_locations()) {
        min_time[pair.first] = std::numeric_limits<double>::infinity();
        dist_at_min_time[pair.first] = std::numeric_limits<double>::infinity();
    }

    min_time[source] = 0.0;
    dist_at_min_time[source] = 0.0;
    pq.push({0.0, source});

    while (!pq.empty()) {
        auto [current_time, u] = pq.top();
        pq.pop();

        if (current_time > min_time[u]) continue;
        if (u == destination) break; // Destination reached with optimal time

        std::vector<Road> outgoing = network.get_outgoing_roads(u, ignore_closures);
        for (const auto& road : outgoing) {
            std::string v = road.get_destination();
            double edge_time = road.get_travel_time_min();
            double edge_dist = road.get_distance_km();

            if (min_time[u] + edge_time < min_time[v]) {
                min_time[v] = min_time[u] + edge_time;
                dist_at_min_time[v] = dist_at_min_time[u] + edge_dist;
                predecessor[v] = {u, road.get_road_id()};
                pq.push({min_time[v], v});
            }
        }
    }

    if (min_time[destination] == std::numeric_limits<double>::infinity()) {
        result.is_reachable = false;
        result.status_message = "Destination is unreachable due to network disconnection or road closures.";
        return result;
    }

    // Reconstruct path
    result.is_reachable = true;
    result.total_travel_time_min = min_time[destination];
    result.total_distance_km = dist_at_min_time[destination];
    result.status_message = "Optimal path found successfully via Dijkstra.";

    std::vector<std::string> rev_nodes;
    std::vector<std::string> rev_roads;
    std::string curr = destination;

    rev_nodes.push_back(curr);
    while (curr != source) {
        auto it = predecessor.find(curr);
        if (it == predecessor.end()) break;
        rev_roads.push_back(it->second.second);
        curr = it->second.first;
        rev_nodes.push_back(curr);
    }

    std::reverse(rev_nodes.begin(), rev_nodes.end());
    std::reverse(rev_roads.begin(), rev_roads.end());

    result.path_nodes = rev_nodes;
    result.path_roads = rev_roads;
    result.edges_traversed = static_cast<int>(rev_roads.size());

    return result;
}

nlohmann::json RouteOptimizer::compare_routes_under_closure(const RoadNetwork& network,
                                                            const std::string& source,
                                                            const std::string& destination,
                                                            const std::string& closed_road_id) const {
    nlohmann::json report;
    RouteResult base_route = find_shortest_path(network, source, destination, true); // without closures

    // Create a modified copy of network with road closed
    RoadNetwork disrupted_net = network;
    if (!closed_road_id.empty()) {
        disrupted_net.close_road(closed_road_id, "Simulation evaluation closure");
    }
    RouteResult alternative_route = find_shortest_path(disrupted_net, source, destination, false);

    report["source"] = source;
    report["destination"] = destination;
    report["target_closed_road"] = closed_road_id;
    report["baseline_route"] = base_route.to_json();
    report["alternative_route"] = alternative_route.to_json();

    if (base_route.is_reachable && alternative_route.is_reachable) {
        double delay = alternative_route.total_travel_time_min - base_route.total_travel_time_min;
        double extra_km = alternative_route.total_distance_km - base_route.total_distance_km;
        report["detour_required"] = (delay > 0.05);
        report["travel_time_delay_min"] = std::max(0.0, delay);
        report["additional_distance_km"] = std::max(0.0, extra_km);
        report["comparison_summary"] = "Alternative route takes " + std::to_string(alternative_route.total_travel_time_min) +
                                      " min vs baseline " + std::to_string(base_route.total_travel_time_min) + " min.";
    } else if (base_route.is_reachable && !alternative_route.is_reachable) {
        report["detour_required"] = true;
        report["destination_isolated"] = true;
        report["comparison_summary"] = "Road closure completely isolates destination. No alternative route exists.";
    } else {
        report["comparison_summary"] = "Route unavailable in both states.";
    }

    return report;
}

nlohmann::json RouteOptimizer::process_route_json(const RoadNetwork& network, const nlohmann::json& input_json) const {
    nlohmann::json output;
    std::string src = input_json.value("source", "");
    std::string dst = input_json.value("destination", "");
    bool ignore_closures = input_json.value("ignore_closures", false);

    RouteResult res = find_shortest_path(network, src, dst, ignore_closures);
    output["success"] = res.is_reachable;
    output["route"] = res.to_json();
    return output;
}
