#include "DispatchStrategy.h"
#include <limits>
#include <sstream>
#include <iomanip>

DispatchDecision NearestAmbulanceStrategy::dispatch(const Incident& incident,
                                                    const std::vector<Ambulance>& ambulances,
                                                    const RoadNetwork& network,
                                                    const std::vector<Incident>& pending_queue,
                                                    double current_sim_time) {
    auto start_time = std::chrono::high_resolution_clock::now();
    DispatchDecision decision;
    decision.set_decision_id("DEC-NEAR-" + incident.get_id());
    decision.set_incident_id(incident.get_id());
    decision.set_strategy_name(get_strategy_name());
    decision.set_simulation_time(current_sim_time);

    CoverageReport pre_cov = coverage_analyzer.compute_coverage(network, ambulances);
    decision.set_pre_coverage_pct(pre_cov.weighted_coverage_pct);

    double best_travel_time = std::numeric_limits<double>::infinity();
    std::string best_amb_id = "";
    CandidateEvaluation best_eval;
    bool found = false;

    std::vector<CandidateEvaluation> all_candidates;

    for (const auto& amb : ambulances) {
        if (!amb.is_available()) continue;

        CandidateEvaluation eval;
        eval.ambulance_id = amb.get_id();
        eval.call_sign = amb.get_call_sign();
        eval.current_location = amb.get_current_location();

        RouteResult route = router.find_shortest_path(network, amb.get_current_location(), incident.get_location(), false);
        eval.is_reachable = route.is_reachable;

        if (route.is_reachable) {
            eval.travel_time_min = route.total_travel_time_min;
            eval.travel_distance_km = route.total_distance_km;
            eval.path_nodes = route.path_nodes;
            eval.immediate_response_cost = route.total_travel_time_min;
            eval.future_delay_cost = 0.0;
            eval.critical_delay_penalty = 0.0;
            eval.coverage_loss_penalty = 0.0;
            eval.road_disruption_penalty = 0.0;
            eval.total_cost = route.total_travel_time_min;

            auto cov_impact = coverage_analyzer.evaluate_dispatch_coverage_impact(network, ambulances, amb.get_id());
            eval.remaining_coverage_pct = cov_impact["post_dispatch_coverage"]["weighted_coverage_pct"].get<double>();
            eval.coverage_loss_pct = cov_impact["coverage_loss_pct"].get<double>();

            std::ostringstream oss;
            oss << "Travel time: " << std::fixed << std::setprecision(1) << eval.travel_time_min << " min";
            eval.rank_explanation = oss.str();

            all_candidates.push_back(eval);

            if (route.total_travel_time_min < best_travel_time) {
                best_travel_time = route.total_travel_time_min;
                best_amb_id = amb.get_id();
                best_eval = eval;
                found = true;
            }
        } else {
            eval.travel_time_min = -1.0;
            eval.travel_distance_km = -1.0;
            eval.total_cost = 99999.0;
            eval.rank_explanation = "Unreachable due to road disruption";
            all_candidates.push_back(eval);
        }
    }

    auto end_time = std::chrono::high_resolution_clock::now();
    double exec_ms = std::chrono::duration<double, std::milli>(end_time - start_time).count();
    decision.set_computation_time_ms(exec_ms);
    decision.set_candidate_evaluations(all_candidates);

    if (found) {
        decision.set_is_feasible(true);
        decision.set_selected_ambulance_id(best_amb_id);
        decision.set_estimated_travel_time(best_eval.travel_time_min);
        decision.set_estimated_distance_km(best_eval.travel_distance_km);
        decision.set_total_cost(best_eval.total_cost);
        decision.set_post_coverage_pct(best_eval.remaining_coverage_pct);
        decision.set_coverage_loss_pct(best_eval.coverage_loss_pct);

        std::ostringstream oss;
        oss << "Dispatched nearest available ambulance " << best_amb_id << " (" << best_eval.call_sign 
            << ") with travel time " << std::fixed << std::setprecision(1) << best_eval.travel_time_min 
            << " min. Future impact was not evaluated.";
        decision.set_selection_reason(oss.str());
    } else {
        decision.set_is_feasible(false);
        decision.set_selected_ambulance_id("");
        decision.set_selection_reason("No available ambulance can reach incident location '" + incident.get_location() + "'.");
    }

    return decision;
}

ImmediateScoringStrategy::ImmediateScoringStrategy(double imm_w, double cov_w)
    : immediate_weight(imm_w), coverage_weight(cov_w) {}

DispatchDecision ImmediateScoringStrategy::dispatch(const Incident& incident,
                                                    const std::vector<Ambulance>& ambulances,
                                                    const RoadNetwork& network,
                                                    const std::vector<Incident>& pending_queue,
                                                    double current_sim_time) {
    auto start_time = std::chrono::high_resolution_clock::now();
    DispatchDecision decision;
    decision.set_decision_id("DEC-IMMED-" + incident.get_id());
    decision.set_incident_id(incident.get_id());
    decision.set_strategy_name(get_strategy_name());
    decision.set_simulation_time(current_sim_time);

    CoverageReport pre_cov = coverage_analyzer.compute_coverage(network, ambulances);
    decision.set_pre_coverage_pct(pre_cov.weighted_coverage_pct);

    double best_score = std::numeric_limits<double>::infinity();
    std::string best_amb_id = "";
    CandidateEvaluation best_eval;
    bool found = false;

    std::vector<CandidateEvaluation> all_candidates;

    for (const auto& amb : ambulances) {
        if (!amb.is_available()) continue;

        CandidateEvaluation eval;
        eval.ambulance_id = amb.get_id();
        eval.call_sign = amb.get_call_sign();
        eval.current_location = amb.get_current_location();

        RouteResult route = router.find_shortest_path(network, amb.get_current_location(), incident.get_location(), false);
        eval.is_reachable = route.is_reachable;

        if (route.is_reachable) {
            eval.travel_time_min = route.total_travel_time_min;
            eval.travel_distance_km = route.total_distance_km;
            eval.path_nodes = route.path_nodes;

            double sev_factor = incident.get_severity_factor();
            eval.immediate_response_cost = route.total_travel_time_min * (sev_factor * 0.5);

            auto cov_impact = coverage_analyzer.evaluate_dispatch_coverage_impact(network, ambulances, amb.get_id());
            eval.remaining_coverage_pct = cov_impact["post_dispatch_coverage"]["weighted_coverage_pct"].get<double>();
            eval.coverage_loss_pct = cov_impact["coverage_loss_pct"].get<double>();

            eval.coverage_loss_penalty = eval.coverage_loss_pct * coverage_weight;
            eval.future_delay_cost = 0.0;
            eval.critical_delay_penalty = 0.0;
            eval.road_disruption_penalty = 0.0;

            eval.total_cost = (immediate_weight * eval.immediate_response_cost) + eval.coverage_loss_penalty;

            std::ostringstream oss;
            oss << "ImmCost=" << std::fixed << std::setprecision(1) << eval.immediate_response_cost 
                << ", CovLossPen=" << eval.coverage_loss_penalty 
                << " -> Score: " << eval.total_cost;
            eval.rank_explanation = oss.str();

            all_candidates.push_back(eval);

            if (eval.total_cost < best_score) {
                best_score = eval.total_cost;
                best_amb_id = amb.get_id();
                best_eval = eval;
                found = true;
            }
        } else {
            eval.travel_time_min = -1.0;
            eval.travel_distance_km = -1.0;
            eval.total_cost = 99999.0;
            eval.rank_explanation = "Unreachable destination";
            all_candidates.push_back(eval);
        }
    }

    auto end_time = std::chrono::high_resolution_clock::now();
    double exec_ms = std::chrono::duration<double, std::milli>(end_time - start_time).count();
    decision.set_computation_time_ms(exec_ms);
    decision.set_candidate_evaluations(all_candidates);

    if (found) {
        decision.set_is_feasible(true);
        decision.set_selected_ambulance_id(best_amb_id);
        decision.set_estimated_travel_time(best_eval.travel_time_min);
        decision.set_estimated_distance_km(best_eval.travel_distance_km);
        decision.set_total_cost(best_eval.total_cost);
        decision.set_post_coverage_pct(best_eval.remaining_coverage_pct);
        decision.set_coverage_loss_pct(best_eval.coverage_loss_pct);

        std::ostringstream oss;
        oss << "Dispatched " << best_amb_id << " based on immediate scoring (travel time + coverage loss penalty). Score: " 
            << std::fixed << std::setprecision(1) << best_eval.total_cost;
        decision.set_selection_reason(oss.str());
    } else {
        decision.set_is_feasible(false);
        decision.set_selected_ambulance_id("");
        decision.set_selection_reason("No feasible candidate available.");
    }

    return decision;
}
