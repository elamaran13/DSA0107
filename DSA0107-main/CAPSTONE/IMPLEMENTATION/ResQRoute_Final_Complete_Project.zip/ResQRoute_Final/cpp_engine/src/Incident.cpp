#include "Incident.h"
#include <sstream>
#include <iomanip>
#include <algorithm>

Incident::Incident()
    : id(""), location(""), severity("Low"), arrival_time(0.0), waiting_time(0.0),
      description(""), status("Pending"), priority_score(0.0),
      severity_weight(25.0), waiting_time_weight(2.0), assigned_ambulance_id("") {
    calculate_priority();
}

Incident::Incident(const std::string& id,
                   const std::string& location,
                   const std::string& severity,
                   double arrival_time,
                   const std::string& description,
                   const std::string& status,
                   double severity_weight,
                   double waiting_time_weight)
    : id(id), location(location), severity(severity), arrival_time(arrival_time),
      waiting_time(0.0), description(description), status(status),
      severity_weight(severity_weight), waiting_time_weight(waiting_time_weight),
      assigned_ambulance_id("") {
    calculate_priority();
}

double Incident::get_severity_factor() const {
    if (severity == "Critical") return 4.0;
    if (severity == "High") return 3.0;
    if (severity == "Medium") return 2.0;
    if (severity == "Low") return 1.0;
    return 1.0;
}

double Incident::calculate_priority(double sw, double ww) {
    if (sw >= 0.0) severity_weight = sw;
    if (ww >= 0.0) waiting_time_weight = ww;
    double sev_factor = get_severity_factor();
    priority_score = (severity_weight * sev_factor) + (waiting_time_weight * waiting_time);
    return priority_score;
}

void Incident::update_waiting_time(double current_sim_time) {
    if (current_sim_time >= arrival_time && status == "Pending") {
        waiting_time = current_sim_time - arrival_time;
    }
    calculate_priority();
}

bool Incident::can_transition_to(const std::string& new_status) const {
    if (status == new_status) return true;
    if (status == "Pending") {
        return (new_status == "Dispatched" || new_status == "Cancelled");
    }
    if (status == "Dispatched") {
        return (new_status == "In-Transit" || new_status == "Cancelled" || new_status == "Pending");
    }
    if (status == "In-Transit") {
        return (new_status == "Resolved" || new_status == "Cancelled");
    }
    if (status == "Resolved" || status == "Cancelled") {
        return false; // Terminal states
    }
    return false;
}

bool Incident::transition_to(const std::string& new_status) {
    if (can_transition_to(new_status)) {
        status = new_status;
        return true;
    }
    return false;
}

std::string Incident::get_priority_explanation() const {
    std::ostringstream oss;
    oss << std::fixed << std::setprecision(1);
    oss << "Severity (" << severity << " = " << get_severity_factor() << " x " << severity_weight 
        << " = " << (get_severity_factor() * severity_weight) << ") + Waiting Time (" 
        << waiting_time << " min x " << waiting_time_weight 
        << " = " << (waiting_time * waiting_time_weight) << ") -> Priority Score: " 
        << priority_score;
    return oss.str();
}

nlohmann::json Incident::to_json() const {
    nlohmann::json j;
    j["id"] = id;
    j["location"] = location;
    j["severity"] = severity;
    j["arrival_time"] = arrival_time;
    j["waiting_time"] = waiting_time;
    j["description"] = description;
    j["status"] = status;
    j["priority_score"] = priority_score;
    j["severity_weight"] = severity_weight;
    j["waiting_time_weight"] = waiting_time_weight;
    j["assigned_ambulance_id"] = assigned_ambulance_id;
    j["priority_explanation"] = get_priority_explanation();
    return j;
}

Incident Incident::from_json(const nlohmann::json& j) {
    Incident inc;
    if (j.contains("id")) inc.id = j["id"].get<std::string>();
    if (j.contains("location")) inc.location = j["location"].get<std::string>();
    if (j.contains("severity")) inc.severity = j["severity"].get<std::string>();
    if (j.contains("arrival_time")) inc.arrival_time = j["arrival_time"].get<double>();
    if (j.contains("waiting_time")) inc.waiting_time = j["waiting_time"].get<double>();
    if (j.contains("description")) inc.description = j["description"].get<std::string>();
    if (j.contains("status")) inc.status = j["status"].get<std::string>();
    if (j.contains("severity_weight")) inc.severity_weight = j["severity_weight"].get<double>();
    if (j.contains("waiting_time_weight")) inc.waiting_time_weight = j["waiting_time_weight"].get<double>();
    if (j.contains("assigned_ambulance_id")) inc.assigned_ambulance_id = j["assigned_ambulance_id"].get<std::string>();
    inc.calculate_priority();
    return inc;
}
