#include "CoverageAnalyzer.h"
#include <limits>
#include <algorithm>

CoverageAnalyzer::CoverageAnalyzer(double threshold)
    : default_threshold_minutes(threshold) {}

CoverageReport CoverageAnalyzer::compute_coverage(const RoadNetwork& network,
                                                  const std::vector<Ambulance>& ambulances,
                                                  double custom_threshold) const {
    CoverageReport rep;
    double thresh = (custom_threshold > 0.0) ? custom_threshold : default_threshold_minutes;
    rep.threshold_minutes = thresh;

    const auto& all_locs = network.get_all_locations();
    rep.total_locations = static_cast<int>(all_locs.size());

    if (rep.total_locations == 0) {
        rep.covered_locations_count = 0;
        rep.unweighted_coverage_pct = 0.0;
        rep.weighted_coverage_pct = 0.0;
        return rep;
    }

    // Filter available ambulances
    std::vector<Ambulance> available_ambs;
    for (const auto& a : ambulances) {
        if (a.is_available()) {
            available_ambs.push_back(a);
        }
    }

    double total_weight = 0.0;
    double covered_weight = 0.0;

    for (const auto& pair : all_locs) {
        const std::string& loc_id = pair.first;
        const Location& loc = pair.second;
        total_weight += loc.demand_weight;

        double best_time = std::numeric_limits<double>::infinity();

        for (const auto& amb : available_ambs) {
            RouteResult route = router.find_shortest_path(network, amb.get_current_location(), loc_id, false);
            if (route.is_reachable && route.total_travel_time_min < best_time) {
                best_time = route.total_travel_time_min;
            }
        }

        rep.min_arrival_times[loc_id] = (best_time == std::numeric_limits<double>::infinity()) ? -1.0 : best_time;

        if (best_time <= thresh) {
            rep.covered_location_ids.push_back(loc_id);
            covered_weight += loc.demand_weight;
        } else {
            rep.uncovered_location_ids.push_back(loc_id);
        }
    }

    rep.covered_locations_count = static_cast<int>(rep.covered_location_ids.size());
    rep.unweighted_coverage_pct = (static_cast<double>(rep.covered_locations_count) / rep.total_locations) * 100.0;
    rep.weighted_coverage_pct = (total_weight > 0.0) ? (covered_weight / total_weight) * 100.0 : 0.0;

    return rep;
}

nlohmann::json CoverageAnalyzer::evaluate_dispatch_coverage_impact(const RoadNetwork& network,
                                                                   const std::vector<Ambulance>& all_ambulances,
                                                                   const std::string& candidate_ambulance_id,
                                                                   double custom_threshold) const {
    nlohmann::json impact;
    double thresh = (custom_threshold > 0.0) ? custom_threshold : default_threshold_minutes;

    CoverageReport pre_dispatch = compute_coverage(network, all_ambulances, thresh);

    // Create a modified ambulance vector where candidate is marked busy
    std::vector<Ambulance> post_ambs = all_ambulances;
    for (auto& a : post_ambs) {
        if (a.get_id() == candidate_ambulance_id) {
            a.set_status("Busy");
            break;
        }
    }

    CoverageReport post_dispatch = compute_coverage(network, post_ambs, thresh);

    // Determine locations that lost coverage
    std::set<std::string> pre_set(pre_dispatch.covered_location_ids.begin(), pre_dispatch.covered_location_ids.end());
    std::set<std::string> post_set(post_dispatch.covered_location_ids.begin(), post_dispatch.covered_location_ids.end());

    std::vector<std::string> lost_locs;
    for (const auto& id : pre_set) {
        if (post_set.find(id) == post_set.end()) {
            lost_locs.push_back(id);
        }
    }

    double coverage_loss_pct = pre_dispatch.weighted_coverage_pct - post_dispatch.weighted_coverage_pct;
    if (coverage_loss_pct < 0.0) coverage_loss_pct = 0.0; // numerical safety

    impact["candidate_ambulance_id"] = candidate_ambulance_id;
    impact["threshold_minutes"] = thresh;
    impact["pre_dispatch_coverage"] = pre_dispatch.to_json();
    impact["post_dispatch_coverage"] = post_dispatch.to_json();
    impact["coverage_loss_pct"] = coverage_loss_pct;
    impact["lost_locations"] = lost_locs;
    impact["is_critical_coverage_loss"] = (coverage_loss_pct > 15.0);

    return impact;
}

nlohmann::json CoverageAnalyzer::process_coverage_json(const RoadNetwork& network,
                                                       const std::vector<Ambulance>& ambulances,
                                                       const nlohmann::json& input_json) const {
    double thresh = input_json.value("threshold_minutes", default_threshold_minutes);
    CoverageReport rep = compute_coverage(network, ambulances, thresh);
    nlohmann::json out = rep.to_json();
    out["success"] = true;
    return out;
}
