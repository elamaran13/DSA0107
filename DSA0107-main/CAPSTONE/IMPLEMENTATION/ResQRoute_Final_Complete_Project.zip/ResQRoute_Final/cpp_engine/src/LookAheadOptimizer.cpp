#include "LookAheadOptimizer.h"
#include <algorithm>
#include <sstream>
#include <iomanip>
#include <iostream>

LookAheadOptimizer::LookAheadOptimizer(const LookAheadWeights& w,
                                       int scenarios,
                                       double horizon,
                                       unsigned int seed)
    : weights(w),
      scenario_count(scenarios > 0 ? scenarios : 5),
      lookahead_horizon_minutes(horizon > 0.0 ? horizon : 45.0),
      random_seed(seed) {}

std::vector<Incident> LookAheadOptimizer::generate_future_scenarios(const RoadNetwork& network,
                                                                    double current_sim_time) const {
    std::vector<Incident> future_events;
    std::mt19937 rng(random_seed);

    const auto& locs = network.get_all_locations();
    if (locs.empty()) return future_events;

    std::vector<std::string> loc_keys;
    for (const auto& pair : locs) {
        loc_keys.push_back(pair.first);
    }

    std::vector<std::string> severities = {"Critical", "High", "Medium", "Low"};
    std::discrete_distribution<int> sev_dist({20, 35, 30, 15}); // 20% Critical, 35% High, 30% Medium, 15% Low
    std::uniform_int_distribution<int> loc_dist(0, static_cast<int>(loc_keys.size()) - 1);
    std::uniform_real_distribution<double> time_dist(current_sim_time + 2.0, current_sim_time + lookahead_horizon_minutes);

    for (int i = 0; i < scenario_count; ++i) {
        std::string inc_id = "FUT-SIM-" + std::to_string(i + 1);
        std::string loc = loc_keys[loc_dist(rng)];
        std::string sev = severities[sev_dist(rng)];
        double arr_time = time_dist(rng);

        Incident inc(inc_id, loc, sev, arr_time, "Simulated Future Demand Event");
        future_events.push_back(inc);
    }

    // Sort chronologically
    std::sort(future_events.begin(), future_events.end(), [](const Incident& a, const Incident& b) {
        return a.get_arrival_time() < b.get_arrival_time();
    });

    return future_events;
}

DispatchDecision LookAheadOptimizer::dispatch(const Incident& incident,
                                              const std::vector<Ambulance>& ambulances,
                                              const RoadNetwork& network,
                                              const std::vector<Incident>& pending_queue,
                                              double current_sim_time) {
    auto start_time = std::chrono::high_resolution_clock::now();

    DispatchDecision decision;
    decision.set_decision_id("DEC-LOOKAHEAD-" + incident.get_id());
    decision.set_incident_id(incident.get_id());
    decision.set_strategy_name(get_strategy_name());
    decision.set_simulation_time(current_sim_time);

    CoverageReport pre_cov = coverage_analyzer.compute_coverage(network, ambulances);
    decision.set_pre_coverage_pct(pre_cov.weighted_coverage_pct);

    // 1. Identify future incidents for counterfactual evaluation
    // Combine existing pending queue (excluding current incident) with deterministic rollout events
    std::vector<Incident> future_pool;
    for (const auto& q_inc : pending_queue) {
        if (q_inc.get_id() != incident.get_id() && q_inc.get_status() == "Pending") {
            future_pool.push_back(q_inc);
        }
    }

    std::vector<Incident> generated_futures = generate_future_scenarios(network, current_sim_time);
    future_pool.insert(future_pool.end(), generated_futures.begin(), generated_futures.end());

    // 2. Candidate generation & evaluation
    std::vector<CandidateEvaluation> candidates;
    double min_total_cost = std::numeric_limits<double>::infinity();
    std::string winning_amb_id = "";
    CandidateEvaluation winning_eval;
    bool found_feasible = false;

    for (const auto& amb : ambulances) {
        if (!amb.is_available()) continue;

        CandidateEvaluation eval;
        eval.ambulance_id = amb.get_id();
        eval.call_sign = amb.get_call_sign();
        eval.current_location = amb.get_current_location();

        // Dijkstra shortest path considering road closures
        RouteResult route = router.find_shortest_path(network, amb.get_current_location(), incident.get_location(), false);
        eval.is_reachable = route.is_reachable;

        if (!route.is_reachable) {
            eval.travel_time_min = -1.0;
            eval.travel_distance_km = -1.0;
            eval.total_cost = 999999.0;
            eval.rank_explanation = "Unreachable destination due to road disruption";
            candidates.push_back(eval);
            continue;
        }

        eval.travel_time_min = route.total_travel_time_min;
        eval.travel_distance_km = route.total_distance_km;
        eval.path_nodes = route.path_nodes;

        // A. Immediate Response Cost
        double sev_factor = incident.get_severity_factor();
        eval.immediate_response_cost = (eval.travel_time_min * sev_factor) + (incident.get_waiting_time() * 0.5);

        // B. Road Disruption Penalty (detour time compared to ideal baseline)
        RouteResult ideal_route = router.find_shortest_path(network, amb.get_current_location(), incident.get_location(), true);
        double detour_delay = 0.0;
        if (ideal_route.is_reachable && eval.travel_time_min > ideal_route.total_travel_time_min) {
            detour_delay = eval.travel_time_min - ideal_route.total_travel_time_min;
        }
        eval.road_disruption_penalty = detour_delay * weights.road_disruption_weight;

        // C. Remaining Ambulance Coverage & Loss
        auto cov_impact = coverage_analyzer.evaluate_dispatch_coverage_impact(network, ambulances, amb.get_id());
        eval.remaining_coverage_pct = cov_impact["post_dispatch_coverage"]["weighted_coverage_pct"].get<double>();
        eval.coverage_loss_pct = cov_impact["coverage_loss_pct"].get<double>();
        eval.coverage_loss_penalty = eval.coverage_loss_pct * weights.coverage_loss_weight;

        // D. Counterfactual Future Emergency Delay Cost
        // If candidate 'amb' is dispatched, its busy duration is travel_time + service_time (e.g. 15 min at scene/hospital)
        double busy_duration = (eval.travel_time_min * 2.0) + 15.0;
        double candidate_free_time = current_sim_time + busy_duration;

        double total_future_delay = 0.0;
        double total_critical_delay = 0.0;
        int evaluated_futures_count = 0;

        for (const auto& fut_inc : future_pool) {
            if (fut_inc.get_arrival_time() > current_sim_time + lookahead_horizon_minutes) {
                continue;
            }

            evaluated_futures_count++;

            // Scenario 1: Best response time among ALL other available ambulances (excluding candidate 'amb')
            double best_alt_time = std::numeric_limits<double>::infinity();
            for (const auto& other_amb : ambulances) {
                if (other_amb.get_id() == amb.get_id() || !other_amb.is_available()) continue;

                RouteResult alt_route = router.find_shortest_path(network, other_amb.get_current_location(), fut_inc.get_location(), false);
                if (alt_route.is_reachable && alt_route.total_travel_time_min < best_alt_time) {
                    best_alt_time = alt_route.total_travel_time_min;
                }
            }

            // Scenario 2: What if candidate 'amb' had remained available for this future incident?
            RouteResult amb_to_fut = router.find_shortest_path(network, amb.get_current_location(), fut_inc.get_location(), false);
            double amb_potential_time = amb_to_fut.is_reachable ? amb_to_fut.total_travel_time_min : 999.0;

            // Counterfactual delay: if amb was significantly closer than other ambulances to this future incident
            if (best_alt_time == std::numeric_limits<double>::infinity()) {
                // If other ambulances cannot reach at all, candidate absence causes catastrophic delay
                total_future_delay += 30.0;
                if (fut_inc.get_severity() == "Critical") {
                    total_critical_delay += 50.0;
                }
            } else if (best_alt_time > amb_potential_time) {
                double delay_diff = best_alt_time - amb_potential_time;
                total_future_delay += delay_diff;
                if (fut_inc.get_severity() == "Critical") {
                    total_critical_delay += (delay_diff * 2.5);
                }
            }
        }

        double norm_future_delay = (evaluated_futures_count > 0) ? (total_future_delay / evaluated_futures_count) : 0.0;
        double norm_critical_delay = (evaluated_futures_count > 0) ? (total_critical_delay / evaluated_futures_count) : 0.0;

        eval.future_delay_cost = norm_future_delay * weights.future_delay_weight;
        eval.critical_delay_penalty = norm_critical_delay * weights.critical_penalty_weight;

        // E. Objective Function: Total Candidate Cost
        eval.total_cost = (weights.immediate_weight * eval.immediate_response_cost)
                        + eval.future_delay_cost
                        + eval.critical_delay_penalty
                        + eval.coverage_loss_penalty
                        + eval.road_disruption_penalty;

        std::ostringstream oss;
        oss << "ImmCost=" << std::fixed << std::setprecision(1) << eval.immediate_response_cost
            << " (t=" << eval.travel_time_min << "m), FutDelayPen=" << eval.future_delay_cost
            << ", CritPen=" << eval.critical_delay_penalty
            << ", CovLossPen=" << eval.coverage_loss_penalty << " (-" << eval.coverage_loss_pct << "%)"
            << " -> Total: " << eval.total_cost;
        eval.rank_explanation = oss.str();

        candidates.push_back(eval);

        if (eval.total_cost < min_total_cost) {
            min_total_cost = eval.total_cost;
            winning_amb_id = amb.get_id();
            winning_eval = eval;
            found_feasible = true;
        }
    }

    auto end_time = std::chrono::high_resolution_clock::now();
    double exec_ms = std::chrono::duration<double, std::milli>(end_time - start_time).count();

    // Sort candidate evaluations by total cost ascending
    std::sort(candidates.begin(), candidates.end(), [](const CandidateEvaluation& a, const CandidateEvaluation& b) {
        return a.total_cost < b.total_cost;
    });

    decision.set_computation_time_ms(exec_ms);
    decision.set_candidate_evaluations(candidates);

    if (found_feasible) {
        decision.set_is_feasible(true);
        decision.set_selected_ambulance_id(winning_amb_id);
        decision.set_estimated_travel_time(winning_eval.travel_time_min);
        decision.set_estimated_distance_km(winning_eval.travel_distance_km);
        decision.set_total_cost(winning_eval.total_cost);
        decision.set_post_coverage_pct(winning_eval.remaining_coverage_pct);
        decision.set_coverage_loss_pct(winning_eval.coverage_loss_pct);

        std::ostringstream oss;
        oss << "Look-Ahead Optimizer selected " << winning_amb_id << " (" << winning_eval.call_sign 
            << "). Total Cost: " << std::fixed << std::setprecision(2) << winning_eval.total_cost 
            << " [Immediate Travel: " << winning_eval.travel_time_min << " min, Future Delay Cost: " 
            << winning_eval.future_delay_cost << ", Coverage Loss: " << winning_eval.coverage_loss_pct 
            << "%]. Preserves optimal regional readiness.";
        decision.set_selection_reason(oss.str());
    } else {
        decision.set_is_feasible(false);
        decision.set_selected_ambulance_id("");
        decision.set_selection_reason("No feasible candidate ambulance available to reach target location '" + incident.get_location() + "'.");
    }

    return decision;
}

nlohmann::json LookAheadOptimizer::process_dispatch_json(const nlohmann::json& input_json) const {
    nlohmann::json output;

    if (!input_json.contains("incident") || !input_json.contains("ambulances") || !input_json.contains("road_network")) {
        output["success"] = false;
        output["error"] = "Missing required keys: incident, ambulances, or road_network";
        return output;
    }

    Incident incident = Incident::from_json(input_json["incident"]);
    RoadNetwork network = RoadNetwork::from_json(input_json["road_network"]);

    std::vector<Ambulance> ambulances;
    for (const auto& item : input_json["ambulances"]) {
        ambulances.push_back(Ambulance::from_json(item));
    }

    std::vector<Incident> pending_queue;
    if (input_json.contains("pending_queue") && input_json["pending_queue"].is_array()) {
        for (const auto& item : input_json["pending_queue"]) {
            pending_queue.push_back(Incident::from_json(item));
        }
    }

    double sim_time = input_json.value("current_sim_time", 0.0);

    LookAheadWeights w = weights;
    if (input_json.contains("weights")) {
        auto jw = input_json["weights"];
        w.immediate_weight = jw.value("immediate_weight", w.immediate_weight);
        w.future_delay_weight = jw.value("future_delay_weight", w.future_delay_weight);
        w.critical_penalty_weight = jw.value("critical_penalty_weight", w.critical_penalty_weight);
        w.coverage_loss_weight = jw.value("coverage_loss_weight", w.coverage_loss_weight);
        w.road_disruption_weight = jw.value("road_disruption_weight", w.road_disruption_weight);
    }

    int scenarios = input_json.value("scenario_count", scenario_count);
    double horizon = input_json.value("horizon_minutes", lookahead_horizon_minutes);
    unsigned int seed = input_json.value("random_seed", random_seed);

    LookAheadOptimizer optimizer(w, scenarios, horizon, seed);
    DispatchDecision decision = optimizer.dispatch(incident, ambulances, network, pending_queue, sim_time);

    output["success"] = true;
    output["decision"] = decision.to_json();
    return output;
}
