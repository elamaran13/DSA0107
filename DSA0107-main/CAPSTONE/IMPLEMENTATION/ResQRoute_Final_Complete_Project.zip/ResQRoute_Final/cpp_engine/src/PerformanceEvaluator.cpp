#include "PerformanceEvaluator.h"
#include <algorithm>
#include <numeric>
#include <cmath>

nlohmann::json StrategyMetrics::to_json() const {
    nlohmann::json decs = nlohmann::json::array();
    for (const auto& d : decisions) {
        decs.push_back(d.to_json());
    }
    return {
        {"strategy_name", strategy_name},
        {"total_incidents", total_incidents},
        {"incidents_served", incidents_served},
        {"incidents_unserved", incidents_unserved},
        {"completion_rate_pct", completion_rate_pct},
        {"avg_response_time_min", avg_response_time_min},
        {"median_response_time_min", median_response_time_min},
        {"critical_avg_response_time_min", critical_avg_response_time_min},
        {"critical_avg_waiting_time_min", critical_avg_waiting_time_min},
        {"total_travel_distance_km", total_travel_distance_km},
        {"final_remaining_coverage_pct", final_remaining_coverage_pct},
        {"avg_coverage_loss_pct", avg_coverage_loss_pct},
        {"total_computation_time_ms", total_computation_time_ms},
        {"avg_computation_time_ms", avg_computation_time_ms},
        {"decisions", decs}
    };
}

PerformanceEvaluator::PerformanceEvaluator() {
    initialize_predefined_scenarios();
}

void PerformanceEvaluator::initialize_predefined_scenarios() {
    RoadNetwork base_net;
    base_net.populate_default_urban_network();

    std::vector<Ambulance> base_ambs = {
        {"AMB-01", "Medic-Alpha", "LOC-01", "Available", "LOC-01", 100.0},
        {"AMB-02", "Medic-Bravo", "LOC-02", "Available", "LOC-02", 95.0},
        {"AMB-03", "Medic-Charlie", "LOC-05", "Available", "LOC-05", 90.0},
        {"AMB-04", "Medic-Delta", "LOC-06", "Available", "LOC-06", 88.0},
        {"AMB-05", "Medic-Echo", "LOC-10", "Available", "LOC-10", 92.0},
        {"AMB-06", "Medic-Foxtrot", "LOC-12", "Available", "LOC-12", 85.0},
        {"AMB-07", "Medic-Golf", "LOC-14", "Available", "LOC-14", 98.0},
        {"AMB-08", "Medic-Hotel", "LOC-08", "Available", "LOC-08", 91.0}
    };

    // Scenario A: Normal Operation
    {
        ScenarioDefinition sc;
        sc.id = "SCENARIO_A";
        sc.name = "Normal Urban Operation";
        sc.description = "Steady-state distribution of incidents across urban sectors with all fleet units operational.";
        sc.initial_network = base_net;
        sc.initial_ambulances = base_ambs;
        sc.incidents = {
            {"INC-A1", "LOC-03", "Medium", 2.0, "Minor industrial laceration", "Pending"},
            {"INC-A2", "LOC-04", "High", 5.0, "Severe respiratory distress", "Pending"},
            {"INC-A3", "LOC-13", "Low", 8.0, "Elderly fall with wrist sprain", "Pending"},
            {"INC-A4", "LOC-07", "Medium", 12.0, "Motorcycle collision at junction", "Pending"}
        };
        predefined_scenarios.push_back(sc);
    }

    // Scenario B: Simultaneous Emergencies
    {
        ScenarioDefinition sc;
        sc.id = "SCENARIO_B";
        sc.name = "Simultaneous Multi-Incident Surge";
        sc.description = "High surge rate where 5 emergencies arrive within a tight 3-minute window, testing resource contention.";
        sc.initial_network = base_net;
        sc.initial_ambulances = base_ambs;
        sc.incidents = {
            {"INC-B1", "LOC-03", "High", 2.0, "Commercial kitchen burn incident", "Pending"},
            {"INC-B2", "LOC-04", "Critical", 2.5, "Pedestrian hit by vehicle", "Pending"},
            {"INC-B3", "LOC-11", "Medium", 3.0, "Asthma attack in residential flat", "Pending"},
            {"INC-B4", "LOC-08", "High", 3.5, "Cardiac chest pain reported", "Pending"},
            {"INC-B5", "LOC-13", "Low", 4.0, "Diabetic dizziness complaint", "Pending"}
        };
        predefined_scenarios.push_back(sc);
    }

    // Scenario C: Critical Emergency Contention
    {
        ScenarioDefinition sc;
        sc.id = "SCENARIO_C";
        sc.name = "Critical Emergency Contention";
        sc.description = "A life-threatening Critical emergency competes against existing Low and Medium calls for medical priority.";
        sc.initial_network = base_net;
        sc.initial_ambulances = base_ambs;
        sc.incidents = {
            {"INC-C1", "LOC-09", "Low", 1.0, "Minor sports injury at waterfront", "Pending"},
            {"INC-C2", "LOC-07", "Medium", 3.0, "Mild allergic reaction", "Pending"},
            {"INC-C3", "LOC-12", "Critical", 5.0, "Unresponsive patient / Sudden cardiac arrest", "Pending"},
            {"INC-C4", "LOC-15", "High", 6.0, "Highway multi-car collision", "Pending"}
        };
        predefined_scenarios.push_back(sc);
    }

    // Scenario D: Severe Coverage Loss Dilemma
    {
        ScenarioDefinition sc;
        sc.id = "SCENARIO_D";
        sc.name = "Coverage Loss Dilemma";
        sc.description = "Dispatching the nearest ambulance from an isolated sector leaves high-demand zones vulnerable to zero coverage.";
        sc.initial_network = base_net;
        // Strip down fleet so assigning AMB-03 creates a large vacuum
        std::vector<Ambulance> sparse_ambs = {
            {"AMB-01", "Medic-Alpha", "LOC-01", "Available", "LOC-01", 100.0},
            {"AMB-02", "Medic-Bravo", "LOC-02", "Available", "LOC-02", 95.0},
            {"AMB-03", "Medic-Charlie", "LOC-05", "Available", "LOC-05", 90.0}, // Sole southern guardian
            {"AMB-04", "Medic-Delta", "LOC-06", "Busy", "LOC-06", 88.0},
            {"AMB-05", "Medic-Echo", "LOC-10", "Busy", "LOC-10", 92.0}
        };
        sc.initial_ambulances = sparse_ambs;
        sc.incidents = {
            {"INC-D1", "LOC-13", "Medium", 2.0, "Fainting spell in Old Town", "Pending"},
            {"INC-D2", "LOC-14", "High", 6.0, "Warehouse structural collapse", "Pending"}
        };
        predefined_scenarios.push_back(sc);
    }

    // Scenario E: Major Arterial Road Closure
    {
        ScenarioDefinition sc;
        sc.id = "SCENARIO_E";
        sc.name = "Major Arterial Road Disruption";
        sc.description = "Arterial road RD-01 (LOC-01 to LOC-03) and RD-07 (LOC-03 to LOC-04) are closed due to sinkhole and water main rupture.";
        RoadNetwork net_e = base_net;
        net_e.close_road("RD-01", "Sinkhole collapse");
        net_e.close_road("RD-07", "Water main explosion");
        sc.initial_network = net_e;
        sc.initial_ambulances = base_ambs;
        sc.closed_roads = {"RD-01", "RD-07"};
        sc.incidents = {
            {"INC-E1", "LOC-04", "Critical", 2.0, "Structure fire with trapped victims", "Pending"},
            {"INC-E2", "LOC-03", "High", 4.0, "Electrocution at commercial hub", "Pending"}
        };
        predefined_scenarios.push_back(sc);
    }

    // Scenario F: Completely Unreachable Destination
    {
        ScenarioDefinition sc;
        sc.id = "SCENARIO_F";
        sc.name = "Isolated Unreachable Destination";
        sc.description = "Peninsula access road RD-24 is severed by bridge collapse. Tests engine's ability to identify infeasible dispatches cleanly.";
        RoadNetwork net_f = base_net;
        net_f.close_road("RD-24", "Bridge structural failure");
        sc.initial_network = net_f;
        sc.initial_ambulances = base_ambs;
        sc.closed_roads = {"RD-24"};
        sc.incidents = {
            {"INC-F1", "LOC-16", "Critical", 3.0, "Drowning victim at isolated peninsula", "Pending"},
            {"INC-F2", "LOC-02", "Medium", 5.0, "Laceration at transit station", "Pending"}
        };
        predefined_scenarios.push_back(sc);
    }

    // Scenario G: Total Fleet Depletion (All Busy)
    {
        ScenarioDefinition sc;
        sc.id = "SCENARIO_G";
        sc.name = "All Ambulances Busy Fleet Depletion";
        sc.description = "All municipal ambulances are deployed on active calls. Verifies queue retention without crashing or invalid assignments.";
        sc.initial_network = base_net;
        std::vector<Ambulance> busy_ambs = base_ambs;
        for (auto& amb : busy_ambs) {
            amb.set_status("Busy");
        }
        sc.initial_ambulances = busy_ambs;
        sc.incidents = {
            {"INC-G1", "LOC-01", "Critical", 1.0, "Cardiac arrest at transit shelter", "Pending"},
            {"INC-G2", "LOC-08", "High", 2.0, "Factory chemical exposure", "Pending"}
        };
        predefined_scenarios.push_back(sc);
    }

    // Scenario H: Future Consequence Counterfactual Test
    {
        ScenarioDefinition sc;
        sc.id = "SCENARIO_H";
        sc.name = "Counterfactual Look-Ahead Consequence";
        sc.description = "Incident 1 (Medium) arrives. Dispatching the nearest ambulance strips protection from the Tech Corridor, where Incident 2 (Critical) arrives 4 mins later. Look-ahead optimizer preserves the vital asset.";
        sc.initial_network = base_net;
        std::vector<Ambulance> strategic_ambs = {
            {"AMB-01", "Medic-Alpha", "LOC-01", "Available", "LOC-01", 100.0},
            {"AMB-08", "Medic-Hotel", "LOC-08", "Available", "LOC-08", 91.0}, // Stationed at LOC-08
            {"AMB-05", "Medic-Echo", "LOC-05", "Available", "LOC-05", 92.0}
        };
        sc.initial_ambulances = strategic_ambs;
        sc.incidents = {
            {"INC-H1", "LOC-12", "Medium", 2.0, "Elderly knee dislocation", "Pending"},     // LOC-12 is slightly closer to AMB-08 than AMB-05
            {"INC-H2", "LOC-08", "Critical", 6.0, "Massive stroke at Tech Center", "Pending"} // LOC-08 Critical emergency!
        };
        predefined_scenarios.push_back(sc);
    }
}

StrategyMetrics PerformanceEvaluator::simulate_strategy(DispatchStrategy& strategy,
                                                         const ScenarioDefinition& scenario,
                                                         double service_duration_min) {
    StrategyMetrics metrics;
    metrics.strategy_name = strategy.get_strategy_name();
    metrics.total_incidents = static_cast<int>(scenario.incidents.size());
    metrics.incidents_served = 0;
    metrics.incidents_unserved = 0;
    metrics.total_travel_distance_km = 0.0;
    metrics.total_computation_time_ms = 0.0;

    // Work on local copies of network and fleet
    RoadNetwork net_copy = scenario.initial_network;
    std::vector<Ambulance> ambs_copy = scenario.initial_ambulances;
    std::vector<Incident> pending_queue;

    std::vector<double> response_times;
    std::vector<double> critical_response_times;
    std::vector<double> critical_waiting_times;
    std::vector<double> coverage_losses;

    double current_time = 0.0;

    for (const auto& inc_template : scenario.incidents) {
        Incident current_inc = inc_template;
        current_time = current_inc.get_arrival_time();

        // 1. Update existing ambulance mission statuses based on current_time
        for (auto& amb : ambs_copy) {
            amb.update_status(current_time);
        }

        // 2. Add current incident to queue and evaluate priority
        pending_queue.push_back(current_inc);

        // 3. Dispatch execution
        DispatchDecision decision = strategy.dispatch(current_inc, ambs_copy, net_copy, pending_queue, current_time);
        metrics.total_computation_time_ms += decision.get_computation_time_ms();
        metrics.decisions.push_back(decision);

        if (decision.get_is_feasible() && !decision.get_selected_ambulance_id().empty()) {
            metrics.incidents_served++;
            double resp_time = decision.get_estimated_travel_time();
            response_times.push_back(resp_time);
            metrics.total_travel_distance_km += decision.get_estimated_distance_km();
            coverage_losses.push_back(decision.get_coverage_loss_pct());

            if (current_inc.get_severity() == "Critical") {
                critical_response_times.push_back(resp_time);
                critical_waiting_times.push_back(current_inc.get_waiting_time());
            }

            // Mark ambulance busy
            for (auto& amb : ambs_copy) {
                if (amb.get_id() == decision.get_selected_ambulance_id()) {
                    double mission_dur = (resp_time * 2.0) + service_duration_min;
                    amb.assign_mission(current_inc.get_id(), mission_dur, current_time);
                    break;
                }
            }

            // Remove served incident from pending queue
            pending_queue.erase(std::remove_if(pending_queue.begin(), pending_queue.end(),
                [&](const Incident& i) { return i.get_id() == current_inc.get_id(); }), pending_queue.end());
        } else {
            metrics.incidents_unserved++;
            // Unserved incident remains pending in queue
        }
    }

    metrics.completion_rate_pct = (metrics.total_incidents > 0)
        ? (static_cast<double>(metrics.incidents_served) / metrics.total_incidents) * 100.0
        : 100.0;

    // Average response time
    if (!response_times.empty()) {
        double sum = std::accumulate(response_times.begin(), response_times.end(), 0.0);
        metrics.avg_response_time_min = sum / response_times.size();

        std::vector<double> sorted_resp = response_times;
        std::sort(sorted_resp.begin(), sorted_resp.end());
        size_t mid = sorted_resp.size() / 2;
        metrics.median_response_time_min = (sorted_resp.size() % 2 == 0)
            ? (sorted_resp[mid - 1] + sorted_resp[mid]) / 2.0
            : sorted_resp[mid];
    } else {
        metrics.avg_response_time_min = 0.0;
        metrics.median_response_time_min = 0.0;
    }

    // Critical metrics
    if (!critical_response_times.empty()) {
        double sum_c = std::accumulate(critical_response_times.begin(), critical_response_times.end(), 0.0);
        metrics.critical_avg_response_time_min = sum_c / critical_response_times.size();
    } else {
        metrics.critical_avg_response_time_min = 0.0;
    }

    if (!critical_waiting_times.empty()) {
        double sum_w = std::accumulate(critical_waiting_times.begin(), critical_waiting_times.end(), 0.0);
        metrics.critical_avg_waiting_time_min = sum_w / critical_waiting_times.size();
    } else {
        metrics.critical_avg_waiting_time_min = 0.0;
    }

    // Coverage metrics
    CoverageAnalyzer cov_analyzer;
    CoverageReport final_cov = cov_analyzer.compute_coverage(net_copy, ambs_copy);
    metrics.final_remaining_coverage_pct = final_cov.weighted_coverage_pct;

    if (!coverage_losses.empty()) {
        double sum_loss = std::accumulate(coverage_losses.begin(), coverage_losses.end(), 0.0);
        metrics.avg_coverage_loss_pct = sum_loss / coverage_losses.size();
    } else {
        metrics.avg_coverage_loss_pct = 0.0;
    }

    metrics.avg_computation_time_ms = (metrics.total_incidents > 0)
        ? (metrics.total_computation_time_ms / metrics.total_incidents)
        : 0.0;

    return metrics;
}

nlohmann::json PerformanceEvaluator::evaluate_scenario(const ScenarioDefinition& scenario) {
    nlohmann::json result;
    result["scenario_id"] = scenario.id;
    result["scenario_name"] = scenario.name;
    result["description"] = scenario.description;
    result["incident_count"] = scenario.incidents.size();
    result["initial_fleet_count"] = scenario.initial_ambulances.size();
    result["closed_roads"] = scenario.closed_roads;

    NearestAmbulanceStrategy strat_nearest;
    ImmediateScoringStrategy strat_immediate;
    LookAheadOptimizer strat_lookahead;

    StrategyMetrics m_nearest = simulate_strategy(strat_nearest, scenario);
    StrategyMetrics m_immediate = simulate_strategy(strat_immediate, scenario);
    StrategyMetrics m_lookahead = simulate_strategy(strat_lookahead, scenario);

    result["strategies"] = {
        {"nearest_available", m_nearest.to_json()},
        {"immediate_scoring", m_immediate.to_json()},
        {"lookahead_optimizer", m_lookahead.to_json()}
    };

    // Objective comparative summary
    std::string summary = "Comparative evaluation completed across 3 distinct strategies.";
    if (m_lookahead.critical_avg_response_time_min < m_nearest.critical_avg_response_time_min && m_nearest.critical_avg_response_time_min > 0) {
        summary += " Look-Ahead reduced Critical emergency response time from " +
                   std::to_string(m_nearest.critical_avg_response_time_min) + " min to " +
                   std::to_string(m_lookahead.critical_avg_response_time_min) + " min.";
    }
    result["objective_summary"] = summary;

    return result;
}

nlohmann::json PerformanceEvaluator::evaluate_scenario_by_id(const std::string& scenario_id) {
    for (const auto& sc : predefined_scenarios) {
        if (sc.id == scenario_id) {
            return evaluate_scenario(sc);
        }
    }
    nlohmann::json err;
    err["success"] = false;
    err["error"] = "Scenario ID '" + scenario_id + "' not found.";
    return err;
}

nlohmann::json PerformanceEvaluator::evaluate_all_scenarios() {
    nlohmann::json suite;
    suite["total_scenarios"] = predefined_scenarios.size();
    suite["benchmark_timestamp"] = "Simulated Evaluation Suite Run";
    suite["results"] = nlohmann::json::array();

    for (const auto& sc : predefined_scenarios) {
        suite["results"].push_back(evaluate_scenario(sc));
    }

    return suite;
}

nlohmann::json PerformanceEvaluator::get_scenarios_metadata() const {
    nlohmann::json arr = nlohmann::json::array();
    for (const auto& sc : predefined_scenarios) {
        arr.push_back({
            {"id", sc.id},
            {"name", sc.name},
            {"description", sc.description},
            {"incident_count", sc.incidents.size()},
            {"closed_roads", sc.closed_roads}
        });
    }
    return arr;
}

nlohmann::json PerformanceEvaluator::process_evaluation_json(const nlohmann::json& input_json) {
    std::string scenario_id = input_json.value("scenario_id", "SCENARIO_A");
    if (scenario_id == "ALL") {
        return evaluate_all_scenarios();
    }
    return evaluate_scenario_by_id(scenario_id);
}
