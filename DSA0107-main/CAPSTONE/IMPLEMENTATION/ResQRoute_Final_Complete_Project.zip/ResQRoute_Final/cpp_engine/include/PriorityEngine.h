#ifndef RESQROUTE_PRIORITYENGINE_H
#define RESQROUTE_PRIORITYENGINE_H

#include "Incident.h"
#include <vector>
#include <memory>
#include "json.hpp"

class PriorityEngine {
private:
    double default_severity_weight;
    double default_waiting_time_weight;

public:
    PriorityEngine(double sev_w = 25.0, double wait_w = 2.0);

    // Weight configuration
    void set_weights(double sev_w, double wait_w);
    double get_severity_weight() const { return default_severity_weight; }
    double get_waiting_time_weight() const { return default_waiting_time_weight; }

    // Evaluation
    double evaluate_incident(Incident& incident, double current_sim_time = -1.0) const;
    void rank_queue(std::vector<Incident>& incidents, double current_sim_time = -1.0) const;

    // Validation & State Machine
    bool validate_status_transition(const Incident& incident, const std::string& target_status, std::string& err_msg) const;
    bool execute_status_transition(Incident& incident, const std::string& target_status, std::string& err_msg) const;

    // Detailed JSON report for queue
    nlohmann::json process_incidents_json(const nlohmann::json& input_json) const;
};

#endif // RESQROUTE_PRIORITYENGINE_H
