#ifndef RESQROUTE_COVERAGEANALYZER_H
#define RESQROUTE_COVERAGEANALYZER_H

#include "RoadNetwork.h"
#include "Ambulance.h"
#include "RouteOptimizer.h"
#include <vector>
#include <string>
#include <set>
#include "json.hpp"

struct CoverageReport {
    double threshold_minutes;
    int total_locations;
    int covered_locations_count;
    double unweighted_coverage_pct;
    double weighted_coverage_pct;
    std::vector<std::string> covered_location_ids;
    std::vector<std::string> uncovered_location_ids;
    std::map<std::string, double> min_arrival_times; // location_id -> best ambulance arrival time

    nlohmann::json to_json() const {
        return {
            {"threshold_minutes", threshold_minutes},
            {"total_locations", total_locations},
            {"covered_locations_count", covered_locations_count},
            {"unweighted_coverage_pct", unweighted_coverage_pct},
            {"weighted_coverage_pct", weighted_coverage_pct},
            {"covered_location_ids", covered_location_ids},
            {"uncovered_location_ids", uncovered_location_ids},
            {"min_arrival_times", min_arrival_times}
        };
    }
};

class CoverageAnalyzer {
private:
    RouteOptimizer router;
    double default_threshold_minutes;

public:
    CoverageAnalyzer(double threshold = 10.0);

    void set_threshold(double threshold) { default_threshold_minutes = threshold; }
    double get_threshold() const { return default_threshold_minutes; }

    CoverageReport compute_coverage(const RoadNetwork& network,
                                    const std::vector<Ambulance>& ambulances,
                                    double custom_threshold = -1.0) const;

    // Evaluates coverage impact if a specific ambulance is dispatched (made busy)
    nlohmann::json evaluate_dispatch_coverage_impact(const RoadNetwork& network,
                                                     const std::vector<Ambulance>& all_ambulances,
                                                     const std::string& candidate_ambulance_id,
                                                     double custom_threshold = -1.0) const;

    nlohmann::json process_coverage_json(const RoadNetwork& network,
                                         const std::vector<Ambulance>& ambulances,
                                         const nlohmann::json& input_json) const;
};

#endif // RESQROUTE_COVERAGEANALYZER_H
