#ifndef RESQROUTE_INCIDENT_H
#define RESQROUTE_INCIDENT_H

#include <string>
#include "json.hpp"

class Incident {
private:
    std::string id;
    std::string location;
    std::string severity;       // "Critical", "High", "Medium", "Low"
    double arrival_time;        // In simulation minutes
    double waiting_time;        // Elapsed waiting minutes
    std::string description;
    std::string status;         // "Pending", "Dispatched", "In-Transit", "Resolved", "Cancelled"
    double priority_score;
    double severity_weight;
    double waiting_time_weight;
    std::string assigned_ambulance_id;

public:
    Incident();
    Incident(const std::string& id,
             const std::string& location,
             const std::string& severity,
             double arrival_time,
             const std::string& description,
             const std::string& status = "Pending",
             double severity_weight = 25.0,
             double waiting_time_weight = 2.0);

    // Getters
    std::string get_id() const { return id; }
    std::string get_location() const { return location; }
    std::string get_severity() const { return severity; }
    double get_arrival_time() const { return arrival_time; }
    double get_waiting_time() const { return waiting_time; }
    std::string get_description() const { return description; }
    std::string get_status() const { return status; }
    double get_priority_score() const { return priority_score; }
    double get_severity_weight() const { return severity_weight; }
    double get_waiting_time_weight() const { return waiting_time_weight; }
    std::string get_assigned_ambulance_id() const { return assigned_ambulance_id; }

    // Setters & Updaters
    void set_severity_weight(double sw) { severity_weight = sw; }
    void set_waiting_time_weight(double ww) { waiting_time_weight = ww; }
    void set_assigned_ambulance_id(const std::string& amb_id) { assigned_ambulance_id = amb_id; }

    double get_severity_factor() const;
    double calculate_priority(double sw = -1.0, double ww = -1.0);
    void update_waiting_time(double current_sim_time);
    
    // State machine transitions
    bool can_transition_to(const std::string& new_status) const;
    bool transition_to(const std::string& new_status);

    std::string get_priority_explanation() const;

    // Serialization
    nlohmann::json to_json() const;
    static Incident from_json(const nlohmann::json& j);
};

#endif // RESQROUTE_INCIDENT_H
