#ifndef RESQROUTE_DISPATCHDECISION_H
#define RESQROUTE_DISPATCHDECISION_H

#include <string>
#include <vector>
#include "json.hpp"

struct CandidateEvaluation {
    std::string ambulance_id;
    std::string call_sign;
    std::string current_location;
    bool is_reachable;
    double travel_time_min;
    double travel_distance_km;
    double immediate_response_cost;
    double future_delay_cost;
    double critical_delay_penalty;
    double coverage_loss_penalty;
    double road_disruption_penalty;
    double total_cost;
    double remaining_coverage_pct;
    double coverage_loss_pct;
    std::vector<std::string> path_nodes;
    std::string rank_explanation;

    nlohmann::json to_json() const {
        return {
            {"ambulance_id", ambulance_id},
            {"call_sign", call_sign},
            {"current_location", current_location},
            {"is_reachable", is_reachable},
            {"travel_time_min", travel_time_min},
            {"travel_distance_km", travel_distance_km},
            {"immediate_response_cost", immediate_response_cost},
            {"future_delay_cost", future_delay_cost},
            {"critical_delay_penalty", critical_delay_penalty},
            {"coverage_loss_penalty", coverage_loss_penalty},
            {"road_disruption_penalty", road_disruption_penalty},
            {"total_cost", total_cost},
            {"remaining_coverage_pct", remaining_coverage_pct},
            {"coverage_loss_pct", coverage_loss_pct},
            {"path_nodes", path_nodes},
            {"rank_explanation", rank_explanation}
        };
    }
};

class DispatchDecision {
private:
    std::string decision_id;
    std::string incident_id;
    std::string selected_ambulance_id;
    std::string strategy_name;
    bool is_feasible;
    double estimated_travel_time;
    double estimated_distance_km;
    double total_cost;
    double pre_coverage_pct;
    double post_coverage_pct;
    double coverage_loss_pct;
    std::vector<CandidateEvaluation> candidate_evaluations;
    std::string selection_reason;
    double computation_time_ms;
    double simulation_time;

public:
    DispatchDecision()
        : decision_id(""), incident_id(""), selected_ambulance_id(""), strategy_name(""),
          is_feasible(false), estimated_travel_time(0.0), estimated_distance_km(0.0),
          total_cost(0.0), pre_coverage_pct(0.0), post_coverage_pct(0.0), coverage_loss_pct(0.0),
          selection_reason("No candidates available"), computation_time_ms(0.0), simulation_time(0.0) {}

    // Getters & Setters
    std::string get_decision_id() const { return decision_id; }
    void set_decision_id(const std::string& id) { decision_id = id; }

    std::string get_incident_id() const { return incident_id; }
    void set_incident_id(const std::string& id) { incident_id = id; }

    std::string get_selected_ambulance_id() const { return selected_ambulance_id; }
    void set_selected_ambulance_id(const std::string& id) { selected_ambulance_id = id; }

    std::string get_strategy_name() const { return strategy_name; }
    void set_strategy_name(const std::string& name) { strategy_name = name; }

    bool get_is_feasible() const { return is_feasible; }
    void set_is_feasible(bool feasible) { is_feasible = feasible; }

    double get_estimated_travel_time() const { return estimated_travel_time; }
    void set_estimated_travel_time(double t) { estimated_travel_time = t; }

    double get_estimated_distance_km() const { return estimated_distance_km; }
    void set_estimated_distance_km(double d) { estimated_distance_km = d; }

    double get_total_cost() const { return total_cost; }
    void set_total_cost(double c) { total_cost = c; }

    double get_pre_coverage_pct() const { return pre_coverage_pct; }
    void set_pre_coverage_pct(double p) { pre_coverage_pct = p; }

    double get_post_coverage_pct() const { return post_coverage_pct; }
    void set_post_coverage_pct(double p) { post_coverage_pct = p; }

    double get_coverage_loss_pct() const { return coverage_loss_pct; }
    void set_coverage_loss_pct(double p) { coverage_loss_pct = p; }

    const std::vector<CandidateEvaluation>& get_candidate_evaluations() const { return candidate_evaluations; }
    void add_candidate_evaluation(const CandidateEvaluation& ce) { candidate_evaluations.push_back(ce); }
    void set_candidate_evaluations(const std::vector<CandidateEvaluation>& evals) { candidate_evaluations = evals; }

    std::string get_selection_reason() const { return selection_reason; }
    void set_selection_reason(const std::string& r) { selection_reason = r; }

    double get_computation_time_ms() const { return computation_time_ms; }
    void set_computation_time_ms(double t) { computation_time_ms = t; }

    double get_simulation_time() const { return simulation_time; }
    void set_simulation_time(double t) { simulation_time = t; }

    nlohmann::json to_json() const {
        nlohmann::json candidates_arr = nlohmann::json::array();
        for (const auto& c : candidate_evaluations) {
            candidates_arr.push_back(c.to_json());
        }
        return {
            {"decision_id", decision_id},
            {"incident_id", incident_id},
            {"selected_ambulance_id", selected_ambulance_id},
            {"strategy_name", strategy_name},
            {"is_feasible", is_feasible},
            {"estimated_travel_time_min", estimated_travel_time},
            {"estimated_distance_km", estimated_distance_km},
            {"total_cost", total_cost},
            {"pre_coverage_pct", pre_coverage_pct},
            {"post_coverage_pct", post_coverage_pct},
            {"coverage_loss_pct", coverage_loss_pct},
            {"selection_reason", selection_reason},
            {"computation_time_ms", computation_time_ms},
            {"simulation_time", simulation_time},
            {"candidate_evaluations", candidates_arr}
        };
    }
};

#endif // RESQROUTE_DISPATCHDECISION_H
