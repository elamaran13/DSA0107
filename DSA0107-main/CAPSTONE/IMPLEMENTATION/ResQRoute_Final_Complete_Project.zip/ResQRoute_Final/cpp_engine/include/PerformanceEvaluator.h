#ifndef RESQROUTE_PERFORMANCEEVALUATOR_H
#define RESQROUTE_PERFORMANCEEVALUATOR_H

#include "Incident.h"
#include "Ambulance.h"
#include "RoadNetwork.h"
#include "DispatchDecision.h"
#include "DispatchStrategy.h"
#include "LookAheadOptimizer.h"
#include <vector>
#include <string>
#include "json.hpp"

struct StrategyMetrics {
    std::string strategy_name;
    int total_incidents;
    int incidents_served;
    int incidents_unserved;
    double completion_rate_pct;
    double avg_response_time_min;
    double median_response_time_min;
    double critical_avg_response_time_min;
    double critical_avg_waiting_time_min;
    double total_travel_distance_km;
    double final_remaining_coverage_pct;
    double avg_coverage_loss_pct;
    double total_computation_time_ms;
    double avg_computation_time_ms;
    std::vector<DispatchDecision> decisions;

    nlohmann::json to_json() const;
};

struct ScenarioDefinition {
    std::string id;             // "SCENARIO_A" .. "SCENARIO_H"
    std::string name;
    std::string description;
    RoadNetwork initial_network;
    std::vector<Ambulance> initial_ambulances;
    std::vector<Incident> incidents;
    std::vector<std::string> closed_roads;
};

class PerformanceEvaluator {
private:
    std::vector<ScenarioDefinition> predefined_scenarios;

    void initialize_predefined_scenarios();

public:
    PerformanceEvaluator();

    // Runs a specific strategy across an incident sequence on a fresh copy of the world
    StrategyMetrics simulate_strategy(DispatchStrategy& strategy,
                                     const ScenarioDefinition& scenario,
                                     double service_duration_min = 15.0);

    // Runs comparison of all 3 strategies on a given scenario
    nlohmann::json evaluate_scenario(const ScenarioDefinition& scenario);

    // Runs comparison by scenario ID (e.g. "SCENARIO_A" to "SCENARIO_H")
    nlohmann::json evaluate_scenario_by_id(const std::string& scenario_id);

    // Runs full suite across all scenarios
    nlohmann::json evaluate_all_scenarios();

    // Get list of available scenario definitions
    nlohmann::json get_scenarios_metadata() const;

    // Process evaluation JSON request from Python
    nlohmann::json process_evaluation_json(const nlohmann::json& input_json);
};

#endif // RESQROUTE_PERFORMANCEEVALUATOR_H
