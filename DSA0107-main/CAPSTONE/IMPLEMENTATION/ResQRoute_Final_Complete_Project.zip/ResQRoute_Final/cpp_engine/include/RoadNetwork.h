#ifndef RESQROUTE_ROADNETWORK_H
#define RESQROUTE_ROADNETWORK_H

#include "Road.h"
#include <map>
#include <vector>
#include <string>

class RoadNetwork {
private:
    std::map<std::string, Location> locations;
    std::map<std::string, Road> roads;
    std::map<std::string, std::vector<Road>> adjacency_list;

public:
    RoadNetwork();

    void add_location(const Location& loc);
    void add_road(const Road& road);

    bool has_location(const std::string& loc_id) const;
    Location get_location(const std::string& loc_id) const;
    const std::map<std::string, Location>& get_all_locations() const { return locations; }

    bool has_road(const std::string& road_id) const;
    Road get_road(const std::string& road_id) const;
    const std::map<std::string, Road>& get_all_roads() const { return roads; }

    bool close_road(const std::string& road_id, const std::string& reason = "Disruption");
    bool reopen_road(const std::string& road_id);
    void reset_all_closures();

    std::vector<Road> get_active_roads() const;
    std::vector<Road> get_closed_roads() const;
    std::vector<Road> get_outgoing_roads(const std::string& loc_id, bool include_closed = false) const;

    nlohmann::json to_json() const;
    static RoadNetwork from_json(const nlohmann::json& j);

    void populate_default_urban_network();
};

#endif // RESQROUTE_ROADNETWORK_H
