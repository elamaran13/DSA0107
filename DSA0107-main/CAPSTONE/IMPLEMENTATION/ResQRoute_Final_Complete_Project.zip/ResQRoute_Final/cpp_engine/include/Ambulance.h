#ifndef RESQROUTE_AMBULANCE_H
#define RESQROUTE_AMBULANCE_H

#include <string>
#include "json.hpp"

class Ambulance {
private:
    std::string id;
    std::string call_sign;
    std::string current_location;
    std::string status;              // "Available", "Busy", "Maintenance"
    std::string station_id;
    double fuel_level;               // 0.0 to 100.0%
    std::string assigned_incident_id;
    double busy_until_time;          // In simulation minutes

public:
    Ambulance();
    Ambulance(const std::string& id,
              const std::string& call_sign,
              const std::string& current_location,
              const std::string& status = "Available",
              const std::string& station_id = "",
              double fuel_level = 100.0,
              const std::string& assigned_incident_id = "",
              double busy_until_time = 0.0);

    // Getters
    std::string get_id() const { return id; }
    std::string get_call_sign() const { return call_sign; }
    std::string get_current_location() const { return current_location; }
    std::string get_status() const { return status; }
    std::string get_station_id() const { return station_id; }
    double get_fuel_level() const { return fuel_level; }
    std::string get_assigned_incident_id() const { return assigned_incident_id; }
    double get_busy_until_time() const { return busy_until_time; }

    // Setters
    void set_current_location(const std::string& loc) { current_location = loc; }
    void set_status(const std::string& st) { status = st; }
    void set_fuel_level(double f) { fuel_level = f; }

    bool is_available() const { return status == "Available"; }
    bool assign_mission(const std::string& incident_id, double mission_duration, double current_time);
    void release_mission();
    void update_status(double current_sim_time);

    // Serialization
    nlohmann::json to_json() const;
    static Ambulance from_json(const nlohmann::json& j);
};

#endif // RESQROUTE_AMBULANCE_H
