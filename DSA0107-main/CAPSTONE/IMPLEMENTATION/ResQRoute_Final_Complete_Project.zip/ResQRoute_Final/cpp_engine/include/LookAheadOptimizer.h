#ifndef RESQROUTE_LOOKAHEADOPTIMIZER_H
#define RESQROUTE_LOOKAHEADOPTIMIZER_H

#include "DispatchStrategy.h"
#include <vector>
#include <random>

struct LookAheadWeights {
    double immediate_weight;          // Weight for immediate response cost (default 1.0)
    double future_delay_weight;       // Weight for future emergency delay (default 1.5)
    double critical_penalty_weight;   // Weight for future critical emergency delay (default 3.0)
    double coverage_loss_weight;      // Weight for coverage loss percentage (default 1.8)
    double road_disruption_weight;    // Weight for road disruption detour delay (default 1.2)

    LookAheadWeights()
        : immediate_weight(1.0),
          future_delay_weight(1.5),
          critical_penalty_weight(3.0),
          coverage_loss_weight(1.8),
          road_disruption_weight(1.2) {}
};

class LookAheadOptimizer : public DispatchStrategy {
private:
    LookAheadWeights weights;
    int scenario_count;               // Number of stochastic look-ahead rollouts (default 5)
    double lookahead_horizon_minutes; // Future evaluation horizon (e.g. 45.0 min)
    unsigned int random_seed;         // Deterministic seed for reproducible evaluation

    // Helper to generate deterministic future scenarios for rollout evaluation
    std::vector<Incident> generate_future_scenarios(const RoadNetwork& network,
                                                    double current_sim_time) const;

public:
    LookAheadOptimizer(const LookAheadWeights& w = LookAheadWeights(),
                       int scenarios = 5,
                       double horizon = 45.0,
                       unsigned int seed = 42);

    std::string get_strategy_name() const override { return "Counterfactual Look-Ahead Optimizer"; }

    // Configuration
    void set_weights(const LookAheadWeights& w) { weights = w; }
    LookAheadWeights get_weights() const { return weights; }
    void set_scenario_count(int count) { scenario_count = count; }
    void set_horizon(double h) { lookahead_horizon_minutes = h; }
    void set_seed(unsigned int s) { random_seed = s; }

    // Primary Dispatch Execution
    DispatchDecision dispatch(const Incident& incident,
                             const std::vector<Ambulance>& ambulances,
                             const RoadNetwork& network,
                             const std::vector<Incident>& pending_queue,
                             double current_sim_time) override;

    // Detailed JSON runner for Python bridge
    nlohmann::json process_dispatch_json(const nlohmann::json& input_json) const;
};

#endif // RESQROUTE_LOOKAHEADOPTIMIZER_H
