#ifndef RESQROUTE_DISPATCHSTRATEGY_H
#define RESQROUTE_DISPATCHSTRATEGY_H

#include "Incident.h"
#include "Ambulance.h"
#include "RoadNetwork.h"
#include "DispatchDecision.h"
#include "RouteOptimizer.h"
#include "CoverageAnalyzer.h"
#include <vector>
#include <memory>
#include <chrono>

class DispatchStrategy {
protected:
    RouteOptimizer router;
    CoverageAnalyzer coverage_analyzer;

public:
    virtual ~DispatchStrategy() = default;
    virtual std::string get_strategy_name() const = 0;

    virtual DispatchDecision dispatch(const Incident& incident,
                                     const std::vector<Ambulance>& ambulances,
                                     const RoadNetwork& network,
                                     const std::vector<Incident>& pending_queue,
                                     double current_sim_time) = 0;
};

// Strategy 1: Nearest Available Ambulance (Standard Greedy Baseline)
class NearestAmbulanceStrategy : public DispatchStrategy {
public:
    std::string get_strategy_name() const override { return "Nearest-Available Baseline"; }

    DispatchDecision dispatch(const Incident& incident,
                             const std::vector<Ambulance>& ambulances,
                             const RoadNetwork& network,
                             const std::vector<Incident>& pending_queue,
                             double current_sim_time) override;
};

// Strategy 2: Immediate Priority & Coverage Scoring (Static Heuristic Baseline)
class ImmediateScoringStrategy : public DispatchStrategy {
private:
    double immediate_weight;
    double coverage_weight;

public:
    ImmediateScoringStrategy(double imm_w = 1.0, double cov_w = 1.5);
    std::string get_strategy_name() const override { return "Immediate Priority-Coverage Baseline"; }

    DispatchDecision dispatch(const Incident& incident,
                             const std::vector<Ambulance>& ambulances,
                             const RoadNetwork& network,
                             const std::vector<Incident>& pending_queue,
                             double current_sim_time) override;
};

#endif // RESQROUTE_DISPATCHSTRATEGY_H
