#ifndef RESQROUTE_ROUTEOPTIMIZER_H
#define RESQROUTE_ROUTEOPTIMIZER_H

#include "RoadNetwork.h"
#include <vector>
#include <string>
#include "json.hpp"

struct RouteResult {
    bool is_reachable;
    std::string source;
    std::string destination;
    std::vector<std::string> path_nodes;
    std::vector<std::string> path_roads;
    double total_distance_km;
    double total_travel_time_min;
    int edges_traversed;
    std::string status_message;

    nlohmann::json to_json() const {
        return {
            {"is_reachable", is_reachable},
            {"source", source},
            {"destination", destination},
            {"path_nodes", path_nodes},
            {"path_roads", path_roads},
            {"total_distance_km", total_distance_km},
            {"total_travel_time_min", total_travel_time_min},
            {"edges_traversed", edges_traversed},
            {"status_message", status_message}
        };
    }
};

class RouteOptimizer {
public:
    RouteOptimizer();

    // Core Dijkstra implementation
    RouteResult find_shortest_path(const RoadNetwork& network,
                                   const std::string& source,
                                   const std::string& destination,
                                   bool ignore_closures = false) const;

    // Compare default route vs detour under road disruption
    nlohmann::json compare_routes_under_closure(const RoadNetwork& network,
                                                const std::string& source,
                                                const std::string& destination,
                                                const std::string& closed_road_id) const;

    // Process general routing request from JSON
    nlohmann::json process_route_json(const RoadNetwork& network, const nlohmann::json& input_json) const;
};

#endif // RESQROUTE_ROUTEOPTIMIZER_H
