#ifndef RESQROUTE_ROAD_H
#define RESQROUTE_ROAD_H

#include <string>
#include "json.hpp"

struct Location {
    std::string id;
    std::string name;
    std::string type;           // "Hospital", "Station", "Residential", "Commercial", "Industrial"
    double demand_weight;       // 1.0 to 5.0 for population/risk weighting
    double latitude;
    double longitude;

    nlohmann::json to_json() const {
        return {
            {"id", id},
            {"name", name},
            {"type", type},
            {"demand_weight", demand_weight},
            {"latitude", latitude},
            {"longitude", longitude}
        };
    }

    static Location from_json(const nlohmann::json& j) {
        Location loc;
        loc.id = j.value("id", "");
        loc.name = j.value("name", "");
        loc.type = j.value("type", "Residential");
        loc.demand_weight = j.value("demand_weight", 1.0);
        loc.latitude = j.value("latitude", 0.0);
        loc.longitude = j.value("longitude", 0.0);
        return loc;
    }
};

class Road {
private:
    std::string road_id;
    std::string source;
    std::string destination;
    double distance_km;
    double speed_limit_kmh;
    double base_travel_time_min;
    bool is_closed;
    std::string closure_reason;
    bool is_bidirectional;

public:
    Road();
    Road(const std::string& road_id,
         const std::string& source,
         const std::string& destination,
         double distance_km,
         double speed_limit_kmh,
         bool is_closed = false,
         const std::string& closure_reason = "",
         bool is_bidirectional = true);

    std::string get_road_id() const { return road_id; }
    std::string get_source() const { return source; }
    std::string get_destination() const { return destination; }
    double get_distance_km() const { return distance_km; }
    double get_speed_limit_kmh() const { return speed_limit_kmh; }
    double get_travel_time_min() const { return base_travel_time_min; }
    bool get_is_closed() const { return is_closed; }
    std::string get_closure_reason() const { return closure_reason; }
    bool get_is_bidirectional() const { return is_bidirectional; }

    void set_closed(bool closed, const std::string& reason = "") {
        is_closed = closed;
        closure_reason = closed ? reason : "";
    }

    nlohmann::json to_json() const;
    static Road from_json(const nlohmann::json& j);
};

#endif // RESQROUTE_ROAD_H
