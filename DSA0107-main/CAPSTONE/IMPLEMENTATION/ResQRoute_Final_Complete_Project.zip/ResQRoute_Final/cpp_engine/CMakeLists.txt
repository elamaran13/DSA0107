cmake_minimum_required(VERSION 3.15)
project(ResQRouteEngine CXX)

set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
set(CMAKE_CXX_EXTENSIONS OFF)

# Place compiled binaries directly in cpp_engine/ for Python bridge integration
set(CMAKE_RUNTIME_OUTPUT_DIRECTORY "${CMAKE_CURRENT_SOURCE_DIR}")
set(CMAKE_RUNTIME_OUTPUT_DIRECTORY_RELEASE "${CMAKE_CURRENT_SOURCE_DIR}")
set(CMAKE_RUNTIME_OUTPUT_DIRECTORY_DEBUG "${CMAKE_CURRENT_SOURCE_DIR}")

if(MSVC)
    add_compile_options(/O2 /W3)
else()
    add_compile_options(-O2 -Wall)
endif()

include_directories(include)

set(CORE_SOURCES
    src/Incident.cpp
    src/Ambulance.cpp
    src/RoadNetwork.cpp
    src/PriorityEngine.cpp
    src/DispatchStrategy.cpp
    src/RouteOptimizer.cpp
    src/CoverageAnalyzer.cpp
    src/LookAheadOptimizer.cpp
    src/PerformanceEvaluator.cpp
)

# Main CLI executable
add_executable(resqroute_engine src/main.cpp ${CORE_SOURCES})

# Test executable
add_executable(resqroute_tests tests/cpp_tests.cpp ${CORE_SOURCES})

enable_testing()
add_test(NAME CppCoreTests COMMAND resqroute_tests)
