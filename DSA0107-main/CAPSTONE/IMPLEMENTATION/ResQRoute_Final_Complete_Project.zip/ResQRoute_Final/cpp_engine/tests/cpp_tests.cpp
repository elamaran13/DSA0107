#include <iostream>
#include <cassert>
#include <cmath>
#include "Incident.h"
#include "Ambulance.h"
#include "RoadNetwork.h"
#include "PriorityEngine.h"
#include "RouteOptimizer.h"
#include "CoverageAnalyzer.h"
#include "LookAheadOptimizer.h"
#include "PerformanceEvaluator.h"

int passed_tests = 0;
int total_tests = 0;

#define ASSERT_TRUE(cond, msg) do { \
    total_tests++; \
    if (cond) { \
        passed_tests++; \
        std::cout << "  [PASS] " << msg << std::endl; \
    } else { \
        std::cerr << "  [FAIL] " << msg << " (line " << __LINE__ << ")" << std::endl; \
    } \
} while(0)

void test_priority_engine() {
    std::cout << "\n=== Running Priority Engine Unit Tests ===" << std::endl;
    Incident inc("INC-TEST-1", "LOC-01", "Critical", 10.0, "Cardiac arrest");
    inc.calculate_priority(25.0, 2.0);
    // Critical = 4.0 * 25.0 = 100.0, waiting time = 0 -> 100.0
    ASSERT_TRUE(std::abs(inc.get_priority_score() - 100.0) < 1e-4, "Critical incident base priority equals 100.0");

    // Advance simulation time to 20.0 -> waiting time = 10.0 min
    inc.update_waiting_time(20.0);
    // 100.0 + (10.0 * 2.0) = 120.0
    ASSERT_TRUE(std::abs(inc.get_priority_score() - 120.0) < 1e-4, "Incident priority increases correctly with waiting time");

    // Priority ranking
    Incident inc2("INC-TEST-2", "LOC-02", "Low", 5.0, "Minor scratch"); // 1.0 * 25.0 + 15 * 2 = 55
    inc2.update_waiting_time(20.0);
    std::vector<Incident> q = {inc2, inc};
    PriorityEngine pe(25.0, 2.0);
    pe.rank_queue(q, 20.0);
    ASSERT_TRUE(q[0].get_id() == "INC-TEST-1", "Queue puts Critical incident ahead of Low incident");

    // State machine transitions
    std::string err;
    ASSERT_TRUE(pe.validate_status_transition(inc, "Dispatched", err), "Pending -> Dispatched is valid");
    inc.transition_to("Dispatched");
    ASSERT_TRUE(pe.validate_status_transition(inc, "In-Transit", err), "Dispatched -> In-Transit is valid");
    inc.transition_to("In-Transit");
    ASSERT_TRUE(!pe.validate_status_transition(inc, "Pending", err), "In-Transit -> Pending is invalid and rejected");
}

void test_dijkstra_and_road_closures() {
    std::cout << "\n=== Running Dijkstra & Road Disruption Unit Tests ===" << std::endl;
    RoadNetwork net;
    net.populate_default_urban_network();
    RouteOptimizer router;

    // Normal shortest path LOC-01 to LOC-03
    RouteResult r1 = router.find_shortest_path(net, "LOC-01", "LOC-03");
    ASSERT_TRUE(r1.is_reachable, "Route LOC-01 to LOC-03 is reachable");
    ASSERT_TRUE(r1.total_distance_km > 0.0, "Path distance is positive");
    ASSERT_TRUE(r1.total_travel_time_min > 0.0, "Path travel time is positive");

    // Close direct road RD-01 (LOC-01 <-> LOC-03)
    net.close_road("RD-01", "Construction");
    ASSERT_TRUE(net.get_road("RD-01").get_is_closed(), "Road RD-01 marked closed");

    // Detour route LOC-01 to LOC-03
    RouteResult r2 = router.find_shortest_path(net, "LOC-01", "LOC-03");
    ASSERT_TRUE(r2.is_reachable, "Alternative detour exists when RD-01 is closed");
    ASSERT_TRUE(r2.total_travel_time_min > r1.total_travel_time_min, "Detour travel time is greater than direct route");

    // Unreachable test: close RD-24 leading to isolated LOC-16
    net.close_road("RD-24", "Bridge Collapse");
    RouteResult r_unreach = router.find_shortest_path(net, "LOC-01", "LOC-16");
    ASSERT_TRUE(!r_unreach.is_reachable, "Severed bridge renders LOC-16 unreachable");
}

void test_ambulance_assignment_validation() {
    std::cout << "\n=== Running Ambulance Assignment Unit Tests ===" << std::endl;
    Ambulance amb("AMB-01", "Medic-1", "LOC-01", "Available");
    ASSERT_TRUE(amb.is_available(), "New ambulance starts Available");

    bool assigned = amb.assign_mission("INC-01", 30.0, 10.0);
    ASSERT_TRUE(assigned && !amb.is_available(), "Ambulance transitions to Busy upon mission assignment");

    // Try assigning another mission simultaneously
    bool double_assign = amb.assign_mission("INC-02", 20.0, 15.0);
    ASSERT_TRUE(!double_assign, "Simultaneous double assignment is strictly rejected");

    // Update time past busy_until_time (10 + 30 = 40)
    amb.update_status(45.0);
    ASSERT_TRUE(amb.is_available(), "Ambulance automatically releases after mission completion time");
}

void test_coverage_analyzer() {
    std::cout << "\n=== Running Ambulance Coverage Unit Tests ===" << std::endl;
    RoadNetwork net;
    net.populate_default_urban_network();

    std::vector<Ambulance> ambs = {
        {"AMB-01", "Medic-1", "LOC-01", "Available"},
        {"AMB-02", "Medic-2", "LOC-05", "Available"}
    };

    CoverageAnalyzer ca(10.0);
    CoverageReport rep = ca.compute_coverage(net, ambs);
    ASSERT_TRUE(rep.covered_locations_count > 0, "Network has positive covered locations");
    ASSERT_TRUE(rep.weighted_coverage_pct > 0.0 && rep.weighted_coverage_pct <= 100.0, "Coverage percentage within [0, 100]");

    // Dispatching AMB-01 should cause coverage loss
    auto impact = ca.evaluate_dispatch_coverage_impact(net, ambs, "AMB-01");
    ASSERT_TRUE(impact["coverage_loss_pct"].get<double>() >= 0.0, "Coverage loss is non-negative");
}

void test_lookahead_optimizer() {
    std::cout << "\n=== Running Look-Ahead Optimizer Unit Tests ===" << std::endl;
    RoadNetwork net;
    net.populate_default_urban_network();

    std::vector<Ambulance> ambs = {
        {"AMB-01", "Medic-Alpha", "LOC-01", "Available"},
        {"AMB-02", "Medic-Bravo", "LOC-05", "Available"}
    };

    Incident inc("INC-EMERGENCY", "LOC-03", "Critical", 5.0, "Multiple trauma");
    std::vector<Incident> pending = {inc};

    LookAheadOptimizer opt;
    DispatchDecision dec = opt.dispatch(inc, ambs, net, pending, 5.0);

    ASSERT_TRUE(dec.get_is_feasible(), "Look-Ahead optimizer generates feasible dispatch");
    ASSERT_TRUE(!dec.get_selected_ambulance_id().empty(), "Ambulance selected");
    ASSERT_TRUE(dec.get_candidate_evaluations().size() == 2, "Evaluated both candidate ambulances");
    ASSERT_TRUE(dec.get_computation_time_ms() >= 0.0, "Computation time measured accurately");
}

void test_multi_scenario_evaluation() {
    std::cout << "\n=== Running Performance Evaluator Scenarios ===" << std::endl;
    PerformanceEvaluator eval;
    nlohmann::json res_a = eval.evaluate_scenario_by_id("SCENARIO_A");
    ASSERT_TRUE(res_a.contains("strategies"), "Scenario A contains all 3 strategies");
    ASSERT_TRUE(res_a["strategies"].contains("nearest_available"), "Nearest available baseline present");
    ASSERT_TRUE(res_a["strategies"].contains("immediate_scoring"), "Immediate scoring baseline present");
    ASSERT_TRUE(res_a["strategies"].contains("lookahead_optimizer"), "Look-Ahead optimizer present");

    double near_time = res_a["strategies"]["nearest_available"]["avg_response_time_min"].get<double>();
    double look_time = res_a["strategies"]["lookahead_optimizer"]["avg_response_time_min"].get<double>();
    ASSERT_TRUE(near_time >= 0.0 && look_time >= 0.0, "Response times calculated and non-negative");
}

int main() {
    std::cout << "Starting ResQRoute C++ Test Suite..." << std::endl;

    test_priority_engine();
    test_dijkstra_and_road_closures();
    test_ambulance_assignment_validation();
    test_coverage_analyzer();
    test_lookahead_optimizer();
    test_multi_scenario_evaluation();

    std::cout << "\n==========================================" << std::endl;
    std::cout << "C++ Test Suite Summary: " << passed_tests << " / " << total_tests << " Passed ("
              << (total_tests > 0 ? (passed_tests * 100 / total_tests) : 0) << "%)" << std::endl;
    std::cout << "==========================================" << std::endl;

    return (passed_tests == total_tests) ? 0 : 1;
}
