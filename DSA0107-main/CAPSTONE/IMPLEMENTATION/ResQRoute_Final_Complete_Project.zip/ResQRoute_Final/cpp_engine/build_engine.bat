@echo off
setlocal enabledelayedexpansion

echo =====================================================================
echo ResQRoute C++17 Engine Builder
echo =====================================================================
cd /d "%~dp0"

where cmake >nul 2>&1
if %ERRORLEVEL% EQU 0 (
    echo [*] Found CMake on system. Building via CMake...
    if not exist "build" mkdir build
    where mingw32-make >nul 2>&1
    if !ERRORLEVEL! EQU 0 (
        cmake -S . -B build -G "MinGW Makefiles" -DCMAKE_BUILD_TYPE=Release
    ) else (
        cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
    )
    if !ERRORLEVEL! EQU 0 (
        cmake --build build --config Release
        if !ERRORLEVEL! EQU 0 (
            echo [OK] CMake build completed successfully.
            goto :test
        )
    )
    echo [!] CMake build encountered an issue. Falling back to direct g++...
)

where g++ >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    if exist "C:\Program Files (x86)\Embarcadero\Dev-Cpp\TDM-GCC-64\bin\g++.exe" (
        set "PATH=C:\Program Files (x86)\Embarcadero\Dev-Cpp\TDM-GCC-64\bin;%PATH%"
    )
)

where g++ >nul 2>&1
if %ERRORLEVEL% EQU 0 (
    echo [*] Compiling C++17 Core Engine via g++...
    g++ -std=c++17 -O2 -Iinclude src/main.cpp src/Incident.cpp src/Ambulance.cpp src/RoadNetwork.cpp src/PriorityEngine.cpp src/DispatchStrategy.cpp src/RouteOptimizer.cpp src/CoverageAnalyzer.cpp src/LookAheadOptimizer.cpp src/PerformanceEvaluator.cpp -o resqroute_engine.exe
    if !ERRORLEVEL! NEQ 0 (
        echo [ERROR] Failed to compile resqroute_engine.exe
        exit /b 1
    )
    echo [*] Compiling C++17 Unit Test Suite via g++...
    g++ -std=c++17 -O2 -Iinclude tests/cpp_tests.cpp src/Incident.cpp src/Ambulance.cpp src/RoadNetwork.cpp src/PriorityEngine.cpp src/DispatchStrategy.cpp src/RouteOptimizer.cpp src/CoverageAnalyzer.cpp src/LookAheadOptimizer.cpp src/PerformanceEvaluator.cpp -o resqroute_tests.exe
    if !ERRORLEVEL! NEQ 0 (
        echo [ERROR] Failed to compile resqroute_tests.exe
        exit /b 1
    )
    echo [OK] Direct g++ compilation succeeded.
) else (
    echo [ERROR] No suitable C++17 compiler (CMake or g++) found in PATH.
    echo Please install MinGW-w64 (g++) or Visual Studio C++ build tools.
    exit /b 1
)

:test
echo.
echo [*] Verifying compiled C++ engine...
if exist "resqroute_engine.exe" (
    .\resqroute_engine.exe --mode ping
)
echo.
echo [*] Running C++ unit test suite...
if exist "resqroute_tests.exe" (
    .\resqroute_tests.exe
)
echo =====================================================================
echo C++ build and verification complete.
echo =====================================================================
endlocal
