import sqlite3
import logging
from typing import Dict, Any, List, Optional, Tuple
from database import get_connection
from cpp_bridge import engine_bridge

logger = logging.getLogger("ResQRoute.RoadService")

class RoadService:
    """
    Manages road network topology, road closures, Dijkstra path computation, and coverage assessment.
    """

    def get_locations(self) -> List[Dict[str, Any]]:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM locations ORDER BY id ASC;")
        rows = [dict(r) for r in cursor.fetchall()]
        conn.close()
        return rows

    def get_roads(self) -> List[Dict[str, Any]]:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM roads ORDER BY road_id ASC;")
        rows = []
        for r in cursor.fetchall():
            d = dict(r)
            d["is_closed"] = bool(d["is_closed"])
            d["is_bidirectional"] = bool(d["is_bidirectional"])
            rows.append(d)
        conn.close()
        return rows

    def get_road_closures(self) -> List[Dict[str, Any]]:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("""
            SELECT rc.*, r.source, r.destination, r.distance_km
            FROM road_closures rc
            JOIN roads r ON rc.road_id = r.road_id
            WHERE rc.is_active = 1
            ORDER BY rc.closed_at DESC;
        """)
        rows = [dict(r) for r in cursor.fetchall()]
        conn.close()
        return rows

    def get_road_network_payload(self) -> Dict[str, Any]:
        """Builds structured JSON payload of current road network topology for C++ engine."""
        locs = self.get_locations()
        roads = self.get_roads()
        return {
            "locations": locs,
            "roads": roads
        }

    def close_road(self, road_id: str, reason: str = "Disruption") -> Tuple[bool, str]:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT road_id, is_closed FROM roads WHERE road_id = ?;", (road_id,))
        road = cursor.fetchone()
        if not road:
            conn.close()
            return False, f"Road {road_id} not found."

        if road["is_closed"]:
            conn.close()
            return True, f"Road {road_id} is already closed."

        cursor.execute("""
            UPDATE roads
            SET is_closed = 1, closure_reason = ?
            WHERE road_id = ?;
        """, (reason, road_id))

        cursor.execute("""
            INSERT INTO road_closures (road_id, reason, is_active)
            VALUES (?, ?, 1);
        """, (road_id, reason))

        conn.commit()
        conn.close()
        return True, f"Road {road_id} marked as closed ({reason})."

    def reopen_road(self, road_id: str) -> Tuple[bool, str]:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT road_id, is_closed FROM roads WHERE road_id = ?;", (road_id,))
        road = cursor.fetchone()
        if not road:
            conn.close()
            return False, f"Road {road_id} not found."

        cursor.execute("""
            UPDATE roads
            SET is_closed = 0, closure_reason = ''
            WHERE road_id = ?;
        """, (road_id,))

        cursor.execute("""
            UPDATE road_closures
            SET is_active = 0, reopened_at = CURRENT_TIMESTAMP
            WHERE road_id = ? AND is_active = 1;
        """, (road_id,))

        conn.commit()
        conn.close()
        return True, f"Road {road_id} reopened for traffic."

    def reset_closures(self) -> Tuple[bool, str]:
        """Reopens all closed road segments and clears active closures."""
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("UPDATE roads SET is_closed = 0, closure_reason = '';")
        cursor.execute("UPDATE road_closures SET is_active = 0, reopened_at = CURRENT_TIMESTAMP WHERE is_active = 1;")
        conn.commit()
        conn.close()
        return True, "All roads reopened successfully."

    def find_route(
        self,
        source: str,
        destination: str,
        ignore_closures: bool = False
    ) -> Dict[str, Any]:
        """Calculates Dijkstra shortest path using the C++ engine."""
        network = self.get_road_network_payload()
        return engine_bridge.compute_route(
            source=source,
            destination=destination,
            road_network=network,
            ignore_closures=ignore_closures
        )

    # Alias for convenience
    calculate_route = find_route

    def analyze_coverage(
        self,
        ambulances: Optional[List[Dict[str, Any]]] = None,
        threshold_minutes: float = 10.0,
        candidate_id: Optional[str] = None
    ) -> Dict[str, Any]:
        """Analyzes network coverage using the C++ engine."""
        network = self.get_road_network_payload()
        return engine_bridge.compute_coverage(
            road_network=network,
            ambulances=ambulances,
            threshold_minutes=threshold_minutes,
            candidate_id=candidate_id
        )


road_service = RoadService()
