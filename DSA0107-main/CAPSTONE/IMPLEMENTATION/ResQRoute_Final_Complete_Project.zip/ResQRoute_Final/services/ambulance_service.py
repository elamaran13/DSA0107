import sqlite3
import logging
from typing import Dict, Any, List, Optional, Tuple
from database import get_connection

logger = logging.getLogger("ResQRoute.AmbulanceService")

class AmbulanceService:
    """
    Manages ambulance vehicle status, availability, assignments, and positions.
    """

    def get_all_ambulances(self) -> List[Dict[str, Any]]:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM ambulances ORDER BY id ASC;")
        rows = [dict(r) for r in cursor.fetchall()]
        conn.close()
        return rows

    def get_available_ambulances(self) -> List[Dict[str, Any]]:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM ambulances WHERE status = 'Available' ORDER BY id ASC;")
        rows = [dict(r) for r in cursor.fetchall()]
        conn.close()
        return rows

    def get_ambulance_by_id(self, amb_id: str) -> Optional[Dict[str, Any]]:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM ambulances WHERE id = ?;", (amb_id,))
        row = cursor.fetchone()
        conn.close()
        return dict(row) if row else None

    def update_ambulance_status(self, amb_id: str, new_status: str) -> Tuple[bool, str]:
        if new_status not in ["Available", "Busy", "Maintenance"]:
            return False, f"Invalid status {new_status}. Must be Available, Busy, or Maintenance."

        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("UPDATE ambulances SET status = ? WHERE id = ?;", (new_status, amb_id))
        conn.commit()
        conn.close()
        return True, f"Ambulance {amb_id} status updated to {new_status}."

    def update_ambulance_location(self, amb_id: str, new_location: str) -> Tuple[bool, str]:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("UPDATE ambulances SET current_location = ? WHERE id = ?;", (new_location, amb_id))
        conn.commit()
        conn.close()
        return True, f"Ambulance {amb_id} relocated to {new_location}."

    def assign_to_mission(
        self,
        amb_id: str,
        incident_id: str,
        duration_min: float,
        current_sim_time: float
    ) -> Tuple[bool, str]:
        amb = self.get_ambulance_by_id(amb_id)
        if not amb:
            return False, f"Ambulance {amb_id} does not exist."

        if amb["status"] != "Available":
            return False, f"Cannot assign {amb_id}: ambulance is currently {amb['status']}."

        conn = get_connection()
        cursor = conn.cursor()
        busy_until = current_sim_time + duration_min

        cursor.execute("""
            UPDATE ambulances
            SET status = 'Busy', assigned_incident_id = ?, busy_until_time = ?
            WHERE id = ?;
        """, (incident_id, busy_until, amb_id))

        cursor.execute("""
            INSERT INTO assignments (incident_id, ambulance_id, assigned_at, status)
            VALUES (?, ?, ?, 'Active');
        """, (incident_id, amb_id, current_sim_time))

        cursor.execute("""
            UPDATE incidents
            SET status = 'Dispatched', assigned_ambulance_id = ?
            WHERE id = ?;
        """, (amb_id, incident_id))

        conn.commit()
        conn.close()
        return True, f"Ambulance {amb_id} dispatched to incident {incident_id} (busy until t={busy_until:.1f} min)."

    def release_from_mission(self, amb_id: str) -> Tuple[bool, str]:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("""
            UPDATE ambulances
            SET status = 'Available', assigned_incident_id = '', busy_until_time = 0.0
            WHERE id = ?;
        """, (amb_id,))
        conn.commit()
        conn.close()
        return True, f"Ambulance {amb_id} released and is now Available."

    def add_ambulance(
        self,
        amb_id: str,
        call_sign: str,
        station_id: str,
        current_location: str,
        fuel_level: float = 100.0
    ) -> Tuple[bool, str]:
        if not amb_id.strip() or not call_sign.strip():
            return False, "Ambulance ID and Call Sign cannot be empty."

        existing = self.get_ambulance_by_id(amb_id)
        if existing:
            return False, f"Ambulance with ID {amb_id} already exists."

        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO ambulances (id, call_sign, current_location, status, station_id, fuel_level, assigned_incident_id, busy_until_time)
            VALUES (?, ?, ?, 'Available', ?, ?, '', 0.0);
        """, (amb_id, call_sign, current_location, station_id, fuel_level))
        conn.commit()
        conn.close()
        return True, f"Ambulance {amb_id} ({call_sign}) successfully registered."


ambulance_service = AmbulanceService()
