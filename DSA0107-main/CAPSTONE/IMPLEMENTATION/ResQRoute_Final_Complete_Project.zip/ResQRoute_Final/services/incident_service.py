import sqlite3
import logging
from typing import Dict, Any, List, Optional, Tuple
from database import get_connection
from cpp_bridge import engine_bridge
from config import DEFAULT_SEVERITY_WEIGHT, DEFAULT_WAITING_TIME_WEIGHT

logger = logging.getLogger("ResQRoute.IncidentService")

class IncidentService:
    """
    Manages emergency incident creation, validation, prioritization, and state transitions.
    """

    def get_all_incidents(self) -> List[Dict[str, Any]]:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM incidents ORDER BY arrival_time ASC;")
        rows = [dict(r) for r in cursor.fetchall()]
        conn.close()
        return rows

    def get_pending_incidents(self) -> List[Dict[str, Any]]:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM incidents WHERE status = 'Pending' ORDER BY priority_score DESC, arrival_time ASC;")
        rows = [dict(r) for r in cursor.fetchall()]
        conn.close()
        return rows

    def get_incident_by_id(self, incident_id: str) -> Optional[Dict[str, Any]]:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM incidents WHERE id = ?;", (incident_id,))
        row = cursor.fetchone()
        conn.close()
        return dict(row) if row else None

    def generate_next_incident_id(self) -> str:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT id FROM incidents WHERE id LIKE 'INC-%' ORDER BY id DESC LIMIT 1;")
        row = cursor.fetchone()
        conn.close()
        if not row:
            return "INC-001"
        try:
            num = int(row["id"].split("-")[1])
            return f"INC-{num + 1:03d}"
        except Exception:
            import time
            return f"INC-{int(time.time()) % 1000:03d}"

    def register_incident(
        self,
        location: str,
        severity: str,
        description: str,
        arrival_time: float = 0.0,
        severity_weight: float = DEFAULT_SEVERITY_WEIGHT,
        waiting_time_weight: float = DEFAULT_WAITING_TIME_WEIGHT
    ) -> Tuple[bool, str, Optional[Dict[str, Any]]]:
        # Validation
        if severity not in ["Critical", "High", "Medium", "Low"]:
            return False, f"Invalid severity level: {severity}. Must be Critical, High, Medium, or Low.", None

        if not location.strip():
            return False, "Emergency location cannot be empty.", None

        if not description.strip():
            return False, "Emergency description is required.", None

        incident_id = self.generate_next_incident_id()

        # Compute priority via C++ engine
        inc_payload = [{
            "id": incident_id,
            "location": location,
            "severity": severity,
            "arrival_time": arrival_time,
            "waiting_time": 0.0,
            "description": description,
            "status": "Pending",
            "severity_weight": severity_weight,
            "waiting_time_weight": waiting_time_weight
        }]

        cpp_res = engine_bridge.prioritize_incidents(
            inc_payload,
            current_sim_time=arrival_time,
            severity_weight=severity_weight,
            waiting_time_weight=waiting_time_weight
        )

        priority_score = 50.0
        if cpp_res.get("success") and cpp_res.get("ranked_pending_queue"):
            priority_score = cpp_res["ranked_pending_queue"][0].get("priority_score", 50.0)

        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("""
            INSERT INTO incidents (id, location, severity, arrival_time, waiting_time, description, status, priority_score, severity_weight, waiting_time_weight)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
        """, (incident_id, location, severity, arrival_time, 0.0, description, "Pending", priority_score, severity_weight, waiting_time_weight))
        conn.commit()
        conn.close()

        created = self.get_incident_by_id(incident_id)
        return True, f"Emergency incident {incident_id} registered with initial priority {priority_score:.1f}.", created

    def recalculate_priorities(
        self,
        current_sim_time: float,
        severity_weight: float = DEFAULT_SEVERITY_WEIGHT,
        waiting_time_weight: float = DEFAULT_WAITING_TIME_WEIGHT
    ) -> List[Dict[str, Any]]:
        """
        Recalculates all pending incident priority scores using the compiled C++ engine.
        """
        all_incidents = self.get_all_incidents()
        cpp_res = engine_bridge.prioritize_incidents(
            all_incidents,
            current_sim_time=current_sim_time,
            severity_weight=severity_weight,
            waiting_time_weight=waiting_time_weight
        )

        if not cpp_res.get("success"):
            logger.error("C++ engine prioritization error: %s", cpp_res.get("error"))
            return self.get_pending_incidents()

        conn = get_connection()
        cursor = conn.cursor()
        ranked = cpp_res.get("ranked_pending_queue", [])
        for inc in ranked:
            cursor.execute("""
                UPDATE incidents
                SET priority_score = ?, waiting_time = ?, severity_weight = ?, waiting_time_weight = ?
                WHERE id = ?;
            """, (inc["priority_score"], inc["waiting_time"], severity_weight, waiting_time_weight, inc["id"]))
        conn.commit()
        conn.close()

        return ranked

    def update_incident_status(self, incident_id: str, new_status: str) -> Tuple[bool, str]:
        valid_transitions = {
            "Pending": ["Dispatched", "Cancelled"],
            "Dispatched": ["In-Transit", "Cancelled", "Pending"],
            "In-Transit": ["Resolved", "Cancelled"],
            "Resolved": [],
            "Cancelled": []
        }

        inc = self.get_incident_by_id(incident_id)
        if not inc:
            return False, f"Incident {incident_id} not found."

        curr_status = inc["status"]
        if new_status == curr_status:
            return True, f"Incident status is already {new_status}."

        allowed = valid_transitions.get(curr_status, [])
        if new_status not in allowed:
            return False, f"Cannot transition incident from '{curr_status}' to '{new_status}'. Allowed transitions: {allowed}"

        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("UPDATE incidents SET status = ? WHERE id = ?;", (new_status, incident_id))
        conn.commit()
        conn.close()

        return True, f"Incident {incident_id} successfully transitioned from '{curr_status}' to '{new_status}'."


incident_service = IncidentService()
