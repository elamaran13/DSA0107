import sqlite3
import json
import uuid
import logging
from typing import Dict, Any, List, Optional
import pandas as pd
from database import get_connection
from cpp_bridge import engine_bridge
from config import EXPORTS_DIR

logger = logging.getLogger("ResQRoute.EvaluationService")

class EvaluationService:
    """
    Executes and analyzes multi-strategy comparative simulations across scenarios.
    """

    def get_available_scenarios(self) -> List[Dict[str, Any]]:
        conn = get_connection()
        cursor = conn.cursor()
        cursor.execute("SELECT * FROM scenario_definitions ORDER BY id ASC;")
        rows = [dict(r) for r in cursor.fetchall()]
        conn.close()

        cpp_meta = {}
        try:
            listed = engine_bridge.list_scenarios()
            if isinstance(listed, list):
                cpp_meta = {s.get("id"): s for s in listed if isinstance(s, dict)}
        except Exception:
            cpp_meta = {}

        if rows:
            for row in rows:
                meta = cpp_meta.get(row["id"], {})
                row["closed_roads"] = meta.get("closed_roads", [])
            return rows
        return list(cpp_meta.values())

    def run_benchmark(self, scenario_id: str = "SCENARIO_A") -> Dict[str, Any]:
        """
        Runs 3-strategy evaluation for a scenario via the C++ PerformanceEvaluator.
        """
        res = engine_bridge.evaluate_scenario(scenario_id=scenario_id)
        if "error" in res:
            logger.error(f"Engine evaluation error: {res['error']}")
            return res

        # Persist run to SQLite
        run_id = f"RUN-{scenario_id}-{uuid.uuid4().hex[:6].upper()}"
        conn = get_connection()
        cursor = conn.cursor()
        try:
            cursor.execute("""
                INSERT INTO simulation_runs (run_id, scenario_id, settings_json)
                VALUES (?, ?, ?);
            """, (run_id, scenario_id, json.dumps({"scenario_id": scenario_id})))

            strategies = res.get("strategies", {})
            for strat_key, s_data in strategies.items():
                cursor.execute("""
                    INSERT INTO simulation_results (
                        run_id, strategy_name, total_incidents, incidents_served,
                        incidents_unserved, completion_rate_pct, avg_response_time_min,
                        median_response_time_min, critical_avg_response_time_min,
                        critical_avg_waiting_time_min, total_travel_distance_km,
                        final_remaining_coverage_pct, avg_coverage_loss_pct,
                        total_computation_time_ms, avg_computation_time_ms
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
                """, (
                    run_id,
                    s_data.get("strategy_name", strat_key),
                    s_data.get("total_incidents", 0),
                    s_data.get("incidents_served", 0),
                    s_data.get("incidents_unserved", 0),
                    s_data.get("completion_rate_pct", 0.0),
                    s_data.get("avg_response_time_min", 0.0),
                    s_data.get("median_response_time_min", 0.0),
                    s_data.get("critical_avg_response_time_min", 0.0),
                    s_data.get("critical_avg_waiting_time_min", 0.0),
                    s_data.get("total_travel_distance_km", 0.0),
                    s_data.get("final_remaining_coverage_pct", 0.0),
                    s_data.get("avg_coverage_loss_pct", 0.0),
                    s_data.get("total_computation_time_ms", 0.0),
                    s_data.get("avg_computation_time_ms", 0.0)
                ))
            conn.commit()
            res["run_id"] = run_id
        except Exception as e:
            conn.rollback()
            logger.error(f"Error persisting simulation results: {e}")
        finally:
            conn.close()

        return res

    def get_comparison_dataframe(self, eval_results: Dict[str, Any]) -> pd.DataFrame:
        strategies = eval_results.get("strategies", {})
        rows = []
        for strat_key, s in strategies.items():
            rows.append({
                "Strategy": s.get("strategy_name", strat_key),
                "Served": f"{s.get('incidents_served', 0)}/{s.get('total_incidents', 0)}",
                "Completion %": f"{s.get('completion_rate_pct', 0.0):.1f}%",
                "Avg Response (min)": round(s.get("avg_response_time_min", 0.0), 2),
                "Median Response (min)": round(s.get("median_response_time_min", 0.0), 2),
                "Critical Resp (min)": round(s.get("critical_avg_response_time_min", 0.0), 2),
                "Total Travel (km)": round(s.get("total_travel_distance_km", 0.0), 2),
                "Final Coverage %": f"{s.get('final_remaining_coverage_pct', 0.0):.1f}%",
                "Avg Cov Loss %": f"{s.get('avg_coverage_loss_pct', 0.0):.1f}%",
                "Avg Time (ms)": round(s.get("avg_computation_time_ms", 0.0), 3)
            })
        return pd.DataFrame(rows)

    def export_benchmark_csv(self, eval_results: Dict[str, Any]) -> str:
        df = self.get_comparison_dataframe(eval_results)
        scenario_id = eval_results.get("scenario_id", "CUSTOM")
        out_path = EXPORTS_DIR / f"evaluation_{scenario_id}.csv"
        df.to_csv(out_path, index=False)
        return str(out_path)


evaluation_service = EvaluationService()
