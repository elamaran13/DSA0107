import sqlite3
import json
import logging
from typing import Dict, Any, List, Optional, Tuple
from database import get_connection
from cpp_bridge import engine_bridge
from services.incident_service import incident_service
from services.ambulance_service import ambulance_service
from services.road_service import road_service
from config import (
    DEFAULT_LOOKAHEAD_WEIGHTS,
    DEFAULT_SCENARIO_ROLLOUT_COUNT,
    DEFAULT_LOOKAHEAD_HORIZON_MIN,
    DEFAULT_RANDOM_SEED
)

logger = logging.getLogger("ResQRoute.DispatchService")

class DispatchService:
    """
    Orchestrates intelligent ambulance dispatch using the C++ Look-Ahead Optimizer,
    persisting decisions, candidate evaluations, and updating fleet state.
    """

    def execute_dispatch(
        self,
        incident_id: str,
        current_sim_time: float = 0.0,
        weights: Optional[Dict[str, float]] = None,
        scenario_count: int = DEFAULT_SCENARIO_ROLLOUT_COUNT,
        horizon_minutes: float = DEFAULT_LOOKAHEAD_HORIZON_MIN,
        random_seed: int = DEFAULT_RANDOM_SEED
    ) -> Tuple[bool, str, Dict[str, Any]]:
        # Fetch current incident
        incident = incident_service.get_incident_by_id(incident_id)
        if not incident:
            return False, f"Incident {incident_id} not found.", {}

        if incident["status"] != "Pending":
            return False, f"Cannot dispatch to incident {incident_id}: status is already '{incident['status']}'.", {}

        # Fetch fleet and network
        ambulances = ambulance_service.get_all_ambulances()
        available_ambs = [a for a in ambulances if a["status"] == "Available"]
        if not available_ambs:
            return False, "All ambulances are currently busy or under maintenance. No unit available to dispatch.", {}

        network = road_service.get_road_network_payload()
        pending_queue = incident_service.get_pending_incidents()

        # Invoke C++ Look-Ahead Optimizer
        cpp_result = engine_bridge.dispatch_incident(
            incident=incident,
            ambulances=ambulances,
            road_network=network,
            pending_queue=pending_queue,
            current_sim_time=current_sim_time,
            weights=weights or DEFAULT_LOOKAHEAD_WEIGHTS,
            scenario_count=scenario_count,
            horizon_minutes=horizon_minutes,
            random_seed=random_seed
        )

        if not cpp_result.get("success"):
            return False, f"C++ Look-Ahead Optimizer error: {cpp_result.get('error')}", {}

        decision = cpp_result.get("decision", {})
        if not decision.get("is_feasible"):
            return False, f"Dispatch failed: {decision.get('selection_reason', 'No reachable ambulance found.')}", decision

        selected_amb_id = decision.get("selected_ambulance_id")
        travel_time = decision.get("estimated_travel_time_min", 0.0)

        # Persist decision & evaluations in SQLite
        conn = get_connection()
        cursor = conn.cursor()
        try:
            cursor.execute("""
                INSERT OR REPLACE INTO dispatch_decisions (
                    decision_id, incident_id, selected_ambulance_id, strategy_name,
                    is_feasible, estimated_travel_time_min, estimated_distance_km,
                    total_cost, pre_coverage_pct, post_coverage_pct, coverage_loss_pct,
                    selection_reason, computation_time_ms, simulation_time
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
            """, (
                decision["decision_id"],
                decision["incident_id"],
                selected_amb_id,
                decision["strategy_name"],
                1 if decision["is_feasible"] else 0,
                decision["estimated_travel_time_min"],
                decision["estimated_distance_km"],
                decision["total_cost"],
                decision["pre_coverage_pct"],
                decision["post_coverage_pct"],
                decision["coverage_loss_pct"],
                decision["selection_reason"],
                decision["computation_time_ms"],
                decision["simulation_time"]
            ))

            for cand in decision.get("candidate_evaluations", []):
                cursor.execute("""
                    INSERT INTO candidate_evaluations (
                        decision_id, ambulance_id, call_sign, is_reachable,
                        travel_time_min, travel_distance_km, immediate_response_cost,
                        future_delay_cost, critical_delay_penalty, coverage_loss_penalty,
                        road_disruption_penalty, total_cost, remaining_coverage_pct,
                        coverage_loss_pct, rank_explanation
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
                """, (
                    decision["decision_id"],
                    cand["ambulance_id"],
                    cand.get("call_sign", ""),
                    1 if cand["is_reachable"] else 0,
                    cand["travel_time_min"],
                    cand["travel_distance_km"],
                    cand["immediate_response_cost"],
                    cand["future_delay_cost"],
                    cand["critical_delay_penalty"],
                    cand["coverage_loss_penalty"],
                    cand["road_disruption_penalty"],
                    cand["total_cost"],
                    cand["remaining_coverage_pct"],
                    cand["coverage_loss_pct"],
                    cand["rank_explanation"]
                ))

            # Update ambulance and incident state
            service_duration = travel_time + 20.0  # Travel time plus 20 mins treatment/transfer
            ambulance_service.assign_to_mission(
                amb_id=selected_amb_id,
                incident_id=incident_id,
                duration_min=service_duration,
                current_sim_time=current_sim_time
            )

            conn.commit()
            return True, f"Successfully dispatched {selected_amb_id} to incident {incident_id}.", decision
        except Exception as e:
            conn.rollback()
            logger.error("Error committing dispatch decision: %s", e)
            return False, f"Database error during dispatch persistence: {str(e)}", decision
        finally:
            conn.close()

    def get_latest_decision(self, incident_id: Optional[str] = None) -> Optional[Dict[str, Any]]:
        conn = get_connection()
        cursor = conn.cursor()
        if incident_id:
            cursor.execute("SELECT * FROM dispatch_decisions WHERE incident_id = ? ORDER BY created_at DESC LIMIT 1;", (incident_id,))
        else:
            cursor.execute("SELECT * FROM dispatch_decisions ORDER BY created_at DESC LIMIT 1;")
        row = cursor.fetchone()
        conn.close()
        return dict(row) if row else None


dispatch_service = DispatchService()
