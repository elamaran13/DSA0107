import time
import logging
from typing import Dict, Any, List, Optional
from database import get_connection
from services.incident_service import incident_service
from services.ambulance_service import ambulance_service
from services.road_service import road_service
from services.dispatch_service import dispatch_service

logger = logging.getLogger("ResQRoute.SimulationService")

class SimulationService:
    """
    Simulation environment orchestrator managing simulation time progression,
    automatic pending call ranking, and status synchronization.
    """

    def __init__(self):
        self.sim_time = 0.0

    def get_current_time(self) -> float:
        return self.sim_time

    def set_time(self, new_time: float):
        self.sim_time = max(0.0, new_time)

    def advance_time(self, delta_minutes: float) -> Dict[str, Any]:
        """
        Advances the simulation clock by delta_minutes, updates ambulance mission completions,
        and recalculates pending incident priorities.
        """
        self.sim_time += delta_minutes

        # Check ambulances returning to available
        ambs = ambulance_service.get_all_ambulances()
        freed = []
        for a in ambs:
            if a["status"] == "Busy" and self.sim_time >= a.get("busy_until_time", 0.0):
                ambulance_service.release_from_mission(a["id"])
                freed.append(a["id"])

        # Update pending emergency priorities
        ranked_pending = incident_service.recalculate_priorities(self.sim_time)

        return {
            "current_sim_time": self.sim_time,
            "advanced_by": delta_minutes,
            "ambulances_freed": freed,
            "pending_queue_size": len(ranked_pending)
        }

    def reset_simulation(self):
        self.sim_time = 0.0


simulation_service = SimulationService()
