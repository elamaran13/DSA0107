import os
from pathlib import Path

# Base project directory (portable, dynamic relative resolution)
BASE_DIR = Path(__file__).resolve().parent

# Subdirectory configurations
DATABASE_DIR = BASE_DIR / "database"
DATABASE_PATH = DATABASE_DIR / "resqroute.db"

DATA_DIR = BASE_DIR / "data"
EXPORTS_DIR = BASE_DIR / "exports"

CPP_ENGINE_DIR = BASE_DIR / "cpp_engine"
CPP_ENGINE_EXE = CPP_ENGINE_DIR / ("resqroute_engine.exe" if os.name == "nt" else "resqroute_engine")
CPP_TESTS_EXE = CPP_ENGINE_DIR / ("resqroute_tests.exe" if os.name == "nt" else "resqroute_tests")

# Ensure required directories exist
DATABASE_DIR.mkdir(parents=True, exist_ok=True)
DATA_DIR.mkdir(parents=True, exist_ok=True)
EXPORTS_DIR.mkdir(parents=True, exist_ok=True)

# Module 1: Priority Engine Parameters
DEFAULT_SEVERITY_WEIGHT = 25.0
DEFAULT_WAITING_TIME_WEIGHT = 2.0

# Module 2: Counterfactual Look-Ahead Optimizer Parameters
DEFAULT_LOOKAHEAD_WEIGHTS = {
    "immediate_weight": 1.0,          # w_imm: Travel time & immediate urgency
    "future_delay_weight": 1.5,       # w_fut: Prospective response delays
    "critical_penalty_weight": 3.0,   # w_crit: Vulnerability to life-threatening calls
    "coverage_loss_weight": 1.8,      # w_cov: Marginal regional coverage loss
    "road_disruption_weight": 1.2     # w_disrupt: Road disruption / detour penalty
}
DEFAULT_SCENARIO_ROLLOUT_COUNT = 5
DEFAULT_LOOKAHEAD_HORIZON_MIN = 45.0
DEFAULT_RANDOM_SEED = 42

# Module 3: Routing & Network Parameters
DEFAULT_COVERAGE_THRESHOLD_MIN = 10.0
DEFAULT_AMBULANCE_SPEED_KMH = 55.0
